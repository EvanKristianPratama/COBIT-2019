@extends('layouts.app')

@section('content')
    <style>
        /* ====== COBIT Objectives Page Styles ====== */

        :root {
            --app-primary: #0f2b5c;
        }

        /* Navbar & Tabs */
        .navbar .nav-link,
        .navbar .navbar-brand {
            text-transform: uppercase;
            letter-spacing: 0.06em;
            font-weight: 700;
            color: rgba(255, 255, 255, 0.95) !important;
            text-shadow: 0 1px 2px rgba(15, 43, 92, 0.18);
        }

        .nav-pills .nav-link,
        .nav-tabs .nav-link,
        #componentGamoTabs .nav-link,
        #componentGamoObjTabs .nav-link {
            text-transform: uppercase;
            letter-spacing: 0.04em;
            font-weight: 700;
            color: rgba(15, 43, 92, 0.9) !important;
        }

        .nav-pills .nav-link.active,
        .nav-tabs .nav-link.active,
        #componentGamoTabs .nav-link.active,
        #componentGamoObjTabs .nav-link.active {
            background-color: var(--app-primary) !important;
            border-color: var(--app-primary) !important;
            color: #fff !important;
            box-shadow: none !important;
        }

        .nav-pills .nav-link:hover,
        .nav-tabs .nav-link:hover {
            color: var(--app-primary) !important;
            background: rgba(15, 43, 92, 0.04) !important;
        }

        /* Buttons */
        .btn-primary {
            background-color: var(--app-primary) !important;
            border-color: var(--app-primary) !important;
            color: #fff !important;
            box-shadow: 0 8px 20px rgba(15, 43, 92, 0.08);
            transition: transform 0.12s ease, box-shadow 0.12s ease, filter 0.12s ease;
        }

        .btn-primary:hover,
        .btn-primary:focus {
            background-color: #0d254a !important;
            border-color: #0d254a !important;
            box-shadow: 0 14px 30px rgba(15, 43, 92, 0.12);
            transform: translateY(-2px);
        }

        .btn-outline-primary {
            color: var(--app-primary) !important;
            border-color: rgba(15, 43, 92, 0.12) !important;
        }

        .btn-outline-primary:hover,
        .btn-outline-primary:focus {
            background-color: rgba(15, 43, 92, 0.06) !important;
            border-color: var(--app-primary) !important;
            color: var(--app-primary) !important;
        }

        /* Cards & Headers */
        .bg-primary,
        .card-header.bg-primary,
        .table-primary {
            background-color: var(--app-primary) !important;
            color: #fff !important;
            border-color: rgba(15, 43, 92, 0.08) !important;
        }

        .objectives-page {
            background: #f6f8ff;
            padding: 20px;
            border-radius: 12px;
        }

        .objectives-page .card {
            background: #fff;
            border-radius: 10px;
        }

        /* Hero & Assessment Cards */
        .hero-card {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 25px 60px rgba(9, 18, 56, 0.18);
            overflow: hidden;
        }

        .hero-header {
            background: linear-gradient(135deg, #081a3d, #0f2b5c);
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            border: none;
        }

        .hero-title {
            font-size: 1.6rem;
            font-weight: 700;
            letter-spacing: 0.03em;
        }

        .hero-subtitle {
            color: rgba(255, 255, 255, 0.8);
            letter-spacing: 0.02em;
        }

        .hero-pill {
            border-radius: 999px;
            padding: 0.4rem 1.3rem;
            background: rgba(255, 255, 255, 0.15);
            font-weight: 600;
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }

        .hero-body {
            padding: 1.75rem;
            background: #fff;
        }

        .hero-stat-card {
            background: #f6f8ff;
            border-radius: 0.9rem;
            padding: 1rem 1.2rem;
            border: 1px solid #e3e8ff;
            height: 100%;
        }

        .hero-status-summary {
            background: #ffffff;
            border: 1px solid #e3e8ff;
            border-radius: 0.9rem;
            padding: 0.75rem 1rem;
            min-width: 260px;
        }

        .hero-status-card {
            flex: 1 1 120px;
            background: #f9fbff;
            border-radius: 0.85rem;
            padding: 0.9rem 1rem;
            border: 1px dashed #dbe2ff;
        }

        .hero-status-card .status-label {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #6f7491;
        }

        .hero-status-card .status-value {
            display: block;
            font-size: 1.35rem;
            font-weight: 700;
        }

        .hero-status-card.status-finished {
            background: rgba(16, 185, 129, 0.08);
            border-color: rgba(16, 185, 129, 0.4);
            color: #0f5132;
        }

        .hero-status-card.status-draft {
            background: rgba(253, 224, 71, 0.12);
            border-color: rgba(250, 204, 21, 0.45);
            color: #7a5d07;
        }

        .model-focus-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.25rem 0.7rem;
            border-radius: 999px;
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 0.06em;
            text-transform: uppercase;
        }

        .model-focus-core {
            background: #7a2433;
            color: #fff;
        }

        .model-focus-info {
            background: #1f6f43;
            color: #fff;
        }

        .model-focus-default {
            background: #1a3665;
            color: #fff;
        }

        .stat-label {
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #6b7392;
        }

        .stat-value {
            display: block;
            font-size: 1.6rem;
            font-weight: 700;
            color: #0f2b5c;
            margin: 0.15rem 0;
        }

        .stat-subtext {
            font-size: 0.9rem;
            color: #7b84a5;
        }

        .hero-action-btn {
            border-radius: 999px;
            padding: 0.55rem 1.5rem;
            font-weight: 600;
            box-shadow: 0 12px 30px rgba(15, 106, 217, 0.2);
        }

        /* Assessment Cards */
        .assessment-card {
            border-radius: 0.9rem;
            transition: transform 0.22s cubic-bezier(.2, .9, .2, 1), box-shadow 0.22s cubic-bezier(.2, .9, .2, 1);
            box-shadow: 0 8px 20px rgba(15, 43, 92, 0.06);
            will-change: transform;
        }

        .assessment-card:hover,
        .assessment-card:focus-within {
            transform: translateY(-6px);
            box-shadow: 0 28px 60px rgba(15, 43, 92, 0.14);
        }

        .assessment-card-header {
            background: #f8f9ff;
            border-bottom: 1px solid rgba(15, 43, 92, 0.08);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 0.75rem;
        }

        .assessment-code {
            font-weight: 700;
            color: #0f2b5c;
        }

        .assessment-meta {
            font-size: 0.85rem;
            color: #7a809b;
        }

        .status-chip {
            border-radius: 999px;
            padding: 0.35rem 1rem;
            font-weight: 600;
            font-size: 0.85rem;
            letter-spacing: 0.03em;
        }

        .chip-success {
            background: #d1f2e2;
            color: #0f5132;
        }

        .chip-info {
            background: #cff4fc;
            color: #055160;
        }

        .chip-warning {
            background: #fff3cd;
            color: #7a5d07;
        }

        .chip-muted {
            background: #f1f3f9;
            color: #5f6783;
        }

        .assessment-progress-block {
            border: 1px solid #e4e8fb;
            border-radius: 0.9rem;
            padding: 1rem 1.25rem;
            background: #fff;
        }

        .assessment-progress {
            height: 8px;
            border-radius: 6px;
            overflow: hidden;
        }

        /* Pills */
        .rating-pill {
            display: inline-block;
            margin-right: 6px;
            padding: 4px 8px;
            border-radius: 12px;
            font-weight: 700;
        }

        .pill-success {
            background: rgba(16, 185, 129, 0.08);
            color: #0f5132;
        }

        .pill-info {
            background: rgba(207, 244, 252, 0.15);
            color: #055160;
        }

        .pill-warning {
            background: rgba(255, 243, 205, 0.15);
            color: #7a5d07;
        }

        .pill-danger {
            background: rgba(255, 205, 210, 0.12);
            color: #7f1d1d;
        }

        /* Sticky Action Group */
        .sticky-action-group {
            position: fixed;
            right: 20px;
            bottom: 20px;
            display: flex;
            gap: 8px;
            z-index: 1050;
        }

        .sticky-action-btn {
            border-radius: 10px;
            padding: 10px 14px;
        }

        /* Vertical Text for Organizational Table */
        .vertical-text {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            white-space: nowrap;
            min-height: 150px;
            padding: 5px 0;
        }

        table th {
            padding: 0 !important;
            vertical-align: middle !important;
        }

        .infoflow-edit-control {
            min-width: 180px;
            font-size: 0.8rem;
        }

        .infoflow-edit-control.textarea {
            min-height: 74px;
        }

        .infoflow-notif-wrap {
            position: fixed;
            top: 16px;
            right: 16px;
            z-index: 2000;
            width: min(360px, calc(100vw - 32px));
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
    </style>

    <div class="container py-4 objectives-page">
        <div id="infoflowNotifWrap" class="infoflow-notif-wrap" aria-live="polite" aria-atomic="true"></div>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h1 class="h4 mb-0">Kamus Component</h1>
                @if($objective->focusArea)
                    @php
                        $focusAreaName = strtolower(trim((string) $objective->focusArea->name));
                        $focusAreaClass = str_contains($focusAreaName, 'information security')
                            ? 'model-focus-info'
                            : (str_contains($focusAreaName, 'core model') ? 'model-focus-core' : 'model-focus-default');
                    @endphp
                    <div class="small text-muted mt-1">
                        Focus Area:
                        <span class="model-focus-chip {{ $focusAreaClass }}">
                            {{ $objective->focusArea->name }}
                        </span>
                    </div>
                @endif
            </div>
            <div class="d-flex gap-2">
                @if(isset($focusAreaId) && $focusAreaId != 1)
                    <a href="{{ route('focus-areas.show', $focusAreaId) }}" class="btn btn-sm btn-outline-primary shadow-sm fw-bold" style="border-width: 2px;">
                        <i class="fas fa-pen me-2"></i>Edit
                    </a>
                @endif
                <a href="{{ route('focus-areas.index') }}" class="btn btn-sm btn-outline-primary shadow-sm fw-bold" style="border-width: 2px;">
                    <i class="fas fa-bullseye me-2"></i>Models
                </a>
                <a href="{{ route('cobit_component.gamoanalysis') }}" class="btn btn-sm btn-outline-primary shadow-sm fw-bold" style="border-width: 2px;">
                    <i class="fas fa-project-diagram me-2"></i>Buka Analisis Alur
                </a>
            </div>
        </div>

        <!-- Mode Selector -->
        <div class="mb-3">
            <div class="btn-group w-100" role="group" aria-label="View mode">
                <button id="modeGamoBtn" type="button" class="btn btn-outline-primary flex-fill">View by GAMO</button>
                <button id="modeComponentBtn" type="button" class="btn btn-primary flex-fill">View by Component</button>
                <button id="masterToggleBtn" type="button" class="btn btn-outline-primary flex-fill">Master</button>
            </div>
        </div>



        <!-- Component Selector -->
        <div class="mb-3 row g-2 align-items-center">
            <div class="col-auto">
                <label for="componentSelect" class="form-label mb-0">Component</label>
            </div>
            <div class="col">
                <select id="componentSelect" class="form-select">
                    <option value="">-- Lihat per Component (semua objective) --</option>
                    @foreach ([
            'overview' => 'Overview',
            'practices' => 'A.Component: Process',
            'organizational' => 'B.Component: Organizational Structures',
            'infoflows' => 'C.Component: Information Flows and Items',
            'skills' => 'D.Component: People, Skills and Competencies',
            'policies' => 'E.Component: Policies and Procedures',
            'culture' => 'F.Component: Culture, Ethics and Behavior',
            'services' => 'G.Component: Services, Infrastructure and Applications',
        ] as $k => $lbl)
                        <option value="{{ $k }}" {{ $k === $component ? 'selected' : '' }}>{{ $lbl }}
                        </option>
                    @endforeach
                </select>
            </div>
        </div>

        <!-- Component Results -->
        <div id="componentResults" class="mb-4"></div>

        <!-- Master Panel -->
        <div id="masterPanel" class="mb-4" style="display:none">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <div>
                        <strong>Data Master</strong>
                    </div>
                    <!-- BADGES REMOVED per request -->
                </div>

                <div class="card-body">
                    <ul class="nav nav-tabs mb-3" id="masterTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="eg-tab" data-bs-toggle="tab" data-bs-target="#eg-pane"
                                type="button" role="tab">Enterprise Goals</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="ag-tab" data-bs-toggle="tab" data-bs-target="#ag-pane"
                                type="button" role="tab">Alignment Goals</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="roles-tab" data-bs-toggle="tab" data-bs-target="#roles-pane"
                                type="button" role="tab">Roles</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="cap-tab" data-bs-toggle="tab" data-bs-target="#cap-pane"
                                type="button" role="tab">Capability & Maturity Level</button>
                        </li>
                    </ul>

                    <div class="tab-content" id="masterTabContent">
                        <div class="tab-pane fade show active" id="eg-pane" role="tabpanel">
                            <div class="table-responsive">
                                <table id="masterEgTable" class="table table-sm table-bordered table-striped mb-0">
                                    <thead class="table-primary text-white">
                                        <tr>
                                            <th style="width:120px">Enterprise Goal</th>
                                            <th>Description</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="ag-pane" role="tabpanel">
                            <div class="table-responsive">
                                <table id="masterAgTable" class="table table-sm table-bordered table-striped mb-0">
                                    <thead class="table-primary text-white">
                                        <tr>
                                            <th style="width:120px">Alignment Goal</th>
                                            <th>Description</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="roles-pane" role="tabpanel">
                            <div class="mb-2 small text-muted">
                                <i class="bi bi-info-circle"></i> Klik pada role untuk melihat GAMO mana saja yang role tersebut muncul beserta RACI-nya.
                            </div>
                            <div class="table-responsive">
                                <table id="masterRolesTable"
                                    class="table table-sm table-bordered table-hover table-striped mb-0">
                                    <thead class="table-primary text-white">
                                        <tr>
                                            <th style="width:120px">Role ID</th>
                                            <th>Role</th>
                                            <th>Description</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                            <!-- Role GAMO Detail Panel -->
                            <div id="roleGamoDetailPanel" class="mt-3" style="display:none;">
                                <div class="card border-info">
                                    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                                        <span id="roleGamoDetailTitle">Role Detail</span>
                                        <button type="button" class="btn btn-sm btn-light" onclick="document.getElementById('roleGamoDetailPanel').style.display='none';">&times;</button>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                            <table id="roleGamoDetailTable" class="table table-sm table-bordered table-striped mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th style="width:100px">GAMO</th>
                                                        <th>Practice</th>
                                                        <th style="width:80px" class="text-center">RACI</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Capability Level pane with mini-prefix tabs -->
                        <div class="tab-pane fade" id="cap-pane" role="tabpanel">
                            <div class="mb-2">
                                <!-- mini tabs for GAMO prefixes (EDM first) -->
                                <div id="capPrefixTabs" class="btn-group w-100 mb-2" role="group"
                                    aria-label="Capability prefixes"></div>
                            </div>

                            <div class="table-responsive">
                                <table id="masterCapTable" class="table table-sm table-bordered table-striped mb-0">
                                    <thead class="table-primary text-white">
                                        <tr>
                                            <th style="width:100px">GAMO</th>
                                            <th style="width:260px">Practice</th>
                                            <th>Activity</th>
                                            <th style="width:120px" class="text-center">Capability Level</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- GAMO Pane -->
        <div id="gamoPane" style="display:none">
            <div class="mb-2">
                <div id="gamoPrefixTabs" class="btn-group w-100 mb-2" role="group" aria-label="GAMO prefixes"></div>
                <div id="gamoBreadcrumbs" class="mb-3"></div>
            </div>
            <div id="gamoResults" class="mb-4"></div>
        </div>
    </div>

    <!-- Modal Pilih Practice (To) -->
    <div class="modal fade" id="toPracticeModal" tabindex="-1" aria-labelledby="toPracticeModalLabel" aria-hidden="true" style="z-index: 1060;">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content shadow-lg border-0">
                <div class="modal-header bg-primary text-white py-2 px-3">
                    <h5 class="modal-title" id="toPracticeModalLabel" style="font-size: 16px;">
                        <i class="bi bi-check2-square"></i> Pilih Penerima Alur Informasi (To)
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-3">
                    <div class="mb-3">
                        <input type="text" id="modalToSearch" class="form-control form-control-sm" placeholder="Cari preset atau practice...">
                    </div>
                    
                    <div class="fw-bold mb-1 border-bottom pb-1 text-secondary" style="font-size: 10px; letter-spacing: 0.5px; text-transform: uppercase;">Presets</div>
                    <div class="mb-3" id="modalToPresetsList">
                        <!-- Presets populated dynamically in JS -->
                    </div>
                    
                    <div class="fw-bold mb-1 border-bottom pb-1 text-secondary" style="font-size: 10px; letter-spacing: 0.5px; text-transform: uppercase;">Practice Codes</div>
                    <div id="modalToPracticesList" style="max-height: 250px; overflow-y: auto;">
                        <!-- Practices populated dynamically in JS -->
                    </div>
                </div>
                <div class="modal-footer py-2 px-3">
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="button" id="modalToSaveBtn" class="btn btn-sm btn-primary px-3">Pilih</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function() {
            'use strict';

            // ===================================================================
            // CONFIGURATION & STATE
            // ===================================================================

            const CONFIG = {
                PREFERRED_ORDER: ['EDM', 'APO', 'BAI', 'DSS', 'MEA'],
                CAP_PREFIX_TABS: ['Tes', 'EDM', 'APO', 'BAI', 'DSS'], // mini-tabs for capability
                COMPONENT_LABELS: {
                    overview: 'Overview',
                    practices: 'Practices',
                    infoflows: 'Information Flows',
                    organizational: 'Organizational',
                    policies: 'Policies',
                    skills: 'Skills',
                    culture: 'Culture & Ethics',
                    services: 'Services'
                }
            };

            const STATE = {
                cacheAll: null,
                masterRendered: false,
                searchTerm: '',
                capAllRows: [], // store all capability rows for filtering
                objectiveMap: new Map(), // safeId -> objective_id mapping untuk tab filter
                inputMode: false,
                showCreateRowForPractice: {}
            };


            // Server-injected master lists
            const MASTER_DATA = {
                enterGoals: @json($masterEnterGoals ?? []),
                alignGoals: @json($masterAlignGoals ?? []),
                roles: @json($masterRoles ?? []),
                practices: @json($masterPractices ?? [])
            };

            const AUTHZ = {
                canInputMode: @json(auth()->check() && auth()->user()->can('design-factors.input'))
            };

            const CURRENT_FOCUS_AREA_ID = @json((int) ($focusAreaId ?? ($objective->focus_area_id ?? 0)));

            // ===================================================================
            // DOM REFERENCES
            // ===================================================================

            const DOM = {
                componentSelect: document.getElementById('componentSelect'),
                componentResults: document.getElementById('componentResults'),
                masterPanel: document.getElementById('masterPanel'),
                gamoPane: document.getElementById('gamoPane'),
                gamoPrefixTabs: document.getElementById('gamoPrefixTabs'),
                gamoBreadcrumbs: document.getElementById('gamoBreadcrumbs'),
                gamoResults: document.getElementById('gamoResults'),
                modeGamoBtn: document.getElementById('modeGamoBtn'),
                modeComponentBtn: document.getElementById('modeComponentBtn'),
                masterToggleBtn: document.getElementById('masterToggleBtn'),
                inputModeBtn: document.getElementById('inputModeBtn'),
                infoflowNotifWrap: document.getElementById('infoflowNotifWrap'),
                capPrefixTabs: document.getElementById('capPrefixTabs'),
                masterCapTableBody: () => document.querySelector('#masterCapTable tbody')
            };

            // ===================================================================
            // UTILITY FUNCTIONS
            // ===================================================================

            const Utils = {
                escapeHtml(str) {
                    if (str === null || str === undefined) return '';
                    const cleaned = String(str)
                        .replaceAll('"', '')
                        .replaceAll('&quot;', '')
                        .replaceAll('&#34;', '')
                        .replaceAll('&ldquo;', '')
                        .replaceAll('&rdquo;', '')
                        .replaceAll('&amp;quot;', '');

                    return cleaned
                        .replaceAll('&', '&amp;')
                        .replaceAll('<', '&lt;')
                        .replaceAll('>', '&gt;')
                        .replaceAll("'", '&#039;');
                },

                idify(str) {
                    return !str ?
                        Math.random().toString(36).slice(2, 8) :
                        String(str).replace(/[^a-z0-9_-]+/gi, '_');
                },

                formatText(raw) {
                    const escaped = this.escapeHtml(raw || '');
                    if (!STATE.searchTerm) return escaped;

                    try {
                        const regex = new RegExp(
                            `(${STATE.searchTerm.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')})`,
                            'gi'
                        );
                        return escaped.replace(regex, '<mark>$1</mark>');
                    } catch (e) {
                        return escaped;
                    }
                },

                displayObjectiveId(value) {
                    return String(value ?? '').replace(/\.(?:M|FA)\d+(?:\.\d+)?$/i, '');
                },

                displayGamoId(value) {
                    return this.displayObjectiveId(value);
                },

                displayFocusArea(value) {
                    if (!value) return 'COBIT Core Model';
                    if (typeof value === 'string') return value;
                    if (typeof value === 'object') {
                        return String(value.name || value.code || value.label || 'COBIT Core Model');
                    }
                    return String(value);
                },

                focusAreaTheme(value) {
                    const name = String(this.displayFocusArea(value)).toLowerCase();
                    if (name.includes('information security')) {
                        return {
                            chipClass: 'model-focus-info',
                            headerBg: '#1f6f43',
                        };
                    }
                    if (name.includes('core model')) {
                        return {
                            chipClass: 'model-focus-core',
                            headerBg: '#7a2433',
                        };
                    }
                    return {
                        chipClass: 'model-focus-default',
                        headerBg: '#1a3665',
                    };
                },

                sortById(arr) {
                    return arr.slice().sort((a, b) =>
                        String(a.id || '').localeCompare(String(b.id || ''))
                    );
                },

                // parse capability level to numeric priority for sorting
                parseLevelForSort(level) {
                    if (level === null || level === undefined) return Number.NEGATIVE_INFINITY;
                    const s = String(level).trim();
                    // try to extract leading number
                    const m = s.match(/-?\d+/);
                    if (m) return parseInt(m[0], 10);
                    // if not numeric, return NaN-like but put after numeric: use -Infinity? we want non-numeric to be last,
                    // so return Number.NEGATIVE_INFINITY - 1 would put before, so instead return Number.NEGATIVE_INFINITY? we will handle separately
                    return NaN;
                }
            };

            // ===================================================================
            // DATA FETCHING
            // ===================================================================

            const DataService = {
                getCsrfToken() {
                    const el = document.querySelector('meta[name="csrf-token"]');
                    return el ? el.getAttribute('content') : '';
                },

                async fetchAllObjectives() {
                    if (STATE.cacheAll) return STATE.cacheAll;

                    const baseUrl = '{{ url('/objectives') }}';
                    const url = CURRENT_FOCUS_AREA_ID ? `${baseUrl}?focus_area=${encodeURIComponent(CURRENT_FOCUS_AREA_ID)}` : baseUrl;
                    const response = await fetch(url, {
                        headers: {
                            'Accept': 'application/json'
                        }
                    });

                    if (!response.ok) {
                        throw new Error(`Fetch error: ${response.status}`);
                    }

                    STATE.cacheAll = await response.json();
                    return STATE.cacheAll;
                },

                async fetchPracticesList() {
                    if (STATE.practicesList) return STATE.practicesList;

                    const baseUrl = '{{ url('/objectives/practices-list') }}';
                    const url = CURRENT_FOCUS_AREA_ID ? `${baseUrl}?focus_area=${encodeURIComponent(CURRENT_FOCUS_AREA_ID)}` : baseUrl;
                    const response = await fetch(url, {
                        headers: {
                            'Accept': 'application/json'
                        }
                    });

                    if (!response.ok) {
                        throw new Error(`Fetch error: ${response.status}`);
                    }

                    const data = await response.json();
                    STATE.practicesList = data.practices || [];
                    return STATE.practicesList;
                },

                async parseJsonResponse(response) {
                    let payload = null;

                    try {
                        payload = await response.json();
                    } catch (err) {
                        payload = null;
                    }

                    if (!response.ok) {
                        const message = payload && payload.message ?
                            payload.message :
                            `Request failed: ${response.status}`;
                        throw new Error(message);
                    }

                    return payload;
                },

                async updateInfoflowInput(inputId, data) {
                    const response = await fetch(`{{ url('/objectives/infoflow-input') }}/${encodeURIComponent(inputId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createInfoflowInput(data) {
                    const response = await fetch(`{{ url('/objectives/infoflow-input') }}`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async updateInfoflowOutput(outputId, data) {
                    const response = await fetch(`{{ url('/objectives/infoflow-output') }}/${encodeURIComponent(outputId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createInfoflowOutput(data) {
                    const response = await fetch(`{{ url('/objectives/infoflow-output') }}`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async deleteInfoflowInput(inputId) {
                    const response = await fetch(`{{ url('/objectives/infoflow-input') }}/${encodeURIComponent(inputId)}`, {
                        method: 'DELETE',
                        headers: {
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        }
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async deleteInfoflowOutput(outputId) {
                    const response = await fetch(`{{ url('/objectives/infoflow-output') }}/${encodeURIComponent(outputId)}`, {
                        method: 'DELETE',
                        headers: {
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        }
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createPolicy(data) {
                    const response = await fetch(`{{ url('/objectives/policies') }}`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async updatePolicy(policyId, data) {
                    const response = await fetch(`{{ url('/objectives/policies') }}/${encodeURIComponent(policyId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createSkill(data) {
                    const response = await fetch(`{{ url('/objectives/skills') }}`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async updateSkill(skillId, data) {
                    const response = await fetch(`{{ url('/objectives/skills') }}/${encodeURIComponent(skillId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createKeyCulture(data) {
                    const response = await fetch(`{{ url('/objectives/key-culture') }}`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async updateKeyCulture(keyCultureId, data) {
                    const response = await fetch(`{{ url('/objectives/key-culture') }}/${encodeURIComponent(keyCultureId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createSia(data) {
                    const response = await fetch(`{{ url('/objectives/sia') }}`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async updateSia(siaId, data) {
                    const response = await fetch(`{{ url('/objectives/sia') }}/${encodeURIComponent(siaId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createPolicyGuidance(policyId, data) {
                    const response = await fetch(`{{ url('/objectives/policies') }}/${encodeURIComponent(policyId)}/guidance`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createSkillGuidance(skillId, data) {
                    const response = await fetch(`{{ url('/objectives/skills') }}/${encodeURIComponent(skillId)}/guidance`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createKeyCultureGuidance(keyCultureId, data) {
                    const response = await fetch(`{{ url('/objectives/key-culture') }}/${encodeURIComponent(keyCultureId)}/guidance`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async updateGuidance(guidanceId, data) {
                    const response = await fetch(`{{ url('/objectives/guidance') }}/${encodeURIComponent(guidanceId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async createPracticeMetric(practiceId, data) {
                    const response = await fetch(`{{ url('/objectives/practices') }}/${encodeURIComponent(practiceId)}/metrics`, {
                        method: 'POST',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async updatePracticeMetric(metricId, data) {
                    const response = await fetch(`{{ url('/objectives/practices/metrics') }}/${encodeURIComponent(metricId)}`, {
                        method: 'PUT',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        },
                        body: JSON.stringify(data || {})
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                },

                async deletePracticeMetric(metricId) {
                    const response = await fetch(`{{ url('/objectives/practices/metrics') }}/${encodeURIComponent(metricId)}`, {
                        method: 'DELETE',
                        headers: {
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': this.getCsrfToken()
                        }
                    });

                    STATE.cacheAll = null;
                    return this.parseJsonResponse(response);
                }
            };

            // ===================================================================
            // MASTER DATA FUNCTIONS
            // ===================================================================

            const MasterService = {
                async collectMasterData() {
                    let egList = this.parseEnterpriseGoals(MASTER_DATA.enterGoals);
                    let agList = this.parseAlignmentGoals(MASTER_DATA.alignGoals);
                    let roles = this.parseRoles(MASTER_DATA.roles);
                    let capRows = [];

                    // Fetch objectives (always needed for cap rows)
                    const all = await DataService.fetchAllObjectives();
                    const extracted = this.extractFromObjectives(all);
                    const capExtracted = this.extractCapabilityLevels(all);

                    if (!egList.length) egList = extracted.egList;
                    if (!agList.length) agList = extracted.agList;
                    if (!roles.length) roles = extracted.roles;

                    capRows = capExtracted;

                    return {
                        egList: Utils.sortById(egList),
                        agList: Utils.sortById(agList),
                        roles: Utils.sortById(roles),
                        capRows // NEW
                    };
                },

                parseEnterpriseGoals(data) {
                    return Array.isArray(data) ?
                        data.map(x => ({
                            id: String(x.entergoals_id || x.id || ''),
                            description: x.description || ''
                        })) : [];
                },

                parseAlignmentGoals(data) {
                    return Array.isArray(data) ?
                        data.map(x => ({
                            id: String(x.aligngoals_id || x.id || ''),
                            description: x.description || ''
                        })) : [];
                },

                parseRoles(data) {
                    return Array.isArray(data) ?
                        data.map(r => ({
                            id: r.role_id || r.id || '',
                            role: r.role || '',
                            description: r.description || ''
                        })) : [];
                },

                extractFromObjectives(objectives) {
                    const egMap = new Map();
                    const agMap = new Map();
                    const roleMap = new Map();

                    objectives.forEach(obj => {
                        // Extract Enterprise Goals
                        (obj.entergoals || []).forEach(eg => {
                            const id = String(eg.entergoals_id || '').toUpperCase();
                            if (id && !egMap.has(id)) {
                                egMap.set(id, {
                                    id,
                                    description: eg.description || ''
                                });
                            }
                        });

                        // Extract Alignment Goals
                        (obj.aligngoals || []).forEach(ag => {
                            const id = String(ag.aligngoals_id || '').toUpperCase();
                            if (id && !agMap.has(id)) {
                                agMap.set(id, {
                                    id,
                                    description: ag.description || ''
                                });
                            }
                        });

                        // Extract Roles
                        (obj.practices || []).forEach(p => {
                            (p.roles || []).forEach(r => {
                                const rid = String(r.role_id || r.id || r.role || '')
                                    .trim();
                                if (rid && !roleMap.has(rid)) {
                                    roleMap.set(rid, {
                                        id: rid,
                                        role: r.role || rid,
                                        description: r.description || ''
                                    });
                                }
                            });
                        });
                    });

                    return {
                        egList: Array.from(egMap.values()),
                        agList: Array.from(agMap.values()),
                        roles: Array.from(roleMap.values())
                    };
                },

                // ----------------------------------------
                // EXTRACT CAPABILITY LEVELS (NEW)
                // ----------------------------------------
                extractCapabilityLevels(objectives) {
                    // returns array of { gamo, practice_id, practice_name, activity, level }
                    const rows = [];
                    (objectives || []).forEach(obj => {
                        const gamo = String(obj.objective_id || '').toUpperCase();
                        (obj.practices || []).forEach(practice => {
                            const practiceLabel =
                                `${practice.practice_id || ''} ${practice.practice_name || ''}`
                                .trim();
                            (practice.activities || []).forEach(activity => {
                                const level = activity.capability_lvl ?? activity
                                    .capability_level ?? activity.level ?? '';
                                rows.push({
                                    gamo,
                                    practice_id: practice.practice_id || '',
                                    practice_name: practice.practice_name ||
                                        practiceLabel,
                                    activity: activity.description || activity
                                        .activity || '',
                                    level: level === null ? '' : String(level)
                                });
                            });
                        });
                    });
                    return rows;
                },

                // ----------------------------------------
                // EXTRACT ROLE-GAMO MAPPINGS (NEW)
                // ----------------------------------------
                extractRoleGamoMappings(objectives) {
                    // returns Map: roleName => [{ gamo, practice_id, practice_name, raci }]
                    const roleGamoMap = new Map();
                    (objectives || []).forEach(obj => {
                        const gamo = String(obj.objective_id || '').toUpperCase();
                        (obj.practices || []).forEach(practice => {
                            const practiceId = practice.practice_id || '';
                            const practiceName = practice.practice_name || '';
                            const practiceLabel = `${practiceId} ${practiceName}`.trim();
                            (practice.roles || []).forEach(role => {
                                const roleName = role.role || '';
                                const raci = role.pivot?.r_a || '';
                                if (!roleName) return;
                                if (!roleGamoMap.has(roleName)) {
                                    roleGamoMap.set(roleName, []);
                                }
                                roleGamoMap.get(roleName).push({
                                    gamo,
                                    practice_id: practiceId,
                                    practice_name: practiceName,
                                    practice_label: practiceLabel,
                                    raci: raci
                                });
                            });
                        });
                    });
                    return roleGamoMap;
                },

                // Show role GAMO detail panel
                showRoleGamoDetail(roleName, roleGamoMap) {
                    const panel = document.getElementById('roleGamoDetailPanel');
                    const title = document.getElementById('roleGamoDetailTitle');
                    const tbody = document.querySelector('#roleGamoDetailTable tbody');
                    if (!panel || !tbody) return;

                    const data = roleGamoMap.get(roleName) || [];
                    title.innerHTML = `<strong>${Utils.escapeHtml(roleName)}</strong> - Muncul di ${data.length} Practice`;

                    if (!data.length) {
                        tbody.innerHTML = '<tr><td colspan="3" class="text-muted text-center">Role ini tidak ditemukan di GAMO manapun.</td></tr>';
                    } else {
                        // Sort by GAMO then by practice_id
                        data.sort((a, b) => {
                            const gCmp = String(a.gamo).localeCompare(String(b.gamo));
                            if (gCmp !== 0) return gCmp;
                            return String(a.practice_id).localeCompare(String(b.practice_id));
                        });

                        tbody.innerHTML = data.map(d => `
                            <tr>
                                <td class="fw-semibold">${Utils.escapeHtml(d.gamo)}</td>
                                <td>${Utils.escapeHtml(d.practice_label)}</td>
                                <td class="text-center fw-bold">${Utils.escapeHtml(d.raci) || '-'}</td>
                            </tr>
                        `).join('');
                    }

                    panel.style.display = 'block';
                    panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                },

                // populate cap prefix mini-tabs and attach handlers
                renderCapPrefixTabs(capRows) {
                    const container = DOM.capPrefixTabs;
                    if (!container) return;

                    // order: EDM first, then other requested prefixes (use CONFIG.CAP_PREFIX_TABS)
                    const prefixes = CONFIG.CAP_PREFIX_TABS.slice();
                    container.innerHTML = '';

                    prefixes.forEach((p, idx) => {
                        const btn = document.createElement('button');
                        btn.type = 'button';
                        // default active is EDM (first)
                        btn.className =
                            `btn ${idx === 0 ? 'btn-primary' : 'btn-outline-primary'} flex-fill`;
                        btn.setAttribute('data-prefix', p);
                        btn.textContent = p;
                        btn.addEventListener('click', () => {
                            // toggle active style
                            Array.from(container.children).forEach(c => {
                                c.classList.remove('btn-primary');
                                c.classList.add('btn-outline-primary');
                            });
                            btn.classList.remove('btn-outline-primary');
                            btn.classList.add('btn-primary');

                            // filter & render cap table
                            const filtered = capRows.filter(r => String(r.gamo || '').toUpperCase()
                                .startsWith(p.toUpperCase()));
                            MasterService.populateCapabilityTable(filtered);
                        });

                        container.appendChild(btn);
                    });

                    // add "All" button at start
                    const allBtn = document.createElement('button');
                    allBtn.type = 'button';
                    allBtn.className = 'btn btn-outline-secondary';
                    allBtn.textContent = 'All';
                    allBtn.setAttribute('data-prefix', 'ALL');
                    allBtn.addEventListener('click', () => {
                        Array.from(container.children).forEach(c => {
                            c.classList.remove('btn-primary');
                            c.classList.add('btn-outline-primary');
                        });
                        // don't set allBtn as primary; keep visual difference
                        MasterService.populateCapabilityTable(capRows);
                    });

                    container.insertBefore(allBtn, container.firstChild);

                    // trigger initial click for EDM (default)
                    const firstPrefBtn = container.querySelector('[data-prefix="EDM"]');
                    if (firstPrefBtn) firstPrefBtn.click();
                    else if (container.children[0]) container.children[0].click();
                },

                // populate master capability table — sorts by level desc and renders rows
                populateCapabilityTable(rows) {
                    const tbody = DOM.masterCapTableBody();
                    if (!tbody) return;
                    tbody.innerHTML = '';
                    // Sort rows by level (numeric ascending first), then by GAMO numeric ascending,
                    // then by practice_name and activity. Non-numeric levels are placed after numeric.
                    const withSortKey = (r) => {
                        const parsed = Utils.parseLevelForSort(r.level);
                        const isNum = !Number.isNaN(parsed) && Number.isFinite(parsed);
                        // extract numeric part of GAMO (e.g., EDM2 -> 2), fallback to large number if missing
                        const gamoMatch = String(r.gamo || '').match(/(\d+)/);
                        const gamoNum = gamoMatch ? parseInt(gamoMatch[1], 10) : Number.POSITIVE_INFINITY;
                        return {
                            parsed,
                            isNum,
                            gamoNum
                        };
                    };

                    rows.sort((a, b) => {
                        const ka = withSortKey(a);
                        const kb = withSortKey(b);

                        // both numeric levels -> ascending
                        if (ka.isNum && kb.isNum) {
                            if (ka.parsed !== kb.parsed) return ka.parsed - kb.parsed;
                        } else if (ka.isNum && !kb.isNum) {
                            return -1; // numeric before non-numeric
                        } else if (!ka.isNum && kb.isNum) {
                            return 1;
                        } else {
                            // both non-numeric -> lexical ascending
                            const lvCmp = String(a.level || '').localeCompare(String(b.level || ''));
                            if (lvCmp !== 0) return lvCmp;
                        }

                        // same level -> compare GAMO numeric (ascending)
                        if (ka.gamoNum !== kb.gamoNum) return (ka.gamoNum || 0) - (kb.gamoNum || 0);

                        // fallback: compare GAMO string
                        const gCmp = String(a.gamo || '').localeCompare(String(b.gamo || ''));
                        if (gCmp !== 0) return gCmp;

                        // then practice_name, then activity
                        const pCmp = String(a.practice_name || '').localeCompare(String(b.practice_name ||
                            ''));
                        if (pCmp !== 0) return pCmp;
                        return String(a.activity || '').localeCompare(String(b.activity || ''));
                    });

                    // Build HTML with merged level cells for consecutive identical levels
                    if (!rows.length) return;

                    // Determine runs of identical level values (string compare)
                    const rowsHtml = [];
                    for (let i = 0; i < rows.length;) {
                        const lvl = rows[i].level || '';
                        let j = i + 1;
                        while (j < rows.length && String(rows[j].level || '') === String(lvl)) j++;
                        const span = j - i;

                        for (let k = i; k < j; k++) {
                            const r = rows[k];
                            const gamoCell = `<td class="fw-semibold">${Utils.formatText(r.gamo || '')}</td>`;
                            const practiceCell =
                                `<td>${Utils.formatText((r.practice_id ? (r.practice_id + ' — ') : '') + (r.practice_name || ''))}</td>`;
                            const activityCell = `<td>${Utils.formatText(r.activity || '')}</td>`;

                            let levelCell = '';
                            if (k === i) {
                                // first row in run: emit level cell with rowspan if >1
                                const displayLevel = (r.level || '') ? Utils.formatText(String(r.level)) : '-';
                                levelCell = span > 1 ?
                                    `<td class="text-center" rowspan="${span}" style="width:120px">${displayLevel}</td>` :
                                    `<td class="text-center" style="width:120px">${displayLevel}</td>`;
                            }

                            rowsHtml.push(`<tr>${gamoCell}${practiceCell}${activityCell}${levelCell}</tr>`);
                        }

                        i = j;
                    }

                    tbody.innerHTML = rowsHtml.join('');
                },

                async renderMaster() {
                    try {
                        const {
                            egList,
                            agList,
                            roles,
                            capRows
                        } = await this.collectMasterData();

                        // Fetch objectives for role-GAMO mapping
                        const objectives = await DataService.fetchAllObjectives();
                        const roleGamoMap = this.extractRoleGamoMappings(objectives);

                        this.populateMasterTable('masterEgTable', egList, ['id', 'description']);
                        this.populateMasterTable('masterAgTable', agList, ['id', 'description']);
                        this.populateMasterTable('masterRolesTable', roles, ['id', 'role', 'description'], {
                            isRolesTable: true,
                            roleGamoMap: roleGamoMap
                        });

                        // store all cap rows for future filtering
                        STATE.capAllRows = (capRows || []).map(r => ({
                            gamo: r.gamo,
                            practice_id: r.practice_id,
                            practice_name: r.practice_name,
                            activity: r.activity,
                            level: r.level
                        }));

                        // render prefix mini-tabs and initially populate table (EDM default)
                        this.renderCapPrefixTabs(STATE.capAllRows);

                        STATE.masterRendered = true;
                    } catch (err) {
                        console.error('renderMaster error:', err);
                        const footer = document.getElementById('masterFooter');
                        if (footer) {
                            footer.innerHTML =
                                `<div class="text-danger">Gagal memuat master: ${Utils.escapeHtml(err.message)}</div>`;
                        }
                    }
                },

                populateMasterTable(tableId, data, columns, options = {}) {
                    const tbody = document.querySelector(`#${tableId} tbody`);
                    if (!tbody) return;

                    tbody.innerHTML = '';

                    data.forEach(item => {
                        const tr = document.createElement('tr');

                        // If this is the roles table, make row clickable
                        if (options.isRolesTable && options.roleGamoMap) {
                            tr.style.cursor = 'pointer';
                            tr.classList.add('role-clickable-row');
                            tr.addEventListener('click', () => {
                                // Remove active class from other rows
                                tbody.querySelectorAll('tr').forEach(r => r.classList.remove('table-active'));
                                tr.classList.add('table-active');
                                this.showRoleGamoDetail(item.role || item.id, options.roleGamoMap);
                            });
                        }

                        columns.forEach((col, idx) => {
                            const td = document.createElement('td');
                            if (idx === 0) td.className = 'fw-semibold';
                            
                            let val = item[col] || '';
                            if (col === 'id' && (tableId === 'masterEgTable' || tableId === 'masterAgTable')) {
                                val = Utils.displayObjectiveId(val);
                            }
                            
                            td.innerHTML = Utils.formatText(val);
                            tr.appendChild(td);
                        });

                        tbody.appendChild(tr);
                    });
                }
            };

            // ===================================================================
            // RENDERERS (COMPONENT DISPLAY)
            // ===================================================================

            const Renderers = {
                renderCardWrapper(opts) {
                    const title = typeof opts.title === 'string' ? opts.title : String(opts.title ?? '');
                    const subtitle = opts.subtitle ? `<div class="small text-white-50">${opts.subtitle}</div>` : '';
                    const smallNote = opts.smallNote ? `<div class="small text-white-50">${opts.smallNote}</div>` :
                        '';
                    const tabsHtml = opts.tabsHtml || '';
                    const bodyHtml = opts.bodyHtml || '';
                    const bodyId = opts.bodyId || Utils.idify(title);

                    return `
        <div class="card mb-3 shadow-sm">
          <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <div>
              <div class="fw-bold">${title}</div>
              ${subtitle}
            </div>
            <div>${smallNote}</div>
          </div>
          <div class="card-body">
            ${tabsHtml}
            <div class="mt-3" id="${bodyId}">${bodyHtml}</div>
          </div>
        </div>
      `;
                },

                escapeAttr(value) {
                    return String(value ?? '')
                        .replaceAll('&', '&amp;')
                        .replaceAll('"', '&quot;')
                        .replaceAll('<', '&lt;')
                        .replaceAll('>', '&gt;');
                },

                escapeTextarea(value) {
                    return String(value ?? '')
                        .replaceAll('&', '&amp;')
                        .replaceAll('<', '&lt;')
                        .replaceAll('>', '&gt;');
                },

                displayObjectiveId(value) {
                    return String(value ?? '').replace(/\.(?:M|FA)\d+(?:\.\d+)?$/i, '');
                },

                renderOverview(objectives) {
                    if (!Array.isArray(objectives) || !objectives.length) {
                        return '<div class="text-muted">No objectives found.</div>';
                    }

                    const buckets = this.categorizeObjectives(objectives);
                    const flattened = this.flattenBuckets(buckets);

                    return flattened.map(obj => this.renderSingleObjectiveCard(obj)).join('');
                },

                categorizeObjectives(objectives) {
                    const buckets = {
                        EDM: [],
                        APO: [],
                        BAI: [],
                        DSS: [],
                        MEA: [],
                        others: []
                    };

                    objectives.forEach(obj => {
                        const prefix = (String(obj.objective_id || '').match(/^[A-Za-z]+/) || [''])[0]
                            .toUpperCase();
                        if (CONFIG.PREFERRED_ORDER.includes(prefix)) {
                            buckets[prefix].push(obj);
                        } else {
                            buckets.others.push(obj);
                        }
                    });

                    return buckets;
                },

                flattenBuckets(buckets) {
                    const flattened = [];

                    CONFIG.PREFERRED_ORDER.forEach(key => {
                        buckets[key].forEach(obj => flattened.push(obj));
                    });

                    buckets.others
                        .sort((a, b) => (a.objective_id || '').localeCompare(b.objective_id || ''))
                        .forEach(obj => flattened.push(obj));

                    return flattened;
                },

                renderSingleObjectiveCard(obj) {
                    const domainLabel = Utils.escapeHtml(
                        obj.domain_display ||
                        (obj.domains?.[0]?.area || obj.domains?.[0]?.name) ||
                        ''
                    );

                    const domainMap = {
                        'EDM': 'Evaluate, Direct and Monitor',
                        'APO': 'Align, Plan and Organize',
                        'BAI': 'Build, Acquire and Implement',
                        'DSS': 'Deliver, Service and Support',
                        'MEA': 'Monitor, Evaluate and Assess'
                    };

                    const code = obj.objective_id?.substring(0, 3) || '';
                    const name = Utils.escapeHtml(domainMap[code] || 'Unknown Domain');

                    const mgmtTitle =
                        `${Utils.escapeHtml(Utils.displayObjectiveId(obj.objective_id || ''))} — ${Utils.formatText(obj.objective || '')}`;
                    const focusAreaTheme = Utils.focusAreaTheme(obj.focus_area || obj.focusArea);
                    const focus = Utils.escapeHtml(Utils.displayFocusArea(obj.focus_area || obj.focusArea));

                    const egListHtml = this.renderGoalsList(obj.entergoals, 'entergoals_id');
                    const agListHtml = this.renderGoalsList(obj.aligngoals, 'aligngoals_id');
                    const egMetricsHtml = this.renderMetrics(obj.entergoals, 'entergoals_id', 'entergoalsmetr');
                    const agMetricsHtml = this.renderMetrics(obj.aligngoals, 'aligngoals_id', 'aligngoalsmetr');

                    return `
    <div style="border:1px solid #bdbdbd;border-radius:4px;overflow:hidden;font-family:Helvetica,Arial,sans-serif;background:#fff;margin-bottom:1.25rem;">
      <!-- header -->
      <div style="display:flex;align-items:stretch;border-bottom:1px solid #e6e6e6;height:64px;">
        <div style="flex:1;background:${focusAreaTheme.headerBg};color:#fff;padding:10px 14px;display:flex;flex-direction:column;justify-content:center;">
          <div style="font-size:15px;font-weight:700;letter-spacing:0.2px;">Domain: ${name}  </div>
          <div style="margin-top:6px;font-size:14px;font-weight:700;">${domainLabel} Objective: ${mgmtTitle}</div>
        </div>
        <div style="width:320px;background:${focusAreaTheme.headerBg};color:#fff;display:flex;align-items:center;justify-content:center;padding:8px;border-left:4px solid #fff;">
          <div style="text-align:center;font-weight:700;font-size:13px;">${focus}</div>
        </div>
      </div>

      <!-- body -->
      <div style="padding:14px;color:#222;font-size:13px;">
        <div style="background:#f6f7f9;border:1px solid #d7dbe0;padding:10px 12px;margin-bottom:10px;border-radius:2px;">
          <div class="fs-5" style="font-weight:700;margin-bottom:6px;">Description</div>
          <div class="medium">${Utils.formatText(obj.objective_description || '')}</div>
        </div>

        <div style="background:#f6f7f9;border:1px solid #d7dbe0;padding:10px 12px;margin-bottom:10px;border-radius:2px;">
          <div class="fs-5" style="font-weight:700;margin-bottom:6px;">Purpose</div>
          <div class="medium">${Utils.formatText(obj.objective_purpose || '')}</div>
        </div>

        <!-- goals row -->
        <div style="display:flex;gap:12px;margin-top:8px;flex-wrap:wrap;">
          <div style="flex:1;min-width:260px;border:1px solid #dcdcdc;padding:10px;background:#fff;min-height:140px;">
            <div style="font-weight:700;background:#eef2f6;padding:6px 8px;border:1px solid #d6dbe0;margin:-10px -10px 10px -10px;font-size:13px;">Enterprise Goals</div>
            <div style="margin-top:6px;font-size:13px;color:#333;">${egListHtml}</div>
          </div>

          <div style="width:56px;display:flex;align-items:center;justify-content:center;">
            <div style="display:inline-block;width:26px;height:26px;border-radius:3px;background:#eef2f6;border:1px solid #d6dbe0;color:#2d4b63;font-weight:700;text-align:center;line-height:26px;">→</div>
          </div>

          <div style="flex:1;min-width:260px;border:1px solid #dcdcdc;padding:10px;background:#fff;min-height:140px;">
            <div style="font-weight:700;background:#eef2f6;padding:6px 8px;border:1px solid #d6dbe0;margin:-10px -10px 10px -10px;font-size:13px;">Alignment Goals</div>
            <div style="margin-top:6px;font-size:13px;color:#333;">${agListHtml}</div>
          </div>
        </div>

        <!-- metrics row -->
        <div style="display:flex;gap:12px;margin-top:14px;flex-wrap:wrap;">
          <div style="flex:1;min-width:260px;border:1px solid #dcdcdc;padding:10px;background:#fff;">
            <div style="font-weight:700;background:#eef2f6;padding:6px 8px;border:1px solid #d6dbe0;margin:-10px -10px 10px -10px;font-size:13px;">Example Metrics for Enterprise Goals</div>
            <div class= " medium " style="margin-top:6px;font-size:15px;color:#333;">${egMetricsHtml}</div>
          </div>

          <div style="width:56px;display:flex;align-items:flex-start;justify-content:center;margin-top:6px;">
            <div style="display:inline-block;width:26px;height:26px;border-radius:3px;background:#eef2f6;border:1px solid #d6dbe0;color:#2d4b63;font-weight:700;text-align:center;line-height:26px;"> </div>
          </div>

          <div style="flex:1;min-width:260px;border:1px solid #dcdcdc;padding:10px;background:#fff;">
            <div style="font-weight:700;background:#eef2f6;padding:6px 8px;border:1px solid #d6dbe0;margin:-10px -10px 10px -10px;font-size:13px;">Example Metrics for Alignment Goals</div>
            <div style="margin-top:6px;font-size:19;color:#333;">${agMetricsHtml}</div>
          </div>
        </div>
      </div>
    </div>
  `;
                },

                renderGoalsList(goals, idField) {
                    if (!goals?.length) {
                        return '<div class="text-muted small">(no goals)</div>';
                    }

                    return goals.map(goal => {
                        const displayId = goal[idField] ? Utils.displayObjectiveId(goal[idField]) : '';
                        const text = displayId + (goal.description ? ': ' + goal.description : '');
                        return `
        <div class="mb-2">
          <div class="fw-semibold">${Utils.formatText(text)}</div>
        </div>
      `;
                    }).join('');
                },

                renderMetrics(goals, idField, metricsField) {
                    if (!goals?.length) {
                        return '<div class="text-muted small">(no example metrics)</div>';
                    }

                    const html = goals.map(goal => {
                        const metrics = (goal[metricsField] || [])
                            .map(m => m.description || '')
                            .filter(Boolean);

                        if (!metrics.length) return '';

                        return `
          <div class="mb-3">
            <div class="fw-semibold mb-1">${Utils.escapeHtml(Utils.displayObjectiveId(goal[idField] || ''))}</div>
            <ul class="ps-3 mb-0 small text-muted">
              ${metrics.map(m => `<li class="mb-1">${Utils.formatText(m)}</li>`).join('')}
            </ul>
          </div>
        `;
                    }).join('');

                    return html || '<div class="text-muted small">(no example metrics)</div>';
                },

                // --- GANTI renderPractices ---
                renderPractices(objectives) {
                    if (!Array.isArray(objectives) || !objectives.length) {
                        return '<div class="text-muted">No practices found.</div>';
                    }

                    return objectives.map(obj => {
                        // Build summary per practice for this objective
                        const practiceSummaries = (obj.practices || []).map(practice => {
                            const levelCounts = {
                                '2': 0,
                                '3': 0,
                                '4': 0,
                                '5': 0,
                                other: 0
                            };
                            (practice.activities || []).forEach(ac => {
                                const raw = ac.capability_lvl ?? ac.capability_level ?? ac
                                    .level ?? '';
                                const s = String(raw).trim();
                                const m = s.match(/(\d+)/);
                                if (m) {
                                    const num = m[1];
                                    if (['2', '3', '4', '5'].includes(num)) {
                                        levelCounts[num] = (levelCounts[num] || 0) + 1;
                                    } else {
                                        levelCounts.other = (levelCounts.other || 0) + 1;
                                    }
                                } else {
                                    // treat empty / non-numeric as other
                                    levelCounts.other = (levelCounts.other || 0) + 1;
                                }
                            });
                            const total = levelCounts['2'] + levelCounts['3'] + levelCounts['4'] +
                                levelCounts['5'] + levelCounts.other;
                            return {
                                practice_id: practice.practice_id || '',
                                practice_name: practice.practice_name || '',
                                counts: levelCounts,
                                total
                            };
                        });


                        const safeObjId = Utils.idify(obj.objective_id || obj.objective || 'obj');
                        // compute totals for each level and overall
                        const totals = (practiceSummaries || []).reduce((acc, ps) => {
                            acc['2'] += Number(ps.counts['2'] || 0);
                            acc['3'] += Number(ps.counts['3'] || 0);
                            acc['4'] += Number(ps.counts['4'] || 0);
                            acc['5'] += Number(ps.counts['5'] || 0);
                            acc.total += Number(ps.total || 0);
                            return acc;
                        }, {
                            '2': 0,
                            '3': 0,
                            '4': 0,
                            '5': 0,
                            total: 0
                        });

                        const summaryTableHtml = (practiceSummaries.length) ?
                            `
        <div class="accordion mb-3" id="practicesSummaryAccordion_${safeObjId}">
          <div class="accordion-item">
            <h2 class="accordion-header" id="practicesSummaryHeading_${safeObjId}">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#practicesSummaryCollapse_${safeObjId}" aria-expanded="false" aria-controls="practicesSummaryCollapse_${safeObjId}">
                Practice summary 
              </button>
            </h2>
            <div id="practicesSummaryCollapse_${safeObjId}" class="accordion-collapse collapse" aria-labelledby="practicesSummaryHeading_${safeObjId}" data-bs-parent="#practicesSummaryAccordion_${safeObjId}">
              <div class="accordion-body p-0">
                <div class="table-responsive">
                  <table class="table table-sm table-bordered mb-0" style="min-width:640px;">
                    <thead class="table-info medium text-uppercase text-center">
                      <tr>
                        <th rowspan="2" style="min-width:200px">Practice</th>
                        <th class="text-center" colspan="4">Total of Activities</th>
                        <th rowspan="2" class="text-center" style="width:70px">Total</th>
                      </tr>
                      <tr>
                        <th class="text-center" style="width:70px">Lv 2</th>
                        <th class="text-center" style="width:70px">Lv 3</th>
                        <th class="text-center" style="width:70px">Lv 4</th>
                        <th class="text-center" style="width:70px">Lv 5</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${practiceSummaries.map(ps => `
                                <tr>
                                  <td class="small fw-bold">${Utils.escapeHtml(Utils.displayObjectiveId(ps.practice_id || ''))}${ps.practice_name ? ' — ' + Utils.escapeHtml(ps.practice_name) : ''}</td>
                                  <td class="text-center small">${(ps.counts['2'] || 0) ? Utils.formatText(String(ps.counts['2'])) : '-'}</td>
                                  <td class="text-center small">${(ps.counts['3'] || 0) ? Utils.formatText(String(ps.counts['3'])) : '-'}</td>
                                  <td class="text-center small">${(ps.counts['4'] || 0) ? Utils.formatText(String(ps.counts['4'])) : '-'}</td>
                                  <td class="text-center small">${(ps.counts['5'] || 0) ? Utils.formatText(String(ps.counts['5'])) : '-'}</td>
                                  <td class="text-center small">${(ps.total || 0) ? Utils.formatText(String(ps.total)) : '-'}</td>
                                </tr>
                              `).join('')}
                    </tbody>
                    <tfoot>
                      <tr class="table-warning fw-bold">
                        <td class="small text-end">Total</td>
                        <td class="text-center small">${totals['2'] ? Utils.formatText(String(totals['2'])) : '-'}</td>
                        <td class="text-center small">${totals['3'] ? Utils.formatText(String(totals['3'])) : '-'}</td>
                        <td class="text-center small">${totals['4'] ? Utils.formatText(String(totals['4'])) : '-'}</td>
                        <td class="text-center small">${totals['5'] ? Utils.formatText(String(totals['5'])) : '-'}</td>
                        <td class="text-center small">${totals.total ? Utils.formatText(String(totals.total)) : '-'}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      ` :
                            '';

                        let html =
                            `<h4 class="mb-3">${Utils.escapeHtml(Utils.displayObjectiveId(obj.objective_id))} — ${Utils.formatText(obj.objective || '')}</h4>`;
                        html += summaryTableHtml;

                        (obj.practices || []).forEach(practice => {
                            html += this.renderSinglePractice(practice);
                        });

                        return html;
                    }).join('');
                },

                // --- GANTI renderSinglePractice (hapus ringkasan per-practice di dalamnya) ---
                renderSinglePractice(practice) {
                    let metricsContentHtml = '';
                    if (STATE.inputMode) {
                        const listHtml = (practice.practicemetr || [])
                            .map((m, i) => {
                                const labelChar = String.fromCharCode(97 + i);
                                return `
                                    <div class="d-flex align-items-start gap-2 mb-2 js-practice-metric-item" data-metric-id="${m.id}">
                                        <span class="mt-1 fw-semibold small text-muted" style="width: 20px;">${labelChar}.</span>
                                        <textarea class="form-control form-control-sm js-practice-metric-desc" rows="1" style="resize: vertical; font-size: 13px;">${Utils.escapeHtml(m.description || '')}</textarea>
                                        <button type="button" class="btn btn-sm btn-primary py-0 px-2 js-save-practice-metric" title="Simpan Metric"><i class="bi bi-check-lg"></i></button>
                                        <button type="button" class="btn btn-sm btn-outline-danger py-0 px-2 js-delete-practice-metric" title="Hapus Metric"><i class="bi bi-trash"></i></button>
                                    </div>
                                `;
                            })
                            .join('');

                        metricsContentHtml = `
                            <div class="fw-bold mb-2 small text-secondary text-uppercase" style="font-size: 11px; letter-spacing: 0.05em;">Example Metrics Editor</div>
                            <div class="js-practice-metrics-list" data-practice-id="${Utils.escapeHtml(practice.practice_id || '')}">
                                ${listHtml}
                            </div>
                            <div class="mt-2 text-end">
                                <button type="button" class="btn btn-sm btn-outline-success py-1 px-3 js-add-practice-metric" data-practice-id="${Utils.escapeHtml(practice.practice_id || '')}">
                                    <i class="bi bi-plus-circle"></i> + Tambah Metric
                                </button>
                            </div>
                        `;
                    } else {
                        const listHtml = (practice.practicemetr || [])
                            .map((m, i) =>
                                `<li class="mb-1">${String.fromCharCode(97 + i)}. ${Utils.formatText(m.description || '')}</li>`
                            )
                            .join('');
                        metricsContentHtml = listHtml ? `<ul class="mb-0 small ps-3">${listHtml}</ul>` : '<div class="text-muted small ps-2">(no example metrics)</div>';
                    }

                    const _acts = (practice.activities || []).map((ac, i) => ({
                        idx: i + 1,
                        desc: ac.description || ac.activity || '',
                        level: (ac.capability_lvl ?? ac.capability_level ?? ac.level ?? '') || '-'
                    }));

                    const rowspanMap = {}; // map 0-based index -> rowspan
                    for (let i = 0; i < _acts.length;) {
                        const lvl = _acts[i].level;
                        let j = i + 1;
                        while (j < _acts.length && _acts[j].level === lvl) j++;
                        const span = j - i;
                        if (span > 1) rowspanMap[i] = span;
                        i = j;
                    }

                    const activitiesHtml = _acts.map((a, i) => {
                        const noCell =
                            `<td class="text-center" style="width:auto; white-space:nowrap;">${a.idx}</td>`;
                        const activityCell =
                            `<td style="width:95%;">${Utils.formatText(a.desc || '')}</td>`;
                        let levelCell = '';
                        if (rowspanMap[i]) {
                            levelCell =
                                `<td class="text-center fw-semibold" style="width:5%;" rowspan="${rowspanMap[i]}">${Utils.formatText(String(a.level || '-'))}</td>`;
                        } else {
                            let covered = false;
                            for (const startStr of Object.keys(rowspanMap)) {
                                const start = parseInt(startStr, 10);
                                const span = rowspanMap[start];
                                if (i > start && i < start + span) {
                                    covered = true;
                                    break;
                                }
                            }
                            if (!covered) {
                                levelCell =
                                    `<td class="text-center fw-semibold" style="width:5%;">${Utils.formatText(String(a.level || '-'))}</td>`;
                            }
                        }

                        return `
      <tr>
        ${noCell}
        ${activityCell}
        ${levelCell}
      </tr>
    `;
                    }).join('');

                    const guidancesHtml = (practice.guidances || []).length ?
                        (practice.guidances || []).map(gd => `
        <tr>
          <td style="width:65%;">${Utils.formatText(gd.guidance || '')}</td>
          <td style="width:35%;">${Utils.formatText(gd.reference || '')}</td>
        </tr>
      `).join('') :
                        '<tr><td colspan="2" class="text-muted text-center py-2">No related guidance for this management practice</td></tr>';

                    return `
    <div class="card mb-4 shadow-sm border-secondary-subtle" style="font-size:14px; line-height:1.4;">
      <div class="card-header text-white fw-bold py-2 px-3" style="background-color:#1a3665;">
        A. Component: Process
      </div>

      <div class="d-flex fw-bold text-white" style="background-color:#7a2433; font-size:14px;">
        <div class="flex-fill p-2 border-end border-light text-center" style="width:50%;">Management Practice</div>
        <div class="flex-fill p-2 text-center" style="width:50%;">Example Metrics</div>
      </div>

      <div class="d-flex border border-top-0 border-secondary-subtle">
        <div class="flex-fill p-3 border-end border-secondary-subtle" style="width:50%; vertical-align:top;">
          <div class="fw-bold mb-1 d-flex justify-content-between align-items-center">
            <span>${Utils.escapeHtml(Utils.displayObjectiveId(practice.practice_id || ''))} ${Utils.escapeHtml(practice.practice_name || '')}</span>
            ${STATE.inputMode ? `<button type="button" class="btn btn-sm btn-outline-danger py-0 px-2 js-delete-practice" data-practice-id="${Utils.escapeHtml(practice.practice_id || '')}"><i class="bi bi-trash"></i> Hapus Practice</button>` : ''}
          </div>
          <div>${Utils.formatText(practice.practice_description || '')}</div>
        </div>
        <div class="flex-fill p-3 bg-light" style="width:50%;">
          ${metricsContentHtml}
        </div>
      </div>

      <div class="fw-bold p-2 text-dark border-top border-secondary-subtle" style="background-color:#d4d7eb;">Activities</div>
      <div class="table-responsive">
        <table class="table table-sm table-bordered border-secondary-subtle mb-0 align-middle">
          <thead style="background-color:#f7f7f7;">
            <tr>
              <th class="text-center" style="width:5%;">NO</th>  
              <th style="width:80%;">Activity</th>
              <th class="text-center" style="width:20%;">Capability Level</th>
            </tr>
          </thead>
          <tbody>${activitiesHtml}</tbody>
        </table>
      </div>

      <div class="fw-bold text-dark border-top border-secondary-subtle d-flex" style="background-color:#c8c2c2;">
        <div class="flex-fill p-2 border-end border-secondary-subtle" style="width:65%;">
          Related Guidance (Standards, Frameworks, Compliance Requirements)
        </div>
        <div class="p-2 text-center" style="width:35%;">Detailed Reference</div>
      </div>
      <div class="table-responsive">
        <table class="table table-sm table-bordered border-secondary-subtle mb-0 align-middle">
          <tbody>${guidancesHtml}</tbody>
        </table>
      </div>
    </div>
  `;
                },


                renderInfoflows(objectives) {
                    const rows = [];

                    objectives.forEach(obj => {
                        (obj.practices || []).forEach(practice => {
                            const inputs = practice.infoflowinput || [];

                            if (!inputs.length) {
                                rows.push({
                                    gamo: obj.objective_id || '',
                                    practice: `${practice.practice_id || ''} ${practice.practice_name || ''}`
                                        .trim(),
                                    practiceId: practice.practice_id || '',
                                    inputId: null,
                                    outputId: null,
                                    from: '',
                                    input: '',
                                    output: '',
                                    to: '',
                                    isNoInputRow: true,
                                    showForm: STATE.inputMode ? !!STATE.showCreateRowForPractice[practice.practice_id] : false
                                });
                                return;
                            }

                            inputs.forEach(inp => {
                                const outputs = inp.connectedoutputs || [];

                                if (outputs.length) {
                                    outputs.forEach(out => {
                                        rows.push({
                                            gamo: obj.objective_id || '',
                                            practice: `${practice.practice_id || ''} ${practice.practice_name || ''}`
                                                .trim(),
                                            practiceId: inp.practice_id || practice.practice_id || '',
                                            inputId: inp.input_id || null,
                                            outputId: out.output_id || null,
                                            from: inp.from || '',
                                            input: inp.description || '',
                                            output: out.description || '',
                                            to: out.to || '',
                                            isNoInputRow: false
                                        });
                                    });
                                } else {
                                    rows.push({
                                        gamo: obj.objective_id || '',
                                        practice: `${practice.practice_id || ''} ${practice.practice_name || ''}`
                                            .trim(),
                                        practiceId: inp.practice_id || practice.practice_id || '',
                                        inputId: inp.input_id || null,
                                        outputId: null,
                                        from: inp.from || '',
                                        input: inp.description || '',
                                        output: '',
                                        to: '',
                                        isNoInputRow: false
                                    });
                                }
                            });

                            if (STATE.inputMode) {
                                rows.push({
                                    gamo: obj.objective_id || '',
                                    practice: `${practice.practice_id || ''} ${practice.practice_name || ''}`
                                        .trim(),
                                    practiceId: practice.practice_id || '',
                                    inputId: null,
                                    outputId: null,
                                    from: '',
                                    input: '',
                                    output: '',
                                    to: '',
                                    isNoInputRow: true,
                                    showForm: !!STATE.showCreateRowForPractice[practice.practice_id]
                                });
                            }
                        });
                    });

                    if (!rows.length) {
                        return '<div class="text-muted">No information flows found.</div>';
                    }

                    const practiceRowspanMap = {};

                    for (let i = 0; i < rows.length;) {
                        const currentPracticeId = rows[i].practiceId;
                        let j = i + 1;
                        while (j < rows.length && rows[j].practiceId === currentPracticeId) {
                            j++;
                        }
                        practiceRowspanMap[i] = j - i;
                        i = j;
                    }

                    const editable = STATE.inputMode;
                    const editHint = editable ?
                        `<div class="alert alert-warning py-2 px-3 small mb-2">Input Mode aktif. Anda bisa edit data lama atau tambah data baru pada baris yang kosong, lalu klik <strong>Simpan/Tambah</strong> per baris.</div>` :
                        '';

                    const actionHeader = editable ? '<th style="width:120px">Action</th>' : '';
                    const escapeAttr = (value) => String(value ?? '')
                        .replaceAll('&', '&amp;')
                        .replaceAll('"', '&quot;')
                        .replaceAll('<', '&lt;')
                        .replaceAll('>', '&gt;');
                    const escapeTextarea = (value) => String(value ?? '')
                        .replaceAll('&', '&amp;')
                        .replaceAll('<', '&lt;')
                        .replaceAll('>', '&gt;');

                    const tbody = rows.map((r, rowIndex) => {
                        const practiceCell = practiceRowspanMap[rowIndex] ? 
                            `<td class="small align-middle" rowspan="${practiceRowspanMap[rowIndex]}">${Utils.formatText(r.practice)}</td>` : '';

                        if (!editable) {
                            const inputText = r.inputId ?
                                (r.input || '') :
                                '(No information flows)';
                            const outputText = r.outputId ?
                                (r.output || '') :
                                (r.inputId ? '(No Output)' : '');

                            return `
        <tr>
          ${practiceCell}
          <td class="small">${Utils.formatText(r.from)}</td>
          <td class="small">${Utils.formatText(inputText)}</td>
          <td class="small">${Utils.formatText(outputText)}</td>
          <td class="small">${Utils.formatText(r.to)}</td>
        </tr>
      `;
                        }

                         if (r.isNoInputRow && !r.showForm) {
                            return `
      <tr class="js-infoflow-row" data-row-index="${rowIndex}">
        ${practiceCell}
        <td colspan="4" class="text-center py-2 bg-light align-middle">
          <button type="button" class="btn btn-xs btn-outline-success js-trigger-add-infoflow" data-practice-id="${escapeAttr(r.practiceId)}" style="font-size: 12px; padding: 2px 10px;">
            <i class="bi bi-plus-circle"></i> + Tambah Alur Informasi
          </button>
        </td>
        <td class="small text-center align-middle"></td>
      </tr>
    `;
                        }

                        const canCreateInput = !r.inputId && Boolean(r.practiceId);
                        const hasInputContext = Boolean(r.inputId) || canCreateInput;
                        const canCreateOrUpdateOutput = hasInputContext;

                        const fromEditor = hasInputContext ?
                            `<input type="text" list="practices-list" class="form-control form-control-sm infoflow-edit-control js-infoflow-field" data-field="from" value="${escapeAttr(r.from || '')}" placeholder="Ketik/Pilih...">` :
                            `<span class="small text-muted">-</span>`;

                        const inputEditor = hasInputContext ?
                            `<textarea class="form-control form-control-sm infoflow-edit-control textarea js-infoflow-field" data-field="input_description">${escapeTextarea(r.input || '')}</textarea>` :
                            `<span class="small text-muted">${Utils.formatText(r.input || '(No information flows)')}</span>`;

                        const outputEditor = canCreateOrUpdateOutput ?
                            `<textarea class="form-control form-control-sm infoflow-edit-control textarea js-infoflow-field" data-field="output_description">${escapeTextarea(r.output || '')}</textarea>` :
                            `<span class="small text-muted">${Utils.formatText(r.output || '(No Output)')}</span>`;

                        const toEditor = canCreateOrUpdateOutput ?
                            `
                            <div class="position-relative w-100">
                                <input type="text" 
                                       class="form-control form-control-sm infoflow-edit-control js-infoflow-field js-to-input" 
                                       data-field="to" 
                                       value="${escapeAttr(r.to || '')}" 
                                       placeholder="Pilih Practice..." 
                                       readonly 
                                       style="cursor: pointer; background-color: #fff; padding-right: 25px;">
                                <span class="position-absolute end-0 top-50 translate-middle-y me-2 pointer-events-none text-muted" style="font-size: 10px;">
                                    <i class="bi bi-chevron-down"></i>
                                </span>
                            </div>
                            ` :
                            `<span class="small text-muted">${Utils.formatText(r.to || '-')}</span>`;

                        let actionCell = `<button type="button" class="btn btn-sm btn-outline-secondary" disabled>Practice tidak valid</button>`;

                        if (hasInputContext) {
                            const buttonLabel = r.inputId ? 'Simpan' : 'Tambah';
                            let cancelButton = '';
                            if (!r.inputId) {
                                cancelButton = `<button type="button" class="btn btn-sm btn-outline-secondary ms-1 js-cancel-add-infoflow" data-practice-id="${escapeAttr(r.practiceId)}">Batal</button>`;
                            }
                            let deleteButton = '';
                            if (r.inputId || r.outputId) {
                                deleteButton = `<button type="button" class="btn btn-sm btn-danger ms-1 js-delete-infoflow-row" data-input-id="${escapeAttr(r.inputId || '')}" data-output-id="${escapeAttr(r.outputId || '')}">Hapus</button>`;
                            }
                            actionCell =
                                `<button type="button" class="btn btn-sm btn-primary js-save-infoflow-row" data-input-id="${escapeAttr(r.inputId || '')}" data-output-id="${escapeAttr(r.outputId || '')}" data-practice-id="${escapeAttr(r.practiceId || '')}" data-row-index="${rowIndex}" data-create-mode="${canCreateInput ? '1' : '0'}">${buttonLabel}</button>${deleteButton}${cancelButton}`;
                        }

                        return `
      <tr class="js-infoflow-row" data-row-index="${rowIndex}">
        ${practiceCell}
        <td class="small">${fromEditor}</td>
        <td class="small">${inputEditor}</td>
        <td class="small">${outputEditor}</td>
        <td class="small">${toEditor}</td>
        <td class="small text-center">${actionCell}</td>
      </tr>
    `;
                    }).join('');

                    return `
        ${editHint}
        <datalist id="practices-list">
          <option value="Outside COBIT">
          <option value="All APO">
          <option value="All BAI">
          <option value="All DSS">
          <option value="All MEA">
          ${(MASTER_DATA.practices || []).map(p => `<option value="${escapeAttr(p.practice_id)}">`).join('')}
        </datalist>
        <div class="table-responsive mb-3">
          <table class="table table-sm table-bordered table-striped mb-0" style="table-layout:fixed;width:100%">
            <thead class="table-primary text-white">
              <tr>
                <th>Management Practice</th>
                <th>From</th>
                <th>Input Description</th>
                <th>Output Description</th>
                <th>To</th>
                ${actionHeader}
              </tr>
            </thead>
            <tbody>${tbody}</tbody>
          </table>
        </div>
      `;
                },

                renderPolicies(objectives) {
                    const rows = [];

                    objectives.forEach(obj => {
                        (obj.policies || []).forEach(policy => {
                            const guidances = policy.guidances || [];

                            if (STATE.inputMode) {
                                if (guidances.length) {
                                    guidances.forEach(g => {
                                        rows.push({
                                            gamo: obj.objective_id || '',
                                            objectiveId: obj.objective_id || '',
                                            policyId: policy.policy_id || null,
                                            policy: policy.policy || policy.name || '',
                                            desc: policy.description || '',
                                            guidanceId: g.guidance_id || null,
                                            guidance: g.guidance || '',
                                            reference: g.reference || '',
                                            isCreateRow: false
                                        });
                                    });

                                    rows.push({
                                        gamo: obj.objective_id || '',
                                        objectiveId: obj.objective_id || '',
                                        policyId: policy.policy_id || null,
                                        policy: policy.policy || policy.name || '',
                                        desc: policy.description || '',
                                        guidanceId: null,
                                        guidance: '',
                                        reference: '',
                                        isCreateRow: false
                                    });
                                } else {
                                    rows.push({
                                        gamo: obj.objective_id || '',
                                        objectiveId: obj.objective_id || '',
                                        policyId: policy.policy_id || null,
                                        policy: policy.policy || policy.name || '',
                                        desc: policy.description || '',
                                        guidanceId: null,
                                        guidance: '',
                                        reference: '',
                                        isCreateRow: false
                                    });
                                }
                            } else {
                                const guidance = guidances
                                    .map(g => g.guidance)
                                    .filter(Boolean)
                                    .join('<br>');

                                const refs = guidances
                                    .map(g => g.reference)
                                    .filter(Boolean)
                                    .join('<br>');

                                rows.push({
                                    gamo: obj.objective_id || '',
                                    objectiveId: obj.objective_id || '',
                                    policyId: policy.policy_id || null,
                                    policy: policy.policy || policy.name || '',
                                    desc: policy.description || '',
                                    guidance,
                                    refs,
                                    isCreateRow: false
                                });
                            }
                        });

                        if (STATE.inputMode) {
                            rows.push({
                                gamo: obj.objective_id || '',
                                objectiveId: obj.objective_id || '',
                                policyId: null,
                                policy: '',
                                desc: '',
                                guidanceId: null,
                                guidance: '',
                                reference: '',
                                isCreateRow: true
                            });
                        }
                    });

                    if (!rows.length) {
                        return '<div class="text-muted">No policies / procedures found.</div>';
                    }

                    const editable = STATE.inputMode;
                    const actionHeader = editable ? '<th style="width:120px">Action</th>' : '';
                    const modeHint = editable ?
                        `<div class="alert alert-warning py-2 px-3 small mb-2">Input Mode aktif. Anda bisa edit policy yang ada atau tambah policy baru per objective.</div>` :
                        '';

                    const tbody = rows.map(r => {
                        if (!editable) {
                            return `
        <tr>
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">${Utils.formatText(r.policy)}</td>
          <td class="small">${Utils.formatText(r.desc)}</td>
          <td class="small">${r.guidance}</td>
          <td class="small">${r.refs}</td>
        </tr>
      `;
                        }

                        const label = r.policyId ? (r.guidanceId ? 'Simpan' : 'Tambah Guidance') : 'Tambah';
                        return `
        <tr class="js-entity-row" data-entity-type="policy">
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="policy">${Renderers.escapeTextarea(r.policy || '')}</textarea>
          </td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="description">${Renderers.escapeTextarea(r.desc || '')}</textarea>
          </td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="guidance">${Renderers.escapeTextarea(r.guidance || '')}</textarea>
          </td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="reference">${Renderers.escapeTextarea(r.reference || '')}</textarea>
          </td>
          <td class="small text-center">
            <button type="button" class="btn btn-sm btn-primary js-save-entity-row" data-entity-type="policy" data-entity-id="${Renderers.escapeAttr(r.policyId || '')}" data-guidance-id="${Renderers.escapeAttr(r.guidanceId || '')}" data-objective-id="${Renderers.escapeAttr(r.objectiveId || '')}">${label}</button>
          </td>
        </tr>
      `;
                    }).join('');

                    return `
        ${modeHint}
        <div class="table-responsive mb-3">
          <table class="table table-sm table-bordered table-striped mb-0" style="table-layout:fixed;width:100%">
            <thead class="table-primary text-white">
              <tr>
                <th style="width:110px">GAMO</th>
                <th>Policy</th>
                <th>Description</th>
                <th>Related Guidance</th>
                <th>Reference</th>
                ${actionHeader}
              </tr>
            </thead>
            <tbody>${tbody}</tbody>
          </table>
        </div>
      `;
                },

                renderSkills(objectives) {
                    const rows = [];

                    objectives.forEach(obj => {
                        (obj.skill || []).forEach(skill => {
                            const guidances = skill.guidances || [];

                            if (STATE.inputMode) {
                                if (guidances.length) {
                                    guidances.forEach(g => {
                                        rows.push({
                                            gamo: obj.objective_id || '',
                                            objectiveId: obj.objective_id || '',
                                            skillId: skill.skill_id || null,
                                            skill: skill.skill || '',
                                            guidanceId: g.guidance_id || null,
                                            guidance: g.guidance || '',
                                            reference: g.reference || '',
                                            isCreateRow: false
                                        });
                                    });

                                    rows.push({
                                        gamo: obj.objective_id || '',
                                        objectiveId: obj.objective_id || '',
                                        skillId: skill.skill_id || null,
                                        skill: skill.skill || '',
                                        guidanceId: null,
                                        guidance: '',
                                        reference: '',
                                        isCreateRow: false
                                    });
                                } else {
                                    rows.push({
                                        gamo: obj.objective_id || '',
                                        objectiveId: obj.objective_id || '',
                                        skillId: skill.skill_id || null,
                                        skill: skill.skill || '',
                                        guidanceId: null,
                                        guidance: '',
                                        reference: '',
                                        isCreateRow: false
                                    });
                                }
                            } else {
                                const guidance = guidances
                                    .map(g => g.guidance)
                                    .filter(Boolean)
                                    .join('<br>');

                                const refs = guidances
                                    .map(g => g.reference)
                                    .filter(Boolean)
                                    .join('<br>');

                                rows.push({
                                    gamo: obj.objective_id || '',
                                    objectiveId: obj.objective_id || '',
                                    skillId: skill.skill_id || null,
                                    skill: skill.skill || '',
                                    guidance,
                                    refs,
                                    isCreateRow: false
                                });
                            }
                        });

                        if (STATE.inputMode) {
                            rows.push({
                                gamo: obj.objective_id || '',
                                objectiveId: obj.objective_id || '',
                                skillId: null,
                                skill: '',
                                guidanceId: null,
                                guidance: '',
                                reference: '',
                                isCreateRow: true
                            });
                        }
                    });

                    if (!rows.length) {
                        return '<div class="text-muted">No skills found.</div>';
                    }

                    const editable = STATE.inputMode;
                    const actionHeader = editable ? '<th style="width:120px">Action</th>' : '';
                    const modeHint = editable ?
                        `<div class="alert alert-warning py-2 px-3 small mb-2">Input Mode aktif. Anda bisa edit skill yang ada atau tambah skill baru per objective.</div>` :
                        '';

                    const tbody = rows.map(r => {
                        if (!editable) {
                            return `
        <tr>
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">${Utils.formatText(r.skill)}</td>
          <td class="small">${r.guidance}</td>
          <td class="small">${r.refs}</td>
        </tr>
      `;
                        }

                        const label = r.skillId ? (r.guidanceId ? 'Simpan' : 'Tambah Guidance') : 'Tambah';
                        return `
        <tr class="js-entity-row" data-entity-type="skill">
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">
            <input type="text" class="form-control form-control-sm infoflow-edit-control js-entity-field" data-field="skill" value="${Renderers.escapeAttr(r.skill || '')}">
          </td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="guidance">${Renderers.escapeTextarea(r.guidance || '')}</textarea>
          </td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="reference">${Renderers.escapeTextarea(r.reference || '')}</textarea>
          </td>
          <td class="small text-center">
            <button type="button" class="btn btn-sm btn-primary js-save-entity-row" data-entity-type="skill" data-entity-id="${Renderers.escapeAttr(r.skillId || '')}" data-guidance-id="${Renderers.escapeAttr(r.guidanceId || '')}" data-objective-id="${Renderers.escapeAttr(r.objectiveId || '')}">${label}</button>
          </td>
        </tr>
      `;
                    }).join('');

                    return `
        ${modeHint}
        <div class="table-responsive mb-3">
          <table class="table table-sm table-bordered table-striped mb-0" style="table-layout:fixed;width:100%">
            <thead class="table-primary text-white">
              <tr>
                <th style="width:110px">GAMO</th>
                <th>Skill</th>
                <th>Related Guidance (Standards, Frameworks, Compliance Requirements)</th>
                <th>Detailed Reference</th>
                ${actionHeader}
              </tr>
            </thead>
            <tbody>${tbody}</tbody>
          </table>
        </div>
      `;
                },

                renderCulture(objectives) {
                    const rows = [];

                    objectives.forEach(obj => {
                        (obj.keyculture || []).forEach(culture => {
                            const guidances = culture.guidances || [];

                            if (STATE.inputMode) {
                                if (guidances.length) {
                                    guidances.forEach(g => {
                                        rows.push({
                                            gamo: obj.objective_id || '',
                                            objectiveId: obj.objective_id || '',
                                            keyCultureId: culture.keyculture_id || null,
                                            element: culture.element || '',
                                            guidanceId: g.guidance_id || null,
                                            guidance: g.guidance || '',
                                            reference: g.reference || '',
                                            isCreateRow: false
                                        });
                                    });

                                    rows.push({
                                        gamo: obj.objective_id || '',
                                        objectiveId: obj.objective_id || '',
                                        keyCultureId: culture.keyculture_id || null,
                                        element: culture.element || '',
                                        guidanceId: null,
                                        guidance: '',
                                        reference: '',
                                        isCreateRow: false
                                    });
                                } else {
                                    rows.push({
                                        gamo: obj.objective_id || '',
                                        objectiveId: obj.objective_id || '',
                                        keyCultureId: culture.keyculture_id || null,
                                        element: culture.element || '',
                                        guidanceId: null,
                                        guidance: '',
                                        reference: '',
                                        isCreateRow: false
                                    });
                                }
                            } else {
                                const guidance = guidances
                                    .map(g => g.guidance)
                                    .filter(Boolean)
                                    .join('<br>');

                                const refs = guidances
                                    .map(g => g.reference)
                                    .filter(Boolean)
                                    .join('<br>');

                                rows.push({
                                    gamo: obj.objective_id || '',
                                    objectiveId: obj.objective_id || '',
                                    keyCultureId: culture.keyculture_id || null,
                                    element: culture.element || '',
                                    guidance,
                                    refs,
                                    isCreateRow: false
                                });
                            }
                        });

                        if (STATE.inputMode) {
                            rows.push({
                                gamo: obj.objective_id || '',
                                objectiveId: obj.objective_id || '',
                                keyCultureId: null,
                                element: '',
                                guidanceId: null,
                                guidance: '',
                                reference: '',
                                isCreateRow: true
                            });
                        }
                    });

                    if (!rows.length) {
                        return '<div class="text-muted">No culture elements found.</div>';
                    }

                    const editable = STATE.inputMode;
                    const actionHeader = editable ? '<th style="width:120px">Action</th>' : '';
                    const modeHint = editable ?
                        `<div class="alert alert-warning py-2 px-3 small mb-2">Input Mode aktif. Anda bisa edit culture element yang ada atau tambah elemen baru per objective.</div>` :
                        '';

                    const tbody = rows.map(r => {
                        if (!editable) {
                            return `
        <tr>
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">${Utils.formatText(r.element)}</td>
          <td class="small">${r.guidance}</td>
          <td class="small">${r.refs}</td>
        </tr>
      `;
                        }

                        const label = r.keyCultureId ? (r.guidanceId ? 'Simpan' : 'Tambah Guidance') : 'Tambah';
                        return `
        <tr class="js-entity-row" data-entity-type="key-culture">
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="element">${Renderers.escapeTextarea(r.element || '')}</textarea>
          </td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="guidance">${Renderers.escapeTextarea(r.guidance || '')}</textarea>
          </td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="reference">${Renderers.escapeTextarea(r.reference || '')}</textarea>
          </td>
          <td class="small text-center">
            <button type="button" class="btn btn-sm btn-primary js-save-entity-row" data-entity-type="key-culture" data-entity-id="${Renderers.escapeAttr(r.keyCultureId || '')}" data-guidance-id="${Renderers.escapeAttr(r.guidanceId || '')}" data-objective-id="${Renderers.escapeAttr(r.objectiveId || '')}">${label}</button>
          </td>
        </tr>
      `;
                    }).join('');

                    return `
        ${modeHint}
        <div class="table-responsive mb-3">
          <table class="table table-sm table-bordered table-striped mb-0" style="table-layout:fixed;width:100%">
            <thead class="table-primary text-white">
              <tr>
                <th style="width:110px">GAMO</th>
                <th>Element</th>
                <th>Guidance</th>
                <th>Reference</th>
                ${actionHeader}
              </tr>
            </thead>
            <tbody>${tbody}</tbody>
          </table>
        </div>
      `;
                },

                renderServices(objectives) {
                    const rows = [];

                    objectives.forEach(obj => {
                        (obj.s_i_a || []).forEach(service => {
                            rows.push({
                                gamo: obj.objective_id || '',
                                objectiveId: obj.objective_id || '',
                                siaId: service.sia_id || null,
                                desc: service.description || '',
                                isCreateRow: false
                            });
                        });

                        if (STATE.inputMode) {
                            rows.push({
                                gamo: obj.objective_id || '',
                                objectiveId: obj.objective_id || '',
                                siaId: null,
                                desc: '',
                                isCreateRow: true
                            });
                        }
                    });

                    if (!rows.length) {
                        return '<div class="text-muted">No services / SIA found.</div>';
                    }

                    const editable = STATE.inputMode;
                    const actionHeader = editable ? '<th style="width:120px">Action</th>' : '';
                    const modeHint = editable ?
                        `<div class="alert alert-warning py-2 px-3 small mb-2">Input Mode aktif. Anda bisa edit SIA yang ada atau tambah SIA baru per objective.</div>` :
                        '';

                    const tbody = rows.map(r => {
                        if (!editable) {
                            return `
        <tr>
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">${Utils.formatText(r.desc)}</td>
        </tr>
      `;
                        }

                        const label = r.siaId ? 'Simpan' : 'Tambah';
                        return `
        <tr class="js-entity-row" data-entity-type="sia">
          <td class="small fw-semibold">${Utils.escapeHtml(Utils.displayGamoId(r.gamo))}</td>
          <td class="small">
            <textarea class="form-control form-control-sm infoflow-edit-control textarea js-entity-field" data-field="description">${Renderers.escapeTextarea(r.desc || '')}</textarea>
          </td>
          <td class="small text-center">
            <button type="button" class="btn btn-sm btn-primary js-save-entity-row" data-entity-type="sia" data-entity-id="${Renderers.escapeAttr(r.siaId || '')}" data-objective-id="${Renderers.escapeAttr(r.objectiveId || '')}">${label}</button>
          </td>
        </tr>
      `;
                    }).join('');

                    return `
        ${modeHint}
        <div class="table-responsive mb-3">
          <table class="table table-sm table-bordered table-striped mb-0" style="table-layout:fixed;width:100%">
            <thead class="table-primary text-white">
              <tr>
                <th style="width:110px">GAMO</th>
                <th>Service / SIA Description</th>
                ${actionHeader}
              </tr>
            </thead>
            <tbody>${tbody}</tbody>
          </table>
        </div>
      `;
                },

                renderOrganizational(objectives) {
                    if (!Array.isArray(objectives) || !objectives.length) {
                        return '<div class="text-muted">No organizational data.</div>';
                    }

                    return objectives.map(obj => {
                        const rolesMap = new Map();
                        (obj.practices || []).forEach(practice => {
                            (practice.roles || []).forEach(role => {
                                if (!rolesMap.has(role.role)) {
                                    rolesMap.set(role.role, role.role_id);
                                }
                            });
                        });

                        const roleNames = Array.from(rolesMap.keys());

                        let html = `
          <div class="mb-0 fw-bold bg-secondary text-white p-2">
            B. Component: Organizational Structures for ${Utils.escapeHtml(Utils.displayObjectiveId(obj.objective_id))} — ${Utils.formatText(obj.objective)}
          </div>
          <div class="table-responsive">
            <table class="table table-sm table-bordered table-striped mb-0">
              <thead class="table-light">
                <tr>
                  <th style="min-width:300px; max-width:500px;">Key Management Practice</th>
                  ${roleNames.map(r => {
                      const roleId = rolesMap.get(r);
                      let deleteBtn = '';
                      if (window.inputMode && roleId) {
                          deleteBtn = `
                            <div class="position-absolute bottom-0 start-50 translate-middle-x w-100 pb-2">
                                <button type="button" class="btn btn-sm btn-outline-primary py-0 px-1 mt-1 mx-auto d-block"
                                    data-child-type="masterrole"
                                    data-child-id="${Utils.escapeAttr(roleId)}"
                                    data-child-field1="${Utils.escapeAttr(r)}"
                                    onclick="openChildEditorFromButton(this)">
                                    <i class="fas fa-pen" style="font-size:0.7rem;"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-outline-danger py-0 px-1 mt-1 d-block mx-auto js-delete-role"
                                  data-objective-id="${Utils.escapeAttr(obj.objective_id || '')}"
                                  data-role-id="${Utils.escapeAttr(roleId)}"
                                  data-role-name="${Utils.escapeAttr(r)}">
                                  <i class="fas fa-trash" style="font-size:0.7rem;"></i>
                                </button>
                            </div>
                          `;
                      }
                      return `
                            <th class="text-center small position-relative" style="width:30px; padding-bottom: 65px !important;">
                              <div class="vertical-text">${Utils.escapeHtml(r)}</div>
                              ${deleteBtn}
                            </th>
                      `;
                  }).join('')}
                </tr>
              </thead>
              <tbody>
        `;

                        // Tambahkan CSS untuk vertical text
                        html = `
          <style>
            .vertical-text {
              writing-mode: vertical-rl;
              transform: rotate(180deg);
              white-space: nowrap;
              min-height: 150px;
              padding: 5px 0;
            }
            
            table th {
              padding: 0 !important;
              vertical-align: middle !important; 
            }
          </style>
        ` + html;

                        (obj.practices || []).forEach(practice => {
                            const mapRole = {};
                            (practice.roles || []).forEach(role => {
                                mapRole[role.role] = {
                                    r_a: role.pivot ? (role.pivot.r_a ?? '') : '',
                                    role_id: role.role_id
                                };
                            });

                            let actionButtons = '';
                            if (window.inputMode) {
                                actionButtons = `
                                    <div class="mt-2">
                                        <button type="button" class="btn btn-sm btn-outline-primary py-0 px-2"
                                            data-child-type="practice"
                                            data-child-id="${Utils.escapeAttr(practice.practice_id || '')}"
                                            data-child-field1="${Utils.escapeAttr(practice.practice_name || '')}"
                                            data-child-field2="${Utils.escapeAttr(practice.practice_description || '')}"
                                            onclick="openChildEditorFromButton(this)">
                                            <i class="fas fa-pen"></i> Edit
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-danger py-0 px-2 ms-1 js-delete-practice"
                                            data-practice-id="${Utils.escapeAttr(practice.practice_id || '')}">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </div>
                                `;
                            }

                            html += `
            <tr>
              <td class="small fw-semibold text-truncate" style="max-width:500px;" title="${Utils.escapeHtml(practice.practice_id || '')}${practice.practice_name ? ' ' + Utils.escapeHtml(practice.practice_name) : ''}">
                ${Utils.escapeHtml(practice.practice_id || '')}${practice.practice_name ? ' ' + Utils.escapeHtml(practice.practice_name) : ''}
                ${actionButtons}
              </td>
              ${roleNames.map(rn => {
                  const roleData = mapRole[rn] || { r_a: '', role_id: '' };
                  const r_a = roleData.r_a;
                  const roleId = roleData.role_id;
                  
                  let roleEditBtn = '';
                  if (window.inputMode && roleId) {
                      roleEditBtn = `
                          <button type="button" class="btn btn-sm btn-outline-secondary py-0 px-1 mt-1 d-block mx-auto"
                              data-child-type="practicerole"
                              data-child-id="${Utils.escapeAttr(practice.practice_id || '')}"
                              data-child-role-id="${Utils.escapeAttr(roleId)}"
                              data-child-field1="${Utils.escapeAttr(r_a)}"
                              data-child-practice-name="${Utils.escapeAttr(practice.practice_name || '')}"
                              onclick="openChildEditorFromButton(this)">
                              <i class="fas fa-pen" style="font-size:0.7rem;"></i>
                          </button>
                      `;
                  }
                  
                  return `
                        <td class="text-center small fw-bold" style="width:40px;">
                            ${Utils.escapeHtml(r_a)}
                            ${roleEditBtn}
                        </td>
                  `;
              }).join('')}
            </tr>
          `;
                        });

                        html += `
                <tr>
                  <td colspan="${roleNames.length + 1}" class="pt-3 pb-3 p-0 border-0">
                    <table class="table table-sm table-bordered mb-0">
                      <tbody>
                        <tr>
                          <td class="fw-bold">Related Guidance</td>
                          <td class="fw-bold">Detailed Reference</td>
                        </tr>
                        <tr>
                          <td colspan="2" class="small text-muted">No related guidance for this component</td>
                        </tr>
                      </tbody>
                    </table>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        `;

                        return html;
                    }).join('');
                }
            };

            // ===================================================================
            // COMPONENT VIEW CONTROLLER
            // ===================================================================

            const ComponentViewController = {
                async renderComponent(componentType) {
                    if (!componentType) {
                        DOM.componentResults.innerHTML = '';
                        return;
                    }

                    // NOTE: Removed style.display manipulation here. 
                    // Visibility is handled strictly by ModeController.
                    DOM.componentResults.innerHTML =
                        `<div class="text-muted small">Loading ${Utils.escapeHtml(componentType)} from all objectives…</div>`;

                    try {
                        const objectives = await DataService.fetchAllObjectives();

                        const tabsHtml = this.createGamoTabs();
                        const initialInner = this.renderComponentContent(componentType, objectives);

                        const cardHtml = Renderers.renderCardWrapper({
                            title: `Menampilkan ${Utils.escapeHtml(componentType)} dari semua objective`,
                            subtitle: '',
                            tabsHtml,
                            bodyHtml: `
            <div id="componentFilterTabs" class="mb-3"></div>
            <div id="componentInnerContent">${initialInner}</div>
          `,
                            bodyId: 'componentInnerContent'
                        });

                        DOM.componentResults.innerHTML = cardHtml;

                        this.initializeComponentFilters(objectives, componentType);
                        this.initializeGamoTabs(objectives, componentType);
                        this.selectDefaultTab(objectives);

                        DOM.componentResults.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    } catch (err) {
                        console.error(err);
                        DOM.componentResults.innerHTML = `
          <div class="alert alert-danger">
            Gagal memuat data: ${Utils.escapeHtml(err.message)}
          </div>
        `;
                    }
                },

                createGamoTabs() {
                    let html = `<div>`;
                    html += `<ul class="nav nav-pills" id="componentGamoTabs">`;
                    html +=
                        `<li class="nav-item"><button class="nav-link active" data-prefix="ALL" type="button">All</button></li>`;

                    CONFIG.PREFERRED_ORDER.forEach(prefix => {
                        html +=
                            `<li class="nav-item"><button class="nav-link" data-prefix="${prefix}" type="button">${prefix}</button></li>`;
                    });

                    html += `</ul>`;
                    html += `<div id="componentGamoObjTabs" class="mt-2" aria-live="polite"></div>`;
                    html += `</div>`;
                    return html;
                },

                renderComponentContent(componentType, objectives) {
                    const rendererMap = {
                        overview: () => Renderers.renderOverview(objectives),
                        practices: () => Renderers.renderPractices(objectives),
                        infoflows: () => Renderers.renderInfoflows(objectives),
                        organizational: () => Renderers.renderOrganizational(objectives),
                        policies: () => Renderers.renderPolicies(objectives),
                        skills: () => Renderers.renderSkills(objectives),
                        culture: () => Renderers.renderCulture(objectives),
                        services: () => Renderers.renderServices(objectives)
                    };

                    const renderer = rendererMap[componentType];
                    return renderer ?
                        renderer() :
                        `<pre class="small">${Utils.escapeHtml(JSON.stringify(objectives, null, 2))}</pre>`;
                },

                initializeComponentFilters(objectives, componentType) {
                    const container = document.getElementById('componentFilterTabs');
                    if (!container || !objectives.length) {
                        if (container) {
                            container.innerHTML = '<div class="small text-muted">No objectives available.</div>';
                        }
                        return;
                    }

                    // reset mapping
                    STATE.objectiveMap.clear();

                    let tabsHtml =
                        `<ul class="nav nav-tabs mb-2" role="tablist" style="overflow:auto; white-space:nowrap;">`;
                    tabsHtml +=
                        `<li class="nav-item" role="presentation"><a href="#" class="nav-link active" data-filter="ALL">All</a></li>`;

                    objectives.forEach(obj => {
                        const rawId = String(obj.objective_id || '');
                        const safeId = Utils.idify(rawId);
                        // store mapping
                        STATE.objectiveMap.set(safeId, rawId);

                        tabsHtml += `
      <li class="nav-item" role="presentation">
        <a href="#" class="nav-link" data-filter="${safeId}" id="comp_tab_${safeId}">
          ${Utils.escapeHtml(Utils.displayObjectiveId(rawId))}
        </a>
      </li>
    `;
                    });

                    tabsHtml += `</ul>`;
                    container.innerHTML = tabsHtml;

                    container.querySelectorAll('a[data-filter]').forEach(anchor => {
                        anchor.addEventListener('click', (e) => {
                            e.preventDefault();
                            this.handleFilterClick(anchor, objectives, componentType);
                        });
                    });

                    const firstAnchor = container.querySelector('a[data-filter="ALL"]');
                    if (firstAnchor) firstAnchor.click();
                },


                handleFilterClick(btn, objectives, componentType) {
                    const parentNav = btn.closest('.nav') || document.getElementById('componentFilterTabs');
                    if (parentNav) {
                        parentNav.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
                    } else {
                        document.querySelectorAll('[data-filter]').forEach(b => b.classList.remove('active'));
                    }
                    btn.classList.add('active');

                    const rawFilter = btn.getAttribute('data-filter') || '';
                    const inner = document.getElementById('componentInnerContent');
                    if (!inner) return;

                    if (rawFilter === 'ALL' || rawFilter === '') {
                        inner.innerHTML = this.renderComponentContent(componentType, objectives);
                        inner.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                        return;
                    }

                    const mappedObjectiveId = STATE.objectiveMap.get(rawFilter);
                    if (mappedObjectiveId) {
                        const obj = objectives.find(x => String(x.objective_id) === String(mappedObjectiveId));
                        if (obj) {
                            inner.innerHTML = this.renderSingleObjectiveComponent(componentType, obj);
                            inner.scrollIntoView({
                                behavior: 'smooth',
                                block: 'start'
                            });
                            return;
                        }
                    }

                    const decodeHtmlEntity = (s) => {
                        if (!s) return '';
                        const txt = document.createElement('textarea');
                        txt.innerHTML = s;
                        return txt.value;
                    };
                    const normalize = (s) => String(decodeHtmlEntity(s || '')).trim().replace(/\s+/g, ' ')
                        .toUpperCase();

                    const normalizedFilter = normalize(rawFilter);
                    // try exact match on normalized objective_id
                    let obj = objectives.find(x => normalize(x.objective_id) === normalizedFilter);
                    if (obj) {
                        inner.innerHTML = this.renderSingleObjectiveComponent(componentType, obj);
                        inner.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                        return;
                    }

                    // try prefix match (e.g., user clicked EDM and expects many)
                    const byPrefix = objectives.filter(x => normalize(x.objective_id).startsWith(normalizedFilter));
                    if (byPrefix.length) {
                        inner.innerHTML = this.renderComponentContent(componentType, byPrefix);
                        inner.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                        return;
                    }

                    // not found
                    console.warn('[handleFilterClick] objective not found for filter:', rawFilter, ' (normalized:',
                        normalizedFilter, ')');
                    inner.innerHTML =
                        `<div class="text-muted small">Objective ${Utils.escapeHtml(rawFilter)} not found.</div>`;
                    inner.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                },

                renderSingleObjectiveComponent(componentType, obj) {
                    const rendererMap = {
                        overview: () => Renderers.renderOverview([obj]),
                        practices: () => Renderers.renderPractices([obj]),
                        infoflows: () => Renderers.renderInfoflows([obj]),
                        organizational: () => Renderers.renderOrganizational([obj]),
                        policies: () => Renderers.renderPolicies([obj]),
                        skills: () => Renderers.renderSkills([obj]),
                        culture: () => Renderers.renderCulture([obj]),
                        services: () => Renderers.renderServices([obj])
                    };

                    const renderer = rendererMap[componentType];
                    return renderer ?
                        renderer() :
                        `<pre class="small">${Utils.escapeHtml(JSON.stringify(obj, null, 2))}</pre>`;
                },

                initializeGamoTabs(objectives, componentType) {
                    document.querySelectorAll('#componentGamoTabs .nav-link').forEach(btn => {
                        btn.addEventListener('click', () => {
                            this.handleGamoTabClick(btn, objectives, componentType);
                        });
                    });

                    const firstPrefixBtn = document.querySelector('#componentGamoTabs .nav-link.active') || document
                        .querySelector('#componentGamoTabs .nav-link[data-prefix="ALL"]');
                    if (firstPrefixBtn) {
                        this.handleGamoTabClick(firstPrefixBtn, objectives, componentType);
                    }
                },

                handleGamoTabClick(btn, objectives, componentType) {
                    document.querySelectorAll('#componentGamoTabs .nav-link').forEach(b => {
                        b.classList.remove('active');
                    });
                    btn.classList.add('active');

                    const prefix = btn.getAttribute('data-prefix') || 'ALL';
                    const filtered = prefix === 'ALL' ?
                        objectives :
                        objectives.filter(obj =>
                            String(obj.objective_id || '').toUpperCase().startsWith(prefix.toUpperCase())
                        );

                    const content = this.renderComponentContent(componentType, filtered);
                    const inner = document.getElementById('componentInnerContent');

                    if (inner) {
                        inner.innerHTML = content;
                        inner.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }

                    const objTabsContainer = document.getElementById('componentGamoObjTabs');
                    if (!objTabsContainer) return;

                    if (!filtered.length) {
                        objTabsContainer.innerHTML =
                            `<div class="small text-muted">No objectives for ${Utils.escapeHtml(prefix)}</div>`;
                        return;
                    }

                    let tabsHtml =
                        `<ul class="nav nav-tabs mb-2" role="tablist" style="overflow:auto; white-space:nowrap;">`;
                    tabsHtml +=
                        `<li class="nav-item" role="presentation"><a href="#" class="nav-link active" data-filter="ALL">All</a></li>`;

                    (filtered).forEach(obj => {
                        const rawId = String(obj.objective_id || '');
                        const safeId = Utils.idify(rawId);
                        // update mapping so either component filters or GAMO tabs can use it
                        STATE.objectiveMap.set(safeId, rawId);

                        tabsHtml += `
    <li class="nav-item" role="presentation">
      <a href="#" class="nav-link" data-filter="${safeId}" id="comp_obj_tab_${safeId}">
        ${Utils.escapeHtml(Utils.displayObjectiveId(rawId))}
      </a>
    </li>
  `;
                    });

                    tabsHtml += `</ul>`;
                    objTabsContainer.innerHTML = tabsHtml;


                    objTabsContainer.querySelectorAll('[data-filter]').forEach(anchor => {
                        anchor.addEventListener('click', (e) => {
                            e.preventDefault();
                            this.handleFilterClick(anchor, filtered, componentType);
                        });
                    });

                    const firstAnchor = objTabsContainer.querySelector('[data-filter="ALL"]');
                    if (firstAnchor) firstAnchor.click();
                },

                selectDefaultTab(objectives) {
                    for (let prefix of CONFIG.PREFERRED_ORDER) {
                        const found = objectives.find(obj =>
                            String(Utils.displayObjectiveId(obj.objective_id || '')).toUpperCase().startsWith(prefix)
                        );

                        if (found) {
                            const btn = document.querySelector(
                                `#componentGamoTabs .nav-link[data-prefix="${prefix}"]`);
                            if (btn) {
                                btn.click();
                                return;
                            }
                        }
                    }
                }
            };

            // ===================================================================
            // GAMO VIEW CONTROLLER
            // ===================================================================

            const GamoViewController = {
                async ensurePopulateGamo() {
                    try {
                        const objectives = await DataService.fetchAllObjectives();
                        const prefixMap = this.groupByPrefix(objectives);
                        const prefixes = this.sortPrefixes(prefixMap);

                        this.renderPrefixTabs(prefixes, prefixMap, objectives);

                        if (prefixes.length) {
                            const firstBtn = DOM.gamoPrefixTabs.querySelector(`[data-prefix="${prefixes[0]}"]`);
                            if (firstBtn) {
                                firstBtn.click();
                            } else {
                                this.renderObjectiveList(prefixes[0], prefixMap.get(prefixes[0]) || [],
                                    objectives);
                            }
                        } else {
                            DOM.gamoPrefixTabs.innerHTML =
                                '<div class="text-muted small">No GAMO prefixes found.</div>';
                            DOM.gamoBreadcrumbs.innerHTML = '';
                        }
                    } catch (err) {
                        console.error('populate gamo failed:', err);
                    }
                },

                groupByPrefix(objectives) {
                    const prefixMap = new Map();

                    objectives.forEach(obj => {
                        const prefix = (String(obj.objective_id || '').match(/^[A-Za-z]+/) || [''])[0]
                            .toUpperCase() || '__OTHER';
                        if (!prefixMap.has(prefix)) {
                            prefixMap.set(prefix, []);
                        }
                        prefixMap.get(prefix).push(obj);
                    });

                    return prefixMap;
                },

                sortPrefixes(prefixMap) {
                    const prefixes = [];

                    CONFIG.PREFERRED_ORDER.forEach(prefix => {
                        if (prefixMap.has(prefix)) {
                            prefixes.push(prefix);
                        }
                    });

                    Array.from(prefixMap.keys())
                        .sort()
                        .forEach(prefix => {
                            if (!prefixes.includes(prefix)) {
                                prefixes.push(prefix);
                            }
                        });

                    return prefixes;
                },

                renderPrefixTabs(prefixes, prefixMap, objectives) {
                    DOM.gamoPrefixTabs.innerHTML = '';

                    prefixes.forEach((prefix, idx) => {
                        const btn = document.createElement('button');
                        btn.type = 'button';
                        btn.className =
                            `btn ${idx === 0 ? 'btn-primary' : 'btn-outline-primary'} flex-fill`;
                        btn.setAttribute('data-prefix', prefix);
                        btn.textContent = prefix === '__OTHER' ? 'OTHER' : prefix;

                        btn.addEventListener('click', () => {
                            this.handlePrefixClick(btn, prefix, prefixMap, objectives);
                        });

                        DOM.gamoPrefixTabs.appendChild(btn);
                    });
                },

                handlePrefixClick(btn, prefix, prefixMap, objectives) {
                    Array.from(DOM.gamoPrefixTabs.children).forEach(child => {
                        child.classList.remove('btn-primary');
                        child.classList.add('btn-outline-primary');
                    });

                    btn.classList.remove('btn-outline-primary');
                    btn.classList.add('btn-primary');

                    this.renderObjectiveList(prefix, prefixMap.get(prefix) || [], objectives);
                },

                renderObjectiveList(prefix, objectiveList, allObjectives) {
                    if (!objectiveList.length) {
                        DOM.gamoBreadcrumbs.innerHTML =
                            '<div class="text-muted small">No objectives for this prefix.</div>';
                        return;
                    }

                    let tabsHtml =
                        `<ul class="nav nav-tabs mb-2" role="tablist" style="overflow:auto; white-space:nowrap;">`;

                    objectiveList.forEach((obj, idx) => {
                        const active = idx === 0 ? 'active' : '';
                        const safeId = Utils.idify(obj.objective_id);
                        const objId = Utils.escapeHtml(Utils.displayObjectiveId(obj.objective_id || ''));

                        tabsHtml += `
          <li class="nav-item" role="presentation">
            <a href="#" class="nav-link ${active}" data-obj="${Utils.escapeHtml(obj.objective_id || '')}" id="gamo_tab_${safeId}">
              ${objId}
            </a>
          </li>
        `;
                    });

                    tabsHtml += `</ul>`;


                    DOM.gamoBreadcrumbs.innerHTML = tabsHtml;

                    DOM.gamoBreadcrumbs.querySelectorAll('a[data-obj]').forEach(anchor => {
                        anchor.addEventListener('click', (e) => {
                            e.preventDefault();
                            this.handleObjectiveTabClick(anchor);
                        });
                    });

                    const firstAnchor = DOM.gamoBreadcrumbs.querySelector('a[data-obj]');
                    if (firstAnchor) firstAnchor.click();
                },

                handleObjectiveTabClick(anchor) {
                    DOM.gamoBreadcrumbs.querySelectorAll('a[data-obj]').forEach(a => {
                        a.classList.remove('active');
                    });
                    anchor.classList.add('active');

                    const objId = anchor.getAttribute('data-obj');
                    this.selectObjective(objId);
                },

                async selectObjective(id) {
                    if (!id) {
                        DOM.gamoResults.innerHTML = '';
                        return;
                    }

                    try {
                        const objectives = await DataService.fetchAllObjectives();
                        const normalizedTarget = Utils.displayObjectiveId(id);
                        const obj = objectives.find(x =>
                            String(x.objective_id) === String(id) ||
                            Utils.displayObjectiveId(x.objective_id || '') === normalizedTarget
                        );

                        if (!obj) {
                            DOM.gamoResults.innerHTML = '<div class="text-muted">Objective not found</div>';
                            return;
                        }

                        // NOTE: per request, do NOT display breadcrumb details / objective title / domain here.
                        // Keep the details pane but do not inject the extra strings previously present.
                        this.renderObjectiveDetails(obj);
                    } catch (err) {
                        console.error(err);
                        DOM.gamoResults.innerHTML = `
          <div class="text-muted">
            Gagal memuat objective: ${Utils.escapeHtml(err.message)}
          </div>
        `;
                    }
                },

                updateBreadcrumbs(obj) {
                        const infoEl = document.getElementById('gamoObjSelectedInfo');
                    if (infoEl) {
                        infoEl.innerHTML =
                            `<div class="small text-muted">Objective selected: ${Utils.escapeHtml(Utils.displayObjectiveId(obj.objective_id || ''))}</div>`;
                    }
                },

                renderObjectiveDetails(obj) {
                    const components = ['overview', 'practices', 'infoflows', 'organizational', 'policies',
                        'skills', 'culture', 'services'
                    ];

                    let tabsHtml = `<ul class="nav nav-pills nav-fill" id="gamoTabs">`;
                    components.forEach((comp, idx) => {
                        const label = CONFIG.COMPONENT_LABELS[comp] || comp;
                        const active = idx === 0 ? 'active' : '';
                        tabsHtml += `
          <li class="nav-item">
            <button class="nav-link ${active}" data-comp="${comp}">${label}</button>
          </li>
        `;
                    });
                    tabsHtml += `</ul>`;

                    const initialBody = Renderers.renderOverview([obj]);

                    const cardHtml = Renderers.renderCardWrapper({
                        title: `${Utils.escapeHtml(Utils.displayObjectiveId(obj.objective_id))} — ${Utils.escapeHtml(obj.objective || '')}`,
                        subtitle: '',
                        smallNote: '', // removed "(GAMO)" and other small note text per request
                        tabsHtml,
                        bodyHtml: initialBody,
                        bodyId: 'gamoContent'
                    });

                    DOM.gamoResults.innerHTML = cardHtml;

                    DOM.gamoResults.querySelectorAll('#gamoTabs .nav-link').forEach(btn => {
                        btn.addEventListener('click', () => {
                            this.handleComponentTabClick(btn, obj);
                        });
                    });
                },

                handleComponentTabClick(btn, obj) {
                    DOM.gamoResults.querySelectorAll('#gamoTabs .nav-link').forEach(b => {
                        b.classList.remove('active');
                    });
                    btn.classList.add('active');

                    const comp = btn.getAttribute('data-comp');
                    const content = this.renderObjectiveComponent(comp, obj);

                    const contentEl = DOM.gamoResults.querySelector('#gamoContent');
                    if (contentEl) {
                        contentEl.innerHTML = content;
                    }
                },

                renderObjectiveComponent(componentType, obj) {
                    const rendererMap = {
                        overview: () => Renderers.renderOverview([obj]),
                        practices: () => Renderers.renderPractices([obj]),
                        infoflows: () => Renderers.renderInfoflows([obj]),
                        organizational: () => Renderers.renderOrganizational([obj]),
                        policies: () => Renderers.renderPolicies([obj]),
                        skills: () => Renderers.renderSkills([obj]),
                        culture: () => Renderers.renderCulture([obj]),
                        services: () => Renderers.renderServices([obj])
                    };

                    const renderer = rendererMap[componentType];
                    return renderer ? renderer() : '';
                }
            };

            // ===================================================================
            // MODE CONTROLLER (refactored)
            // - centralizes button state handling
            // - ensures only one primary (filled) button at a time
            // - keeps DOM display logic isolated
            // ===================================================================

            const ModeController = {
                // Public API: setMode, activateGamoMode, activateComponentMode, toggleMaster

                setMode(mode) {
                    // hide master panel whenever switching mode
                    DOM.masterPanel.style.display = 'none';

                    // normalize buttons first (ensure none are accidentally left as primary)
                    this._setInactive(DOM.modeGamoBtn);
                    this._setInactive(DOM.modeComponentBtn);
                    this._setInactive(DOM.masterToggleBtn);

                    if (mode === 'gamo') {
                        this.activateGamoMode();
                    } else {
                        this.activateComponentMode();
                    }
                },

                activateGamoMode() {
                    this._setActive(DOM.modeGamoBtn);
                    this._setInactive(DOM.modeComponentBtn);
                    this._setInactive(DOM.masterToggleBtn);

                    DOM.gamoPane.style.display = 'block';
                    DOM.componentResults.style.display = 'none';
                    if (DOM.componentSelect && DOM.componentSelect.closest('.row')) {
                        DOM.componentSelect.closest('.row').style.display = 'none';
                    }

                    GamoViewController.ensurePopulateGamo().catch(err => {
                        console.error('Failed to populate GAMO:', err);
                    });
                },

                activateComponentMode() {
                    this._setActive(DOM.modeComponentBtn);
                    this._setInactive(DOM.modeGamoBtn);
                    this._setInactive(DOM.masterToggleBtn);

                    DOM.gamoPane.style.display = 'none';
                    DOM.componentResults.style.display = 'block';
                    if (DOM.componentSelect && DOM.componentSelect.closest('.row')) {
                        DOM.componentSelect.closest('.row').style.display = '';
                    }
                },

                async toggleMaster() {
                    const isVisible = DOM.masterPanel.style.display !== 'block';

                    if (isVisible) {
                        // show master panel and mark Master button active
                        DOM.masterPanel.style.display = 'block';
                        this._setActive(DOM.masterToggleBtn);

                        // ensure other mode buttons appear inactive
                        this._setInactive(DOM.modeGamoBtn);
                        this._setInactive(DOM.modeComponentBtn);

                        DOM.gamoPane.style.display = 'none';
                        DOM.componentResults.style.display = 'none';
                        if (DOM.componentSelect && DOM.componentSelect.closest('.row')) {
                            DOM.componentSelect.closest('.row').style.display = 'none';
                        }

                        if (!STATE.masterRendered) {
                            await MasterService.renderMaster();
                        }
                    } else {
                        // hide master and restore component mode visuals
                        DOM.masterPanel.style.display = 'none';
                        this._setInactive(DOM.masterToggleBtn);
                        this.setMode('component');
                    }
                },

                // Helper: mark button visually active (filled)
                _setActive(btn) {
                    if (!btn) return;
                    // prefer removing any outline class and add primary
                    btn.classList.remove('btn-outline-primary', 'btn-outline-secondary');
                    if (!btn.classList.contains('btn-primary')) btn.classList.add('btn-primary');
                },

                // Helper: mark button visually inactive (outline)
                _setInactive(btn) {
                    if (!btn) return;
                    if (btn.classList.contains('btn-primary')) {
                        btn.classList.replace('btn-primary', 'btn-outline-primary');
                    }
                    // ensure at least one outline class exists
                    if (!btn.classList.contains('btn-outline-primary') && !btn.classList.contains(
                            'btn-outline-secondary')) {
                        btn.classList.add('btn-outline-primary');
                    }
                }
            };

            const NotificationController = {
                show(type, message, timeoutMs = 3200) {
                    if (!DOM.infoflowNotifWrap) return;

                    const classMap = {
                        success: 'alert-success',
                        danger: 'alert-danger',
                        warning: 'alert-warning',
                        info: 'alert-info'
                    };

                    const alertClass = classMap[type] || 'alert-secondary';
                    const note = document.createElement('div');
                    note.className = `alert ${alertClass} alert-dismissible fade show py-2 px-3 mb-0 shadow-sm`;
                    note.setAttribute('role', 'status');
                    note.innerHTML = `
                        <div class="small">${Utils.escapeHtml(message || '')}</div>
                        <button type="button" class="btn-close" aria-label="Close"></button>
                    `;

                    const closeBtn = note.querySelector('.btn-close');
                    closeBtn.addEventListener('click', () => {
                        note.remove();
                    });

                    DOM.infoflowNotifWrap.prepend(note);

                    window.setTimeout(() => {
                        note.remove();
                    }, timeoutMs);
                }
            };

            const InputModeController = {
                syncButton() {
                    if (!DOM.inputModeBtn) return;

                    if (!AUTHZ.canInputMode) {
                        DOM.inputModeBtn.textContent = 'Input Mode: No Access';
                        DOM.inputModeBtn.disabled = true;
                        DOM.inputModeBtn.classList.remove('btn-primary', 'btn-outline-secondary');
                        DOM.inputModeBtn.classList.add('btn-outline-secondary');
                        return;
                    }

                    DOM.inputModeBtn.disabled = false;
                    DOM.inputModeBtn.textContent = `Input Mode: ${STATE.inputMode ? 'ON' : 'OFF'}`;

                    DOM.inputModeBtn.classList.remove('btn-primary', 'btn-outline-secondary');
                    DOM.inputModeBtn.classList.add(STATE.inputMode ? 'btn-primary' : 'btn-outline-secondary');
                },

                toggle() {
                    if (!AUTHZ.canInputMode) return;
                    STATE.inputMode = !STATE.inputMode;
                    this.syncButton();
                    this.refreshActiveComponentView();
                    NotificationController.show(
                        'info',
                        STATE.inputMode ? 'Input Mode aktif. Data komponen bisa diedit.' :
                        'Input Mode nonaktif. Data kembali terkunci.',
                        2400
                    );
                },

                getActiveComponent() {
                    const isGamoMode = DOM.gamoPane && DOM.gamoPane.style.display === 'block';
                    if (isGamoMode) {
                        const activeComponentBtn = DOM.gamoResults ?
                            DOM.gamoResults.querySelector('#gamoTabs .nav-link.active') :
                            null;
                        return activeComponentBtn ? activeComponentBtn.getAttribute('data-comp') : 'overview';
                    }

                    return DOM.componentSelect ? (DOM.componentSelect.value || 'overview') : 'overview';
                },

                async refreshActiveComponentView() {
                    const isMasterVisible = DOM.masterPanel && DOM.masterPanel.style.display === 'block';
                    if (isMasterVisible) return;

                    const isGamoMode = DOM.gamoPane && DOM.gamoPane.style.display === 'block';
                    if (isGamoMode) {
                        const activeObjAnchor = DOM.gamoBreadcrumbs ?
                            DOM.gamoBreadcrumbs.querySelector('a[data-obj].active') :
                            null;
                        const activeObjectiveId = activeObjAnchor ?
                            activeObjAnchor.getAttribute('data-obj') :
                            '';

                        const activeComponent = this.getActiveComponent();

                        if (activeObjectiveId) {
                            await GamoViewController.selectObjective(activeObjectiveId);

                            const targetBtn = DOM.gamoResults ?
                                DOM.gamoResults.querySelector(
                                    `#gamoTabs .nav-link[data-comp="${activeComponent || 'overview'}"]`
                                ) :
                                null;

                            if (targetBtn) {
                                targetBtn.click();
                            }
                        }
                        return;
                    }

                    if (DOM.componentSelect) {
                        DOM.componentSelect.dispatchEvent(new Event('change'));
                    }
                },

                async saveInfoflowRow(button) {
                    if (!button || !AUTHZ.canInputMode) return;

                    const row = button.closest('.js-infoflow-row');
                    const inputIdRaw = button.getAttribute('data-input-id');
                    const outputIdRaw = button.getAttribute('data-output-id');
                    const practiceId = (button.getAttribute('data-practice-id') || '').trim();

                    if (!row || !practiceId) {
                        NotificationController.show('danger', 'Practice ID tidak ditemukan. Data tidak bisa disimpan.');
                        return;
                    }

                    const inputId = inputIdRaw ? String(inputIdRaw).trim() : '';
                    const outputId = outputIdRaw ? String(outputIdRaw).trim() : '';

                    const fromField = row.querySelector('.js-infoflow-field[data-field="from"]');
                    const inputDescField = row.querySelector('.js-infoflow-field[data-field="input_description"]');
                    const outputDescField = row.querySelector('.js-infoflow-field[data-field="output_description"]');
                    const toField = row.querySelector('.js-infoflow-field[data-field="to"]');

                    const normalizeText = (value) => String(value || '').trim();

                    const inputPayload = {
                        from: normalizeText(fromField ? fromField.value : ''),
                        description: normalizeText(inputDescField ? inputDescField.value : '')
                    };

                    const outputPayload = {
                        to: normalizeText(toField ? toField.value : ''),
                        description: normalizeText(outputDescField ? outputDescField.value : '')
                    };

                    const hasAnyInputValue = Boolean(inputPayload.from || inputPayload.description);
                    const hasAnyOutputValue = Boolean(outputPayload.to || outputPayload.description);
                    const isCreateRow = !inputId;

                    if (isCreateRow && !hasAnyInputValue && !hasAnyOutputValue) {
                        NotificationController.show('warning',
                            'Isi minimal satu field sebelum menambah data infoflow baru.');
                        return;
                    }

                    const originalLabel = button.textContent;
                    button.disabled = true;
                    button.textContent = 'Menyimpan...';

                    try {
                        let resolvedInputId = inputId;

                        if (resolvedInputId) {
                            await DataService.updateInfoflowInput(resolvedInputId, inputPayload);
                        } else {
                            const createdInput = await DataService.createInfoflowInput({
                                practice_id: practiceId,
                                ...inputPayload
                            });

                            resolvedInputId = String(createdInput.input_id || '');
                        }

                        if (outputId) {
                            await DataService.updateInfoflowOutput(outputId, outputPayload);
                        } else if (hasAnyOutputValue) {
                            await DataService.createInfoflowOutput({
                                practice_id: practiceId,
                                input_id: resolvedInputId ? Number(resolvedInputId) : null,
                                ...outputPayload
                            });
                        }

                        button.textContent = 'Tersimpan';
                        NotificationController.show(
                            'success',
                            isCreateRow ? 'Data infoflow baru berhasil ditambahkan.' :
                            'Data infoflow berhasil diperbarui.'
                        );
                        if (isCreateRow) {
                            STATE.showCreateRowForPractice[practiceId] = false;
                        }
                        await this.refreshActiveComponentView();
                    } catch (err) {
                        console.error('Failed to save infoflow row:', err);
                        button.textContent = 'Gagal';
                        NotificationController.show('danger',
                            `Gagal menyimpan data infoflow: ${err.message}`);
                    } finally {
                        window.setTimeout(() => {
                            button.disabled = false;
                            button.textContent = originalLabel;
                        }, 900);
                    }
                },

                async deleteObjectiveRole(button) {
                    if (!button || !AUTHZ.canInputMode) return;

                    const objectiveId = (button.getAttribute('data-objective-id') || '').trim();
                    const roleId = (button.getAttribute('data-role-id') || '').trim();
                    const roleName = (button.getAttribute('data-role-name') || '').trim();
                    
                    if (!objectiveId || !roleId) {
                        NotificationController.show('danger', 'Data role tidak valid.');
                        return;
                    }

                    if (!confirm(`Apakah Anda yakin ingin menghapus role "${roleName}" dari objective ${objectiveId}? Semua data RACI terkait role ini akan ikut terhapus.`)) {
                        return;
                    }

                    const originalLabel = button.innerHTML;
                    button.disabled = true;
                    button.innerHTML = '<i class="spinner-border spinner-border-sm"></i>';

                    try {
                        const url = `{{ url('/objectives') }}/${encodeURIComponent(objectiveId)}/roles/${encodeURIComponent(roleId)}`;
                        const response = await fetch(url, {
                            method: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                                'Accept': 'application/json'
                            }
                        });

                        if (!response.ok) {
                            const errData = await response.json();
                            throw new Error(errData.message || 'Server error');
                        }

                        NotificationController.show('success', 'Role berhasil dihapus.');
                        await this.refreshActiveComponentView();
                    } catch (err) {
                        console.error('Failed to delete role:', err);
                        NotificationController.show('danger', `Gagal menghapus role: ${err.message}`);
                    } finally {
                        window.setTimeout(() => {
                            button.disabled = false;
                            button.innerHTML = originalLabel;
                        }, 900);
                    }
                },

                async deletePractice(button) {
                    if (!button || !AUTHZ.canInputMode) return;

                    const practiceId = (button.getAttribute('data-practice-id') || '').trim();
                    if (!practiceId) {
                        NotificationController.show('danger', 'Practice ID tidak valid.');
                        return;
                    }

                    if (!confirm(`Apakah Anda yakin ingin menghapus practice ${practiceId}? Semua data terkait (Activities, Metrics, Infoflow, Roles, Guidances) akan ikut terhapus.`)) {
                        return;
                    }

                    const originalLabel = button.innerHTML;
                    button.disabled = true;
                    button.innerHTML = '<i class="spinner-border spinner-border-sm"></i> Menghapus...';

                    try {
                        const url = `{{ url('/objectives/practices') }}/${encodeURIComponent(practiceId)}`;
                        const response = await fetch(url, {
                            method: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                                'Accept': 'application/json'
                            }
                        });

                        if (!response.ok) {
                            const errData = await response.json();
                            throw new Error(errData.message || 'Server error');
                        }

                        NotificationController.show('success', `Practice ${practiceId} berhasil dihapus.`);
                        
                        // Refresh active view
                        await this.refreshActiveComponentView();

                    } catch (err) {
                        console.error('Failed to delete practice:', err);
                        NotificationController.show('danger', `Gagal menghapus practice: ${err.message}`);
                    } finally {
                        button.disabled = false;
                        button.innerHTML = originalLabel;
                    }
                },

                async deleteInfoflowRow(button) {
                    if (!button || !AUTHZ.canInputMode) return;

                    const inputId = (button.getAttribute('data-input-id') || '').trim();
                    const outputId = (button.getAttribute('data-output-id') || '').trim();

                    if (!inputId && !outputId) {
                        NotificationController.show('danger', 'ID tidak ditemukan. Data tidak bisa dihapus.');
                        return;
                    }

                    if (!confirm('Apakah Anda yakin ingin menghapus baris alur informasi ini?')) {
                        return;
                    }

                    const originalLabel = button.textContent;
                    button.disabled = true;
                    button.textContent = 'Menghapus...';

                    try {
                        if (outputId) {
                            await DataService.deleteInfoflowOutput(outputId);
                        } else if (inputId) {
                            await DataService.deleteInfoflowInput(inputId);
                        }

                        NotificationController.show('success', 'Data alur informasi berhasil dihapus.');
                        await this.refreshActiveComponentView();
                    } catch (err) {
                        console.error('Failed to delete infoflow row:', err);
                        button.textContent = 'Gagal';
                        NotificationController.show('danger', `Gagal menghapus data: ${err.message}`);
                    } finally {
                        window.setTimeout(() => {
                            button.disabled = false;
                            button.textContent = originalLabel;
                        }, 900);
                    }
                },

                async saveEntityRow(button) {
                    if (!button || !AUTHZ.canInputMode) return;

                    const row = button.closest('.js-entity-row');
                    const entityType = (button.getAttribute('data-entity-type') || '').trim();
                    const entityId = (button.getAttribute('data-entity-id') || '').trim();
                    const guidanceId = (button.getAttribute('data-guidance-id') || '').trim();
                    const objectiveId = (button.getAttribute('data-objective-id') || '').trim();

                    if (!row || !entityType || !objectiveId) {
                        NotificationController.show('danger', 'Data baris tidak lengkap. Simpan dibatalkan.');
                        return;
                    }

                    const payload = {};
                    row.querySelectorAll('.js-entity-field').forEach(field => {
                        const key = field.getAttribute('data-field');
                        if (!key) return;
                        payload[key] = String(field.value || '').trim();
                    });

                    const hasAnyEntityValue = ['policy', 'description', 'skill', 'element']
                        .some(key => Boolean(String(payload[key] || '').trim()));
                    const hasAnyGuidanceValue = ['guidance', 'reference']
                        .some(key => Boolean(String(payload[key] || '').trim()));
                    const hasAnyValue = hasAnyEntityValue || hasAnyGuidanceValue;

                    if (!entityId && !hasAnyValue) {
                        NotificationController.show('warning',
                            'Isi minimal satu field sebelum menambah data baru.');
                        return;
                    }

                    const configMap = {
                        policy: {
                            create: (data) => DataService.createPolicy(data),
                            update: (id, data) => DataService.updatePolicy(id, data),
                            createGuidance: (id, data) => DataService.createPolicyGuidance(id, data),
                            createPayload: {
                                objective_id: objectiveId,
                                policy: payload.policy || '',
                                description: payload.description || ''
                            },
                            updatePayload: {
                                policy: payload.policy || '',
                                description: payload.description || ''
                            },
                            idField: 'policy_id',
                            createdMessage: 'Policy baru berhasil ditambahkan.',
                            updatedMessage: 'Policy berhasil diperbarui.'
                        },
                        skill: {
                            create: (data) => DataService.createSkill(data),
                            update: (id, data) => DataService.updateSkill(id, data),
                            createGuidance: (id, data) => DataService.createSkillGuidance(id, data),
                            createPayload: {
                                objective_id: objectiveId,
                                skill: payload.skill || ''
                            },
                            updatePayload: {
                                skill: payload.skill || ''
                            },
                            idField: 'skill_id',
                            createdMessage: 'Skill baru berhasil ditambahkan.',
                            updatedMessage: 'Skill berhasil diperbarui.'
                        },
                        'key-culture': {
                            create: (data) => DataService.createKeyCulture(data),
                            update: (id, data) => DataService.updateKeyCulture(id, data),
                            createGuidance: (id, data) => DataService.createKeyCultureGuidance(id, data),
                            createPayload: {
                                objective_id: objectiveId,
                                element: payload.element || ''
                            },
                            updatePayload: {
                                element: payload.element || ''
                            },
                            idField: 'keyculture_id',
                            createdMessage: 'Culture element baru berhasil ditambahkan.',
                            updatedMessage: 'Culture element berhasil diperbarui.'
                        },
                        sia: {
                            create: (data) => DataService.createSia(data),
                            update: (id, data) => DataService.updateSia(id, data),
                            createPayload: {
                                objective_id: objectiveId,
                                description: payload.description || ''
                            },
                            updatePayload: {
                                description: payload.description || ''
                            },
                            idField: 'sia_id',
                            createdMessage: 'SIA baru berhasil ditambahkan.',
                            updatedMessage: 'SIA berhasil diperbarui.'
                        }
                    };

                    const config = configMap[entityType];
                    if (!config) {
                        NotificationController.show('danger', `Entity type ${entityType} belum didukung.`);
                        return;
                    }

                    const originalLabel = button.textContent;
                    button.disabled = true;
                    button.textContent = 'Menyimpan...';

                    try {
                        let resolvedEntityId = entityId;

                        if (resolvedEntityId) {
                            await config.update(resolvedEntityId, config.updatePayload);
                        } else {
                            const createdEntity = await config.create(config.createPayload);
                            resolvedEntityId = String(createdEntity[config.idField] || '');
                        }

                        if (entityType !== 'sia') {
                            if (guidanceId) {
                                await DataService.updateGuidance(guidanceId, {
                                    guidance: payload.guidance || '',
                                    reference: payload.reference || ''
                                });
                            } else if (hasAnyGuidanceValue && resolvedEntityId) {
                                await config.createGuidance(resolvedEntityId, {
                                    guidance: payload.guidance || '',
                                    reference: payload.reference || ''
                                });
                            }
                        }

                        button.textContent = 'Tersimpan';
                        NotificationController.show(
                            'success',
                            entityId ? config.updatedMessage : config.createdMessage
                        );
                        await this.refreshActiveComponentView();
                    } catch (err) {
                        console.error(`Failed to save ${entityType}:`, err);
                        button.textContent = 'Gagal';
                        NotificationController.show('danger',
                            `Gagal menyimpan data ${entityType}: ${err.message}`);
                    } finally {
                        window.setTimeout(() => {
                            button.disabled = false;
                            button.textContent = originalLabel;
                        }, 900);
                    }
                },

                async savePracticeMetric(button) {
                    if (!button || !AUTHZ.canInputMode) return;

                    const item = button.closest('.js-practice-metric-item');
                    const list = button.closest('.js-practice-metrics-list');
                    if (!item || !list) return;

                    const practiceId = (list.getAttribute('data-practice-id') || '').trim();
                    const metricId = (item.getAttribute('data-metric-id') || '').trim();
                    const descField = item.querySelector('.js-practice-metric-desc');
                    const description = (descField ? descField.value : '').trim();

                    if (!description) {
                        NotificationController.show('warning', 'Deskripsi metric tidak boleh kosong.');
                        return;
                    }

                    const originalLabel = button.innerHTML;
                    button.disabled = true;
                    button.innerHTML = '<i class="spinner-border spinner-border-sm"></i>';

                    try {
                        if (metricId) {
                            // Update
                            await DataService.updatePracticeMetric(metricId, { description });
                            NotificationController.show('success', 'Example metric berhasil diperbarui.');
                        } else {
                            // Create
                            if (!practiceId) {
                                NotificationController.show('danger', 'Practice ID tidak valid.');
                                return;
                            }
                            await DataService.createPracticeMetric(practiceId, { description });
                            NotificationController.show('success', 'Example metric baru berhasil ditambahkan.');
                        }
                        await this.refreshActiveComponentView();
                    } catch (err) {
                        console.error('Failed to save practice metric:', err);
                        NotificationController.show('danger', `Gagal menyimpan example metric: ${err.message}`);
                    } finally {
                        button.disabled = false;
                        button.innerHTML = originalLabel;
                    }
                },

                async deletePracticeMetric(button) {
                    if (!button || !AUTHZ.canInputMode) return;

                    const item = button.closest('.js-practice-metric-item');
                    if (!item) return;

                    const metricId = (item.getAttribute('data-metric-id') || '').trim();
                    if (!metricId) return;

                    if (!confirm('Apakah Anda yakin ingin menghapus example metric ini?')) {
                        return;
                    }

                    const originalLabel = button.innerHTML;
                    button.disabled = true;
                    button.innerHTML = '<i class="spinner-border spinner-border-sm"></i>';

                    try {
                        await DataService.deletePracticeMetric(metricId);
                        NotificationController.show('success', 'Example metric berhasil dihapus.');
                        await this.refreshActiveComponentView();
                    } catch (err) {
                        console.error('Failed to delete practice metric:', err);
                        NotificationController.show('danger', `Gagal menghapus example metric: ${err.message}`);
                    } finally {
                        button.disabled = false;
                        button.innerHTML = originalLabel;
                    }
                }
            };

            // ===================================================================
            // EVENT LISTENERS
            // ===================================================================

            const EventListeners = {
                init() {
                    this.setupComponentSelect();
                    this.setupModeButtons();
                    this.setupMasterToggle();
                    this.setupInputModeToggle();
                    this.setupInfoflowRowSaveHandler();
                    this.setupInfoflowRowAddCancelHandlers();
                    this.setupInfoflowRowDeleteHandler();
                    this.setupRoleDeleteHandler();
                    this.setupPracticeDeleteHandler();
                    this.setupEntityRowSaveHandler();
                    this.setupPracticeMetricSaveHandler();
                    this.setupPracticeMetricDeleteHandler();
                    this.setupPracticeMetricAddHandler();
                    this.setupDraftMetricRemoveHandler();
                    this.setupToModalHandler();
                    this.initializeComponent();
                    InputModeController.syncButton();
                },

                setupComponentSelect() {
                    DOM.componentSelect.addEventListener('change', function() {
                        ComponentViewController.renderComponent(this.value);
                    });
                },

                setupModeButtons() {
                    DOM.modeGamoBtn.addEventListener('click', () => {
                        ModeController.setMode('gamo');
                    });

                    DOM.modeComponentBtn.addEventListener('click', () => {
                        ModeController.setMode('component');
                    });
                },

                setupMasterToggle() {
                    DOM.masterToggleBtn.addEventListener('click', () => {
                        ModeController.toggleMaster();
                    });
                },

                setupInputModeToggle() {
                    if (!DOM.inputModeBtn) return;

                    DOM.inputModeBtn.addEventListener('click', () => {
                        InputModeController.toggle();
                    });
                },

                setupInfoflowRowSaveHandler() {
                    document.addEventListener('click', (event) => {
                        const targetBtn = event.target.closest('.js-save-infoflow-row');
                        if (!targetBtn) return;
                        InputModeController.saveInfoflowRow(targetBtn);
                    });
                },

                setupInfoflowRowDeleteHandler() {
                    document.addEventListener('click', (event) => {
                        const targetBtn = event.target.closest('.js-delete-infoflow-row');
                        if (!targetBtn) return;
                        InputModeController.deleteInfoflowRow(targetBtn);
                    });
                },

                setupRoleDeleteHandler() {
                    document.addEventListener('click', (event) => {
                        const targetBtn = event.target.closest('.js-delete-role');
                        if (!targetBtn) return;
                        InputModeController.deleteObjectiveRole(targetBtn);
                    });
                },

                setupPracticeDeleteHandler() {
                    document.addEventListener('click', (event) => {
                        const targetBtn = event.target.closest('.js-delete-practice');
                        if (!targetBtn) return;
                        InputModeController.deletePractice(targetBtn);
                    });
                },

                setupInfoflowRowAddCancelHandlers() {
                    document.addEventListener('click', (event) => {
                        const addBtn = event.target.closest('.js-trigger-add-infoflow');
                        if (addBtn) {
                            const practiceId = addBtn.getAttribute('data-practice-id');
                            if (practiceId) {
                                STATE.showCreateRowForPractice[practiceId] = true;
                                InputModeController.refreshActiveComponentView();
                            }
                            return;
                        }

                        const cancelBtn = event.target.closest('.js-cancel-add-infoflow');
                        if (cancelBtn) {
                            const practiceId = cancelBtn.getAttribute('data-practice-id');
                            if (practiceId) {
                                STATE.showCreateRowForPractice[practiceId] = false;
                                InputModeController.refreshActiveComponentView();
                            }
                        }
                    });
                },

                setupEntityRowSaveHandler() {
                    document.addEventListener('click', (event) => {
                        const targetBtn = event.target.closest('.js-save-entity-row');
                        if (!targetBtn) return;
                        InputModeController.saveEntityRow(targetBtn);
                    });
                },

                setupPracticeMetricSaveHandler() {
                    document.addEventListener('click', (event) => {
                        const targetBtn = event.target.closest('.js-save-practice-metric');
                        if (!targetBtn) return;
                        InputModeController.savePracticeMetric(targetBtn);
                    });
                },

                setupPracticeMetricDeleteHandler() {
                    document.addEventListener('click', (event) => {
                        const targetBtn = event.target.closest('.js-delete-practice-metric');
                        if (!targetBtn) return;
                        InputModeController.deletePracticeMetric(targetBtn);
                    });
                },

                setupPracticeMetricAddHandler() {
                    document.addEventListener('click', (event) => {
                        const addBtn = event.target.closest('.js-add-practice-metric');
                        if (!addBtn) return;

                        const practiceId = addBtn.getAttribute('data-practice-id');
                        const card = addBtn.closest('.bg-light');
                        if (!card) return;

                        const listContainer = card.querySelector('.js-practice-metrics-list');
                        if (!listContainer) return;

                        const newIdx = listContainer.children.length;
                        const labelChar = String.fromCharCode(97 + newIdx); // 'a', 'b', 'c', ...

                        const newRowHtml = `
                            <div class="d-flex align-items-start gap-2 mb-2 js-practice-metric-item" data-metric-id="">
                                <span class="mt-1 fw-semibold small text-muted" style="width: 20px;">${labelChar}.</span>
                                <textarea class="form-control form-control-sm js-practice-metric-desc" rows="1" style="resize: vertical; font-size: 13px;" placeholder="Tulis deskripsi metric baru..."></textarea>
                                <button type="button" class="btn btn-sm btn-primary py-0 px-2 js-save-practice-metric" title="Simpan Metric"><i class="bi bi-check-lg"></i></button>
                                <button type="button" class="btn btn-sm btn-outline-danger py-0 px-2 js-remove-draft-metric" title="Batal"><i class="bi bi-trash"></i></button>
                            </div>
                        `;
                        listContainer.insertAdjacentHTML('beforeend', newRowHtml);
                    });
                },

                setupDraftMetricRemoveHandler() {
                    document.addEventListener('click', (event) => {
                        const removeBtn = event.target.closest('.js-remove-draft-metric');
                        if (!removeBtn) return;

                        const item = removeBtn.closest('.js-practice-metric-item');
                        if (item) {
                            item.remove();
                        }
                    });
                },

                setupToModalHandler() {
                    // Click on the 'To' input triggers opening the modal
                    document.addEventListener('click', (event) => {
                        const toInput = event.target.closest('.js-to-input');
                        if (!toInput) return;

                        // Save reference to the active input
                        STATE.activeToInput = toInput;

                        // Parse the current values
                        const currentValues = toInput.value.split(';').map(v => v.trim()).filter(Boolean);

                        // Populate the modal choices
                        this.populateModalChoices(currentValues);

                        // Open the modal using Bootstrap API
                        const modalEl = document.getElementById('toPracticeModal');
                        if (modalEl) {
                            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
                            modal.show();
                        }
                    });

                    // Search input inside the modal
                    const searchInput = document.getElementById('modalToSearch');
                    if (searchInput) {
                        searchInput.addEventListener('input', (event) => {
                            const query = event.target.value.toLowerCase().trim();
                            const items = document.querySelectorAll('#toPracticeModal .form-check');
                            items.forEach(item => {
                                const searchText = item.getAttribute('data-search-text') || item.textContent.toLowerCase();
                                if (searchText.includes(query)) {
                                    item.style.setProperty('display', '', 'important');
                                } else {
                                    item.style.setProperty('display', 'none', 'important');
                                }
                            });
                        });
                    }

                    // Reset search and focus when modal is shown
                    const modalEl = document.getElementById('toPracticeModal');
                    if (modalEl) {
                        modalEl.addEventListener('shown.bs.modal', () => {
                            if (searchInput) {
                                searchInput.value = '';
                                searchInput.focus();
                            }
                            const items = document.querySelectorAll('#toPracticeModal .form-check');
                            items.forEach(item => {
                                item.style.setProperty('display', '', 'important');
                            });
                        });
                    }

                    // Save button in modal
                    const saveBtn = document.getElementById('modalToSaveBtn');
                    if (saveBtn) {
                        saveBtn.addEventListener('click', () => {
                            if (!STATE.activeToInput) return;

                            const checkedCheckboxes = Array.from(document.querySelectorAll('#toPracticeModal .js-modal-to-checkbox:checked'));
                            const selectedValues = checkedCheckboxes.map(cb => cb.value);

                            // Update the active input and trigger input event so it registers as edited
                            STATE.activeToInput.value = selectedValues.join('; ');
                            STATE.activeToInput.dispatchEvent(new Event('input', { bubbles: true }));

                            // Close the modal
                            const modal = bootstrap.Modal.getInstance(modalEl);
                            if (modal) {
                                modal.hide();
                            }
                        });
                    }
                },

                populateModalChoices(currentValues) {
                    const presetsContainer = document.getElementById('modalToPresetsList');
                    const practicesContainer = document.getElementById('modalToPracticesList');

                    if (!presetsContainer || !practicesContainer) return;

                    // 1. Populate Presets
                    const presets = [
                        'Outside COBIT',
                        'All EDM',
                        'All APO',
                        'All BAI',
                        'All DSS',
                        'All MEA'
                    ];

                    presetsContainer.innerHTML = presets.map((preset, idx) => {
                        const isChecked = currentValues.includes(preset) ? 'checked' : '';
                        return `
                            <div class="form-check py-0.5">
                                <input class="form-check-input js-modal-to-checkbox" type="checkbox" value="${Utils.escapeHtml(preset)}" id="modal_to_preset_${idx}" ${isChecked}>
                                <label class="form-check-label fw-semibold text-dark" for="modal_to_preset_${idx}">${Utils.escapeHtml(preset)}</label>
                            </div>
                        `;
                    }).join('');

                    // 2. Populate Practice Codes
                    practicesContainer.innerHTML = (MASTER_DATA.practices || []).map((p, idx) => {
                        const v = p.practice_id;
                        const name = p.practice_name || '';
                        const isChecked = currentValues.includes(v) ? 'checked' : '';
                        return `
                            <div class="form-check py-0.5" data-search-text="${Utils.escapeHtml((v + ' ' + name).toLowerCase())}">
                                <input class="form-check-input js-modal-to-checkbox" type="checkbox" value="${Utils.escapeHtml(v)}" id="modal_to_practice_${idx}" ${isChecked}>
                                <label class="form-check-label" for="modal_to_practice_${idx}" title="${Utils.escapeHtml(name)}">
                                    <strong>${Utils.escapeHtml(v)}</strong> - <span class="text-muted small">${Utils.escapeHtml(name)}</span>
                                </label>
                            </div>
                        `;
                    }).join('');
                },

                initializeComponent() {
                    try {
                        const params = new URLSearchParams(window.location.search);
                        let compParam = params.get('component') || '{{ $component }}' || '';

                        if (!compParam) {
                            compParam = 'overview';
                        }

                        DOM.componentSelect.value = compParam;
                        DOM.componentSelect.dispatchEvent(new Event('change'));
                    } catch (err) {
                        console.warn('Failed to initialize component select:', err);
                    }
                }
            };

            // ===================================================================
            // INITIALIZATION
            // ===================================================================

            function init() {
                ModeController.setMode('gamo');
                EventListeners.init();
            }

            // Start the application
            init();

        })();
    </script>
@endsection
