@extends('layouts.app')

{{-- 
    PERFORMANCE OPTIMIZATION NOTE:
    Calculations related to grouping activities by capability level have been 
    moved to PHP blocks outside loops to reduce rendering time (complexity reduction).
    CSS property 'content-visibility: auto' is used on cards to improve scrolling performance.
--}}

@section('content')
    <meta name="csrf-token" content="{{ csrf_token() }}">

    {{-- Loading Overlay with Progress --}}
    <style>
        .objective-card {
            content-visibility: auto;
            contain-intrinsic-size: 1px 600px;
            /* Estimate height to prevent scrollbar jumping */
        }
    </style>
    <div id="loading-overlay" class="loading-overlay">
        <div class="loading-content">
            <div class="loading-spinner"></div>
            <div class="loading-text" id="loading-text">Loading...</div>
            <div class="loading-progress-container">
                <div class="loading-progress-bar" id="loading-progress-bar"></div>
            </div>
            <div class="loading-percentage" id="loading-percentage">0%</div>
        </div>
    </div>

    {{-- Non-blocking Corner Loading Indicator --}}
    <div id="corner-loading" class="corner-loading" style="display: none;">
        <div class="corner-loading-content">
            <div class="corner-spinner"></div>
            <div class="corner-loading-info">
                <div class="corner-loading-text" id="corner-loading-text">Loading data...</div>
                <div class="corner-loading-progress">
                    <div class="corner-progress-bar" id="corner-progress-bar"></div>
                </div>
                <div class="corner-loading-percentage" id="corner-loading-percentage">0%</div>
            </div>
        </div>
    </div>

    <div class="container mx-auto p-6" id="page-top">
        {{-- Main Card --}}
        <div class="card shadow-sm mb-4 hero-card" style="border:none;box-shadow:0 22px 45px rgba(14,33,70,0.15);">
            <div class="card-header hero-header py-4"
                style="background:linear-gradient(135deg,#081a3d,#0f2b5c);color:#fff;border:none;">
                <div class="d-flex justify-content-between align-items-start">
                    {{-- Left Side: Title and Info --}}
                    <div>
                        <div class="hero-title" style="font-size:1.5rem;font-weight:700;letter-spacing:0.04em;">COBIT 2019 :
                            I&T Assessment Capability and Maturity</div>
                        <div class="d-flex flex-wrap gap-4 mt-3" style="font-size:0.95rem;">
                            <div>
                                <span style="color:rgba(255,255,255,0.6);">Assessment Id:</span>
                                <span class="fw-bold ms-1">{{ $evalId }}</span>
                            </div>
                            <div>
                                <span style="color:rgba(255,255,255,0.6);">Assessment Year:</span>
                                <span
                                    class="fw-bold ms-1">{{ $evaluation->year ?? ($evaluation->assessment_year ?? ($evaluation->tahun ?? 'N/A')) }}</span>
                            </div>
                            <div>
                                <span style="color:rgba(255,255,255,0.6);">Assessment Scope:</span>
                                <span class="fw-bold ms-1">{{ $activeScope->nama_scope ?? 'No Scope Selected' }}</span>
                            </div>
                        </div>
                    </div>
                    {{-- Right Side: Status Badge --}}
                    <div class="d-flex align-items-center gap-2 flex-wrap justify-content-end">
                        <span id="status-badge" class="assessment-status-chip status-draft">
                            <span class="status-dot"></span>
                            <span class="status-text">Draft</span>
                        </span>

                        {{-- JSON Data for Scope --}}
                        <script>
                            window.ALL_OBJECTIVES_GROUPED = @json(
                                $allObjectives->groupBy(function ($item) {
                                    return preg_replace('/\d+/', '', $item->objective_id);
                                }));
                            window.CURRENT_SCOPE = @json($objectives->pluck('objective_id'));
                            window.UPDATE_SCOPE_URL = "{{ route('assessment.update-scope', $evalId) }}";
                            window.DELETE_SCOPE_URL = "{{ route('assessment.delete-scope') }}";
                            window.SCOPE_DETAILS = @json($scopeDetails ?? []);
                            window.ALL_SCOPES = @json($allScopes ?? []);
                        </script>
                    </div>
                </div>
            </div>
            <div class="card-body">

                <div class="assessment-toolbar-anchor" id="assessment-toolbar-anchor">
                    <div class="domain-tabs-wrapper" id="assessment-toolbar">
                        <div class="domain-tabs" role="tablist">
                            <a href="{{ route('assessment.evidence.index', $evalId) }}"
                                class="domain-tab text-decoration-none d-flex align-items-center"
                                style="background-color: #0f2b5c; color: #fff;">
                                <i class="fas fa-plus me-2"></i>Evidence
                            </a>
                            @if (($canManageAssessment ?? false) && $evaluation->status !== 'finished')
                                <button type="button" class="d-flex align-items-center px-3 py-2 me-1 border-0 fw-bold"
                                    data-bs-toggle="modal" data-bs-target="#editScopeModal"
                                    style="background-color: #0f2b5c; color: #fff; border-radius: 10px; font-size: 0.9rem;">
                                    <i class="fas fa-layer-group me-2"></i>SCOPE
                                </button>
                            @endif
                            <button type="button" class="domain-tab active " data-domain="all">All</button>
                            <button type="button" class="domain-tab" data-domain="EDM">EDM</button>
                            <button type="button" class="domain-tab" data-domain="APO">APO</button>
                            <button type="button" class="domain-tab" data-domain="BAI">BAI</button>
                            <button type="button" class="domain-tab" data-domain="DSS">DSS</button>
                            <button type="button" class="domain-tab" data-domain="MEA">MEA</button>
                            <button type="button" class="domain-tab" data-domain="recap">Summary Result</button>
                            <button type="button" class="domain-tab" data-domain="diagram">Spider Web Diagram</button>
                            <a href="{{ route('assessment.report', $evalId) }}"
                                class="domain-tab text-decoration-none d-flex align-items-center"
                                style="background-color: #0f2b5c; color: #fff;">
                                <i class="fas fa-file-alt me-2"></i>Report
                            </a>
                        </div>
                        <div id="objective-filter-wrapper" class="objective-filter-wrapper" style="display: none;">
                            <div class="objective-filter-tabs" id="objective-filter-tabs" role="tablist"></div>
                        </div>
                    </div>
                </div>

                {{-- Selected domains scope display removed per request --}}

                <div id="domain-overview-wrapper" class="domain-overview-wrapper mt-3" style="display: none;">
                    <button class="domain-overview-toggle" type="button" id="domain-overview-toggle"
                        aria-expanded="true">
                        <span><i class="fas fa-chart-line me-2"></i>Domain Summary Result</span>
                        <i class="fas fa-chevron-up toggle-indicator"></i>
                    </button>
                    <div class="domain-level-card" id="domain-level-overview">
                        <div class="domain-level-header">
                            <div>
                                <h5 class="domain-level-title" id="domain-level-title"></h5>
                            </div>
                            <span class="domain-level-pill" id="domain-level-pill">EDM</span>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th rowspan="2" style="width: 10%; vertical-align: middle;">Gamo</th>
                                        <th rowspan="2" style="width: 25%; vertical-align: middle;">Gamo Name</th>
                                        <th colspan="6" class="text-center">Score</th>
                                        <th rowspan="2" class="text-center"
                                            style="width: 12%; vertical-align: middle;">Value</th>
                                        <th rowspan="2" class="text-center"
                                            style="width: 12%; vertical-align: middle;">Rating</th>
                                        <th rowspan="2" class="text-center"
                                            style="width: 14%; vertical-align: middle;">Maximum Capability</th>
                                    </tr>
                                    <tr>
                                        <th class="text-center" style="width: 10%">0</th>
                                        <th class="text-center" style="width: 10%">1</th>
                                        <th class="text-center" style="width: 10%">2</th>
                                        <th class="text-center" style="width: 10%">3</th>
                                        <th class="text-center" style="width: 10%">4</th>
                                        <th class="text-center" style="width: 10%">5</th>
                                    </tr>
                                </thead>
                                <tbody id="domain-level-rows"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" id="recap-standalone-row" style="display: none;">
            <div class="col-12">
                <div class="recap-standalone-wrapper" id="recap-standalone-wrapper">
                    <div class="recap-standalone-header">
                        <div>
                            <h5 class="recap-title">Assessment Recapitulation Result</h5>
                        </div>
                    </div>
                    <div id="recap-standalone-body"></div>
                </div>
            </div>
        </div>

        <div class="row" id="diagram-standalone-row" style="display: none;">
            <div class="col-12">
                <div class="diagram-standalone-wrapper" id="diagram-standalone-wrapper">
                    <div class="recap-standalone-header">
                        <div>
                            <h5 class="recap-title">Spider Web Diagram</h5>
                        </div>
                    </div>
                    <div id="diagram-standalone-body"></div>
                    <div id="diagram-maturity-container" class="text-center mt-4 pb-4" style="display: none;">
                        <h5 class="text-muted mb-2">I&T Maturity Score</h5>
                        <div id="diagram-maturity-value" class="display-4 fw-bold text-primary"></div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Edit Scope Modal --}}
        <div class="modal fade" id="editScopeModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header border-bottom-0 pb-0">
                        <div>
                            <h5 class="modal-title fw-bold text-primary" id="scopeModalTitle">Edit Scope</h5>
                            <p class="text-muted small mb-0" id="scopeModalDesc">Select the Governance & Management
                                Objectives relevant to this assessment.</p>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body bg-light">
                        {{-- Scope Selector --}}
                        <div class="mb-3">
                            <label for="modalScopeSelector" class="form-label fw-bold">Pilih Scope</label>
                            <div class="input-group">
                                <select id="modalScopeSelector" class="form-select">
                                    @forelse($allScopes as $scope)
                                        <option value="{{ $scope->id }}"
                                            {{ $activeScope && $activeScope->id == $scope->id ? 'selected' : '' }}>
                                            {{ $scope->nama_scope }}
                                        </option>
                                    @empty
                                    @endforelse
                                    <option value="ADD_NEW">+ Tambah Scope Baru</option>
                                </select>
                                <button class="btn btn-outline-primary" type="button" id="btnSwitchScope"
                                    title="Pindah ke scope ini">
                                    <i class="fas fa-external-link-alt me-2"></i>Buka Scope
                                </button>
                            </div>
                        </div>
                        <div id="scopeNameSection" class="mb-3" style="display:none;">
                            <label for="newScopeName" class="form-label fw-bold">Nama Scope</label>
                            <input type="text" class="form-control" id="newScopeName"
                                placeholder="Contoh: Audit Q1, Sistem Kritis">
                        </div>
                        <div id="scopeContainer" class="d-flex flex-column gap-4">
                            <!-- Content generated by JS -->
                        </div>
                    </div>
                    <div class="modal-footer bg-white border-top-0 pt-0 mt-3">
                        <div class="d-flex justify-content-between w-100 align-items-center mt-3">
                            <div class="fw-bold text-primary">
                                <span id="selectedCount" class="fs-5">0</span> objektif dipilih
                            </div>
                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-outline-danger me-2" id="btnDeleteScope"
                                    style="display:none;">
                                    <i class="fas fa-trash-alt me-1"></i>Hapus
                                </button>
                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Batal</button>
                                <button type="button" class="btn btn-primary px-4" id="btnSaveScope">
                                    <span class="spinner-border spinner-border-sm d-none me-2" role="status"
                                        aria-hidden="true"></span>
                                    Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Track which scope is being edited
                window.editingScopeId = null;

                // Modal Scope Selector Handler
                const modalScopeSelector = document.getElementById('modalScopeSelector');
                if (modalScopeSelector) {
                    // Function to update UI based on selected scope
                    function updateScopeUI() {
                        const selectedValue = modalScopeSelector.value;

                        if (selectedValue === 'ADD_NEW') {
                            // Creating new scope
                            window.editingScopeId = null;
                            document.getElementById('scopeModalTitle').textContent = 'Tambah Scope Baru';
                            document.getElementById('scopeModalDesc').textContent =
                                'Masukkan nama untuk scope baru dan pilih domain.';
                            document.getElementById('scopeNameSection').style.display = 'block';
                            document.getElementById('newScopeName').value = '';
                            document.getElementById('btnSwitchScope').style.display = 'none'; // Hide switch button
                            // Hide delete button
                            const btnDel = document.getElementById('btnDeleteScope');
                            if (btnDel) btnDel.style.display = 'none';

                            // Uncheck all checkboxes
                            document.querySelectorAll('.scope-checkbox').forEach(cb => {
                                cb.checked = false;
                            });
                        } else if (selectedValue) {
                            // Editing existing scope - load data without redirect
                            window.editingScopeId = selectedValue;
                            document.getElementById('btnSwitchScope').style.display =
                                'inline-block'; // Show switch button

                            // Show delete button
                            const btnDel = document.getElementById('btnDeleteScope');
                            if (btnDel) btnDel.style.display = 'inline-block';

                            const scopeName = modalScopeSelector.options[modalScopeSelector.selectedIndex].text;

                            document.getElementById('scopeModalTitle').textContent = 'Edit Scope';
                            document.getElementById('scopeModalDesc').textContent =
                                'Ubah nama dan pilihan domain untuk scope ini.';
                            // Show name input for renaming
                            document.getElementById('scopeNameSection').style.display = 'block';
                            document.getElementById('newScopeName').value = scopeName.trim();

                            // Load this scope's selected domains
                            const scopeData = window.SCOPE_DETAILS && window.SCOPE_DETAILS[selectedValue];
                            document.querySelectorAll('.scope-checkbox').forEach(cb => {
                                cb.checked = scopeData && scopeData.domains && scopeData.domains.includes(cb
                                    .value);
                            });
                        }

                        // Update count
                        const countEl = document.getElementById('selectedCount');
                        if (countEl) {
                            countEl.textContent = document.querySelectorAll('.scope-checkbox:checked').length;
                        }
                    }

                    // Switch Scope Button Handler
                    const btnSwitchScope = document.getElementById('btnSwitchScope');
                    if (btnSwitchScope) {
                        btnSwitchScope.addEventListener('click', function() {
                            const selectedValue = modalScopeSelector.value;
                            const scopeName = modalScopeSelector.options[modalScopeSelector.selectedIndex].text;

                            if (selectedValue && selectedValue !== 'ADD_NEW') {
                                // Switch confirmation
                                Swal.fire({
                                    title: 'Pindah Scope?',
                                    text: `Pindah tampilan aktif ke "${scopeName}"?`,
                                    icon: 'question',
                                    showCancelButton: true,
                                    confirmButtonColor: '#0f2b5c',
                                    confirmButtonText: 'Ya, Pindah!',
                                    cancelButtonText: 'Batal'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href =
                                            '{{ route('assessment.show', $evalId) }}?scope_id=' +
                                            selectedValue;
                                    }
                                });
                            }
                        });
                    }

                    // Delete Scope Button Handler
                    const btnDeleteScope = document.getElementById('btnDeleteScope');
                    if (btnDeleteScope) {
                        btnDeleteScope.addEventListener('click', function() {
                            const selectedValue = modalScopeSelector.value;
                            const scopeName = modalScopeSelector.options[modalScopeSelector.selectedIndex].text;

                            if (selectedValue && selectedValue !== 'ADD_NEW') {
                                Swal.fire({
                                    title: 'Hapus Scope?',
                                    text: `Apakah Anda yakin ingin menghapus scope "${scopeName}"?`,
                                    icon: 'warning',
                                    showCancelButton: true,
                                    confirmButtonColor: '#d33',
                                    cancelButtonColor: '#3085d6',
                                    confirmButtonText: 'Ya, Hapus!',
                                    cancelButtonText: 'Batal'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        // AJAX Delete
                                        fetch(window.DELETE_SCOPE_URL, {
                                                method: 'DELETE',
                                                headers: {
                                                    'Content-Type': 'application/json',
                                                    'X-CSRF-TOKEN': document.querySelector(
                                                        'meta[name="csrf-token"]').content
                                                },
                                                body: JSON.stringify({
                                                    scope_id: selectedValue
                                                })
                                            })
                                            .then(response => response.json())
                                            .then(data => {
                                                if (data.success) {
                                                    Swal.fire(
                                                        'Terhapus!',
                                                        'Scope berhasil dihapus.',
                                                        'success'
                                                    ).then(() => {
                                                        window.location.reload();
                                                    });
                                                } else {
                                                    Swal.fire('Gagal', data.message ||
                                                        'Gagal menghapus.', 'error');
                                                }
                                            })
                                            .catch(err => {
                                                console.error(err);
                                                Swal.fire('Error', 'Terjadi kesalahan.', 'error');
                                            });
                                    }
                                });
                            }
                        });
                    }

                    // Listen to change
                    modalScopeSelector.addEventListener('change', updateScopeUI);

                    // Initialize on modal show
                    document.getElementById('editScopeModal').addEventListener('shown.bs.modal', updateScopeUI);
                }

                if (!window.ALL_OBJECTIVES_GROUPED) return;

                const container = document.getElementById('scopeContainer');
                const countEl = document.getElementById('selectedCount');
                const saveBtn = document.getElementById('btnSaveScope');

                // Fixed Order
                const orderedDomains = ['EDM', 'APO', 'BAI', 'DSS', 'MEA'];

                // Collect all objectives in order
                const allObjectives = [];
                orderedDomains.forEach(domain => {
                    const objectives = window.ALL_OBJECTIVES_GROUPED[domain];
                    if (objectives) {
                        allObjectives.push(...objectives);
                    }
                });

                // Build table
                let html = `
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle mb-0" style="font-size: 0.9rem;">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 60px; text-align: center;">
                                <input class="form-check-input" type="checkbox" id="selectAllGamos" style="width: 1.25em; height: 1.25em;" title="Pilih Semua">
                            </th>
                            <th style="width: 100px;">GAMO</th>
                            <th>GAMO Name</th>`;

                // Add column for each existing scope
                if (window.ALL_SCOPES && window.ALL_SCOPES.length > 0) {
                    window.ALL_SCOPES.forEach(scope => {
                        html += `<th style="width: 120px; text-align: center;">${scope.nama_scope}</th>`;
                    });
                }

                html += `
                        </tr>
                    </thead>
                    <tbody>`;

                // Add row for each objective
                allObjectives.forEach(obj => {
                    html += `
                <tr>
                    <td style="text-align: center;">
                        <input class="form-check-input scope-checkbox" type="checkbox" 
                               value="${obj.objective_id}" style="width: 1.25em; height: 1.25em;">
                    </td>
                    <td class="fw-bold">${obj.objective_id}</td>
                    <td>${obj.objective}</td>`;

                    // Add checkmark columns for existing scopes
                    if (window.ALL_SCOPES && window.ALL_SCOPES.length > 0) {
                        window.ALL_SCOPES.forEach(scope => {
                            const isInScope = window.SCOPE_DETAILS[scope.id] &&
                                window.SCOPE_DETAILS[scope.id].domains.includes(obj.objective_id);
                            html += `<td style="text-align: center;">${isInScope ? '✓' : ''}</td>`;
                        });
                    }

                    html += `</tr>`;
                });

                html += `
                    </tbody>
                </table>
            </div>`;

                container.innerHTML = html;

                // Interactive counting
                const checkboxes = document.querySelectorAll('.scope-checkbox');

                function updateUI() {
                    let total = 0;
                    checkboxes.forEach(cb => {
                        if (cb.checked) total++;
                    });
                    countEl.textContent = total;
                }

                checkboxes.forEach(cb => {
                    if (window.CURRENT_SCOPE.includes(cb.value)) {
                        cb.checked = true;
                    }
                    cb.addEventListener('change', updateUI);
                });
                updateUI();

                // Handle Check/Uncheck All
                const selectAllCheckbox = document.getElementById('selectAllGamos');
                if (selectAllCheckbox) {
                    selectAllCheckbox.addEventListener('change', function() {
                        const isChecked = this.checked;
                        checkboxes.forEach(cb => {
                            cb.checked = isChecked;
                        });
                        updateUI();
                    });

                    // Optional: uncheck "Select All" if any individual box is unchecked
                    checkboxes.forEach(cb => {
                        cb.addEventListener('change', function() {
                            if (!this.checked) {
                                selectAllCheckbox.checked = false;
                            } else {
                                // Check if all are checked
                                const allChecked = Array.from(checkboxes).every(c => c.checked);
                                selectAllCheckbox.checked = allChecked;
                            }
                        });
                    });

                    // Initial check state
                    const allChecked = Array.from(checkboxes).length > 0 && Array.from(checkboxes).every(c => c
                        .checked);
                    selectAllCheckbox.checked = allChecked;
                }

                // Save
                saveBtn.addEventListener('click', function() {
                    const selected = Array.from(document.querySelectorAll('.scope-checkbox:checked')).map(cb =>
                        cb.value);

                    if (selected.length === 0) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Belum Ada Objektif Dipilih',
                            text: 'Mohon pilih setidaknya satu objektif.',
                            confirmButtonColor: '#0f2b5c'
                        });
                        return;
                    }

                    const isNewScope = window.editingScopeId === null;
                    const scopeNameInput = document.getElementById('newScopeName');
                    const scopeName = scopeNameInput.value.trim();
                    const actionText = isNewScope ? 'Buat Scope Baru' : 'Perbarui Scope';
                    const confirmText = isNewScope ?
                        `Buat scope "${scopeName}" dengan ${selected.length} objektif?` :
                        `Simpan perubahan pada scope "${scopeName}"?`;

                    if (!scopeName) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Nama Diperlukan',
                            text: 'Mohon masukkan nama scope.',
                            confirmButtonColor: '#0f2b5c'
                        });
                        return;
                    }

                    Swal.fire({
                        title: actionText,
                        text: confirmText,
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonColor: '#0f2b5c',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Ya, Simpan',
                        cancelButtonText: 'Batal'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            performSave(selected);
                        }
                    });
                });

                function performSave(selected) {
                    saveBtn.disabled = true;
                    saveBtn.querySelector('.spinner-border').classList.remove('d-none');

                    // Get scope name
                    const scopeNameInput = document.getElementById('newScopeName');
                    const isNewScope = window.editingScopeId === null;
                    const scopeName = scopeNameInput.value.trim();

                    const payload = isNewScope ? {
                        scopes: selected,
                        nama_scope: scopeName,
                        is_new: true
                    } : {
                        scopes: selected,
                        scope_id: window.editingScopeId,
                        nama_scope: scopeName
                    };

                    fetch(window.UPDATE_SCOPE_URL, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                            },
                            body: JSON.stringify(payload)
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: 'Scope berhasil diperbarui.',
                                    confirmButtonColor: '#0f2b5c',
                                    timer: 1500
                                }).then(() => {
                                    window.location.reload();
                                });
                            } else {
                                throw new Error(data.message || 'Terjadi kesalahan');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal',
                                text: 'Gagal memperbarui scope: ' + error.message,
                                confirmButtonColor: '#0f2b5c'
                            });
                            saveBtn.disabled = false;
                            saveBtn.querySelector('.spinner-border').classList.add('d-none');
                        });
                }
            });
        </script>

        {{-- Ensure SweetAlert2 is loaded --}}
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        {{-- Objectives Cards --}}
        @php
            $domainOrderMap = ['EDM' => 1, 'APO' => 2, 'BAI' => 3, 'DSS' => 4, 'MEA' => 5];
            $sortedObjectives = collect($objectives)->sortBy(function ($objective) use ($domainOrderMap) {
                $domain = preg_replace('/\d+/', '', $objective->objective_id);
                $domainRank = $domainOrderMap[$domain] ?? 99;
                return sprintf('%02d_%s', $domainRank, $objective->objective_id);
            });
        @endphp

        <div class="row" id="objectives-container">
            @foreach ($sortedObjectives as $objective)
                @php
                    $domain = preg_replace('/\d+/', '', $objective->objective_id);

                    // PERFORMANCE OPTIMIZATION: Pre-calculate groupings to avoid N+1 filters in loops
                    $practicesByLevel = [];
                    $allLevels = [];

                    foreach ($objective->practices as $practice) {
                        if ($practice->activities) {
                            foreach ($practice->activities as $activity) {
                                $lvl = $activity->capability_lvl;
                                $allLevels[] = $lvl;

                                if (!isset($practicesByLevel[$lvl])) {
                                    $practicesByLevel[$lvl] = [];
                                }

                                $pId = $practice->practice_id;
                                if (!isset($practicesByLevel[$lvl][$pId])) {
                                    $practicesByLevel[$lvl][$pId] = [
                                        'practice' => $practice,
                                        'activities' => [],
                                    ];
                                }
                                $practicesByLevel[$lvl][$pId]['activities'][] = $activity;
                            }
                        }
                    }

                    $uniqueLevels = array_unique($allLevels);
                    sort($uniqueLevels);
                    $minLevel = !empty($uniqueLevels) ? $uniqueLevels[0] : 2;
                    $maxLevel = min(5, !empty($uniqueLevels) ? end($uniqueLevels) : 2); // Cap at 5

                    // Calculate total Level 2 activities for the header stat
                    $totalLevel2Activities = 0;
                    if (isset($practicesByLevel[2])) {
                        foreach ($practicesByLevel[2] as $pData) {
                            $totalLevel2Activities += count($pData['activities']);
                        }
                    }

                    $practiceSummaryRows = [];
                    $practiceSummaryTotals = [
                        2 => 0,
                        3 => 0,
                        4 => 0,
                        5 => 0,
                        'total' => 0,
                    ];

                    foreach ($objective->practices as $practice) {
                        $levelCounts = [
                            2 => 0,
                            3 => 0,
                            4 => 0,
                            5 => 0,
                        ];

                        foreach ($practice->activities ?? [] as $activity) {
                            $rawLevel = (string) ($activity->capability_lvl ?? '');
                            preg_match('/(\d+)/', $rawLevel, $matches);
                            $levelNumber = isset($matches[1]) ? (int) $matches[1] : null;

                            if ($levelNumber !== null && array_key_exists($levelNumber, $levelCounts)) {
                                $levelCounts[$levelNumber]++;
                            }
                        }

                        $practiceTotal = array_sum($levelCounts);
                        if ($practiceTotal === 0) {
                            continue;
                        }

                        foreach ([2, 3, 4, 5] as $levelNumber) {
                            $practiceSummaryTotals[$levelNumber] += $levelCounts[$levelNumber];
                        }
                        $practiceSummaryTotals['total'] += $practiceTotal;

                        $practiceSummaryRows[] = [
                            'practice_id' => trim((string) $practice->practice_id, '"'),
                            'practice_name' => trim((string) $practice->practice_name, '"'),
                            'counts' => $levelCounts,
                            'total' => $practiceTotal,
                        ];
                    }
                @endphp
                <div class="col-12 mb-4 objective-card" id="objective-{{ $objective->objective_id }}"
                    data-domain="{{ $domain }}" data-objective-id="{{ $objective->objective_id }}"
                    data-objective-name="{{ $objective->objective }}">
                    <div class="card shadow-sm h-100">
                        {{-- Card Header --}}
                        <div class="card-header objective-header py-3">
                            @php
                                $domainFullNames = [
                                    'EDM' => 'Evaluate, Direct, and Monitor',
                                    'APO' => 'Align, Plan, and Organize',
                                    'BAI' => 'Build, Acquire, and Implement',
                                    'DSS' => 'Deliver, Service, and Support',
                                    'MEA' => 'Monitor, Evaluate, and Assess',
                                ];
                                $fullDomainName = $domainFullNames[$domain] ?? $domain;
                            @endphp
                            <div class="objective-hero d-flex justify-content-between align-items-start">
                                <div>
                                    <h5 class="objective-title mb-1">{{ $objective->objective_id }} -
                                        {{ $objective->objective }}</h5>
                                    <div class="objective-domain">{{ $fullDomainName }}</div>
                                </div>
                                <div class="objective-stats text-end">
                                    <div class="objective-stat">{{ $totalLevel2Activities }} activities</div>
                                    <div class="capability-level-display mt-2">
                                        <span class="capability-badge badge-level-1"
                                            id="capability-level-{{ $objective->objective_id }}">
                                            Level <span class="level-number">1</span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            @if ($objective->objective_description || $objective->objective_purpose)
                                <div class="objective-summary mt-3">
                                    @if ($objective->objective_description)
                                        <div class="summary-column">
                                            <div class="summary-label">Description</div>
                                            <p class="objective-description-text mb-0">
                                                {{ $objective->objective_description }}
                                            </p>
                                        </div>
                                    @endif
                                    @if ($objective->objective_purpose)
                                        <div class="summary-column">
                                            <div class="summary-label">Purpose</div>
                                            <p class="objective-purpose-text mb-0">
                                                {{ $objective->objective_purpose }}
                                            </p>
                                        </div>
                                    @endif
                                </div>
                            @endif
                        </div>

                        @if (!empty($practiceSummaryRows))
                            <div class="practice-summary-block">
                                <button class="practice-summary-header practice-summary-toggle" type="button"
                                    data-practice-summary-toggle aria-expanded="true"
                                    aria-controls="practice-summary-content-{{ $objective->objective_id }}">
                                    <div>
                                        <div class="practice-summary-title">Practice Summary {{ $objective->objective_id }}</div>
                                    </div>
                                    <i class="fas fa-chevron-up toggle-indicator"></i>
                                </button>
                                <div class="practice-summary-content"
                                    id="practice-summary-content-{{ $objective->objective_id }}">
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered mb-0 practice-summary-table">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2" class="align-middle">Practice</th>
                                                    <th colspan="4" class="text-center align-middle">Total of Activities
                                                    </th>
                                                    <th rowspan="2" class="text-center align-middle total-col">Total</th>
                                                </tr>
                                            <tr>
                                                <th class="text-center level-col">LV 2</th>
                                                <th class="text-center level-col">LV 3</th>
                                                <th class="text-center level-col">LV 4</th>
                                                <th class="text-center level-col">LV 5</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($practiceSummaryRows as $summaryRow)
                                                    <tr>
                                                        <td class="practice-cell">
                                                            <span
                                                                class="practice-summary-code">{{ $summaryRow['practice_id'] }}</span>
                                                            <span class="practice-summary-name">-
                                                                {{ $summaryRow['practice_name'] }}</span>
                                                        </td>
                                                        @foreach ([2, 3, 4, 5] as $levelNumber)
                                                            <td class="text-center">
                                                                {{ $summaryRow['counts'][$levelNumber] > 0 ? $summaryRow['counts'][$levelNumber] : '-' }}
                                                            </td>
                                                        @endforeach
                                                        <td class="text-center total-col">{{ $summaryRow['total'] }}</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <td class="fw-bold">Total</td>
                                                    @foreach ([2, 3, 4, 5] as $levelNumber)
                                                        <td class="text-center fw-bold">
                                                            {{ $practiceSummaryTotals[$levelNumber] > 0 ? $practiceSummaryTotals[$levelNumber] : '-' }}
                                                        </td>
                                                    @endforeach
                                                    <td class="text-center fw-bold total-col">
                                                        {{ $practiceSummaryTotals['total'] > 0 ? $practiceSummaryTotals['total'] : '-' }}
                                                    </td>
                                                </tr>
                                                <tr class="practice-summary-metric-row">
                                                    <td class="fw-bold">Index</td>
                                                    @foreach ([2, 3, 4, 5] as $levelNumber)
                                                        <td class="text-center">
                                                            <span class="practice-summary-metric-value"
                                                                id="practice-summary-index-{{ $objective->objective_id }}-{{ $levelNumber }}"></span>
                                                        </td>
                                                    @endforeach
                                                    <td class="text-center"></td>
                                                </tr>
                                                <tr class="practice-summary-metric-row">
                                                    <td class="fw-bold">Rating</td>
                                                    @foreach ([2, 3, 4, 5] as $levelNumber)
                                                        <td class="text-center">
                                                            <span class="practice-summary-metric-value"
                                                                id="practice-summary-level-rating-{{ $objective->objective_id }}-{{ $levelNumber }}"></span>
                                                        </td>
                                                    @endforeach
                                                    <td class="text-center"></td>
                                                </tr>
                                                <tr class="practice-summary-metric-row">
                                                    <td class="fw-bold">Capability</td>
                                                    <td colspan="2" class="text-center">
                                                        <span class="practice-summary-metric-value"
                                                            id="practice-summary-value-{{ $objective->objective_id }}">0,00</span>
                                                    </td>
                                                    <td colspan="2" class="text-center">
                                                        <span class="practice-summary-metric-value"
                                                            id="practice-summary-rating-{{ $objective->objective_id }}">0N</span>
                                                    </td>
                                                    <td class="text-center">
                                                        <span class="practice-summary-metric-value"
                                                            id="practice-summary-level-{{ $objective->objective_id }}">0</span>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        @endif

                        {{-- Card Footer with Multi-Level Assessment --}}
                        <div class="card-footer bg-light">
                            @for ($level = $minLevel; $level <= $maxLevel; $level++)
                                @php
                                    $levelActivities = 0;
                                    if (isset($practicesByLevel[$level])) {
                                        foreach ($practicesByLevel[$level] as $pData) {
                                            $levelActivities += count($pData['activities']);
                                        }
                                    }
                                @endphp
                                @if ($levelActivities > 0)
                                    <div class="capability-level-section mb-3" data-level="{{ $level }}">
                                        <div class="level-section-header">
                                            <div class="level-section-info">
                                                <span class="level-pill">Level {{ $level }}</span>
                                                <span class="level-section-subtext">{{ $levelActivities }}
                                                    activities</span>
                                            </div>
                                            <div class="level-section-actions">
                                                <span class="capability-score level-score-chip"
                                                    id="level-score-{{ $objective->objective_id }}-{{ $level }}">
                                                    N (0.00)
                                                </span>
                                                <button type="button" class="btn btn-sm reference-toggle-btn"
                                                    data-reference-toggle
                                                    data-objective-id="{{ $objective->objective_id }}"
                                                    data-level="{{ $level }}"
                                                    aria-pressed="true"
                                                    title="Hide reference">
                                                    <i class="fas fa-eye"></i>
                                                    <span class="reference-toggle-text">Hide Reference</span>
                                                </button>
                                                <button class="btn btn-sm level-toggle-btn toggle-level-details"
                                                    type="button" data-objective-id="{{ $objective->objective_id }}"
                                                    data-level="{{ $level }}"
                                                    data-min-level="{{ $minLevel }}"
                                                    data-required-previous="{{ $level > $minLevel ? 'true' : 'false' }}">
                                                    <i class="fas me-1 fa-chevron-down toggle-icon"></i>
                                                    <span class="toggle-text">Show Assesment</span>
                                                </button>
                                            </div>
                                        </div>

                                        {{-- Assessment Section for this level --}}
                                        <div class="assessment-section mt-3"
                                            id="assessment-{{ $objective->objective_id }}-{{ $level }}"
                                            style="display: none;">

                                            {{-- Activities Assessment for this level --}}
                                            <div class="table-responsive">
                                                <table class="table table-sm table-bordered align-middle assessment-table">
                                                    <thead>
                                                        <tr>
                                                            <th class="text-center" style="width: 55px;">No</th>
                                                            <th style="width: 120px;">Practice</th>
                                                            <th style="width: 200px;">Practice Name</th>
                                                            <th style="width: 340px;">Activity</th>
                                                            <th style="width: 160px; min-width: 120px;">Rating</th>
                                                            <th class="reference-column-header"
                                                                style="width: 260px; min-width: 220px;">Reference</th>
                                                            <th style="width: 220px;">Evidence</th>
                                                            <th style="width: 300px; min-width: 300px;">Notes</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @php
                                                            $activityCounter = 1;
                                                            $practicesForThisLevel = $practicesByLevel[$level] ?? [];
                                                        @endphp
                                                        @foreach ($practicesForThisLevel as $pData)
                                                            @php
                                                                $practice = $pData['practice'];
                                                                $activities = $pData['activities'];
                                                                $practiceReferences = collect($practice->infoflowoutput ?? [])
                                                                    ->map(function ($output) {
                                                                        $description = trim((string) ($output->description ?? ''), '"');
                                                                        $to = trim((string) ($output->to ?? ''), '"');

                                                                        if ($description === '' && $to === '') {
                                                                            return null;
                                                                        }

                                                                        return [
                                                                            'description' => $description,
                                                                            'to' => $to,
                                                                        ];
                                                                    })
                                                                    ->filter()
                                                                    ->values();
                                                            @endphp
                                                            @foreach ($activities as $activity)
                                                                <tr class="activity-row">
                                                                    <td class="text-center fw-semibold">
                                                                        {{ $activityCounter }}</td>
                                                                    <td class="practice-code-cell text-center">
                                                                        <span
                                                                            class="practice-code-text">{{ trim($practice->practice_id, '"') }}</span>
                                                                    </td>
                                                                    <td class="practice-name-cell">
                                                                        <div class="fw-semibold">
                                                                            {{ trim($practice->practice_name, '"') }}</div>
                                                                    </td>
                                                                    <td class="description-cell">
                                                                        <p class="mb-1 fw-medium">
                                                                            {{ trim($activity->description, '"') }}</p>
                                                                    </td>
                                                                    <td class="rating-cell">
                                                                        <select
                                                                            class="form-select form-select-sm activity-rating-select"
                                                                            data-activity-id="{{ $activity->activity_id }}"
                                                                            data-objective-id="{{ $objective->objective_id }}"
                                                                            data-level="{{ $level }}">
                                                                            <option value="">Select Rating</option>
                                                                            <option value="N">None</option>
                                                                            <option value="P">Partially</option>
                                                                            <option value="L">Largely</option>
                                                                            <option value="F">Fully</option>
                                                                        </select>
                                                                    </td>
                                                                    @if ($loop->first)
                                                                        <td class="reference-cell reference-column-cell"
                                                                            rowspan="{{ max(1, count($activities)) }}">
                                                                            @if ($practiceReferences->isNotEmpty())
                                                                                <ul class="reference-list mb-0">
                                                                                    @foreach ($practiceReferences as $reference)
                                                                                        <li>
                                                                                            <div class="reference-description">
                                                                                                {{ $reference['description'] }}</div>
                                                                                            @if ($reference['to'] !== '')
                                                                                                <div class="reference-target">
                                                                                                    To:
                                                                                                    {{ $reference['to'] }}
                                                                                                </div>
                                                                                            @endif
                                                                                        </li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            @else
                                                                                <span class="text-muted small">No reference
                                                                                    available</span>
                                                                            @endif
                                                                        </td>
                                                                    @endif

                                                                    <td class="evidence-cell">
                                                                        <div class="evidence-input-wrapper">
                                                                            <textarea class="form-control form-control-sm assessment-textarea evidence-input d-none"
                                                                                id="evidence_{{ $activity->activity_id }}" name="evidence_{{ $activity->activity_id }}"
                                                                                data-field-type="evidence" data-activity-id="{{ $activity->activity_id }}"
                                                                                data-objective-id="{{ $objective->objective_id }}" data-level="{{ $level }}" rows="2" readonly
                                                                                style="background-color: #f8f9fa;" placeholder="Select evidence from the list..."></textarea>
                                                                            <div class="evidence-display"
                                                                                data-activity-id="{{ $activity->activity_id }}">
                                                                                <span class="text-muted small">No evidence
                                                                                    added</span>
                                                                            </div>
                                                                            <div class="d-flex gap-2 align-items-center">
                                                                                <button type="button"
                                                                                    class="btn btn-outline-secondary btn-sm evidence-modal-trigger"
                                                                                    data-activity-id="{{ $activity->activity_id }}"
                                                                                    data-objective-id="{{ $objective->objective_id }}"
                                                                                    data-level="{{ $level }}">
                                                                                    Pilih Evidence
                                                                                </button>
                                                                                <select
                                                                                    class="form-select form-select-sm evidence-history-select d-none"
                                                                                    data-activity-id="{{ $activity->activity_id }}"
                                                                                    data-objective-id="{{ $objective->objective_id }}"
                                                                                    data-level="{{ $level }}"
                                                                                    data-placeholder="Select saved evidence">
                                                                                    <option value="">Select saved
                                                                                        evidence...</option>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </td>

                                                                    <td class="notes-cell">
                                                                        <textarea class="form-control form-control-sm assessment-textarea note-input" id="note_{{ $activity->activity_id }}"
                                                                            name="note_{{ $activity->activity_id }}" data-field-type="note" data-activity-id="{{ $activity->activity_id }}"
                                                                            data-objective-id="{{ $objective->objective_id }}" data-level="{{ $level }}" rows="2"
                                                                            placeholder="Enter additional notes or comments..."></textarea>
                                                                    </td>
                                                                </tr>
                                                                @php $activityCounter++; @endphp
                                                            @endforeach
                                                        @endforeach
                                                        @if ($activityCounter === 1)
                                                            <tr>
                                                                <td colspan="8" class="text-center text-muted py-4">
                                                                    <i class="fas fa-info-circle me-2"></i>
                                                                    No practices with Level {{ $level }} activities
                                                                    found for assessment.
                                                                </td>
                                                            </tr>
                                                        @endif
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            @endfor
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        {{-- No Results Message --}}
        <div id="no-results" class="text-center py-5" style="display: none;">
            <div class="card shadow-sm">
                <div class="card-body py-5">
                    <i class="fas fa-search text-muted mb-3" style="font-size: 3rem;"></i>
                    <h5 class="text-muted">No objectives found</h5>
                    <p class="text-muted">Try selecting a different domain filter.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Evidence modal -->
    <div class="modal fade" id="evidenceModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Pilih Evidence</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive" style="max-height: 420px; overflow-y: auto;">
                        <table class="table table-sm table-bordered table-hover mb-0" id="evidence-modal-table">
                            <thead>
                                <tr>
                                    <th style="width: 60px;">Pilih</th>
                                    <th class="text-center" style="width: 50px;">No</th>
                                    <th>Judul Dokumen</th>
                                    <th>No. Dokumen</th>
                                    <th class="text-center">Grup</th>
                                    <th>Tipe</th>
                                    <th class="text-center" style="width: 110px;">Tahun Terbit</th>
                                    <th class="text-center" style="width: 130px;">Tahun Kadaluarsa</th>
                                    <th>Pemilik</th>
                                    <th>Pengesahan</th>
                                    <th class="text-center">Klasifikasi</th>
                                    <th>Ringkasan</th>
                                </tr>
                                <tr class="table-light">
                                    <th></th>
                                    <th></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari judul" data-filter-field="judul_dokumen"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari no dok" data-filter-field="no_dokumen"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari grup" data-filter-field="grup"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari tipe" data-filter-field="tipe"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari terbit" data-filter-field="tahun_terbit"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari kadaluarsa" data-filter-field="tahun_kadaluarsa"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari pemilik" data-filter-field="pemilik_dokumen"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari pengesahan" data-filter-field="pengesahan"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari klasifikasi" data-filter-field="klasifikasi"></th>
                                    <th><input type="text" class="form-control form-control-sm"
                                            placeholder="Cari ringkasan" data-filter-field="summary"></th>
                                </tr>
                            </thead>
                            <tbody id="evidence-modal-table-body"></tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <div class="d-flex align-items-center gap-3">
                        <span id="evidence-modal-page-info" class="text-muted small">page 1 of 1</span>
                        <div class="btn-group btn-group-sm">
                            <button type="button" class="btn btn-outline-secondary" id="evidence-modal-prev">
                                <i class="fas fa-chevron-left"></i>
                            </button>
                            <button type="button" class="btn btn-outline-secondary" id="evidence-modal-next">
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                    <div>
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button type="button" class="btn btn-primary" id="evidence-modal-apply">Gunakan
                            Evidence</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @php($canManageAssessment = (bool) ($canManageAssessment ?? false))

    <div class="sticky-action-group">
        @if ($canManageAssessment)
            <button type="button" class="sticky-action-btn btn btn-primary" id="save-assessment"
                title="Save Assessment">
                <i class="fas fa-save me-2"></i>Save
            </button>
            <button type="button" class="sticky-action-btn btn btn-success" id="btn-finish-assessment"
                style="display: none;" title="Finish Assessment">
                <i class="fas fa-check-circle me-2"></i>Finish
            </button>
            <button type="button" class="sticky-action-btn btn btn-warning" id="btn-unlock-assessment"
                style="display: none;" title="Edit Assessment">
                <i class="fas fa-edit me-2"></i>Edit
            </button>
        @endif
        <a href="{{ route('assessment.index') }}" class="sticky-action-btn btn btn-light" title="Back to List">
            <i class="fas fa-arrow-left me-2"></i>Back
        </a>
        <button type="button" class="sticky-action-btn btn btn-light" id="back-to-top-btn" title="Back to Top">
            <i class="fas fa-arrow-up me-2"></i>Top
        </button>
        <a href="{{ url('/') }}" class="sticky-action-btn btn btn-light" title="Go to Home">
            <i class="fas fa-home me-2"></i>Home
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Server-provided manage flag to control editable UI state
        window.CAN_MANAGE_ASSESSMENT = {{ $canManageAssessment ? 'true' : 'false' }};
        // Selected domains (GAMO) provided by server — used by the Scope tab
        window.SELECTED_DOMAINS = {!! json_encode($selectedDomains ?? []) !!};
        // Server-provided evidences
        window.SERVER_EVIDENCES = {!! json_encode($evidences ?? []) !!};
        // Target capability map keyed by GAMO (only when assessment year matches Target Capability year)
        window.TARGET_CAPABILITY_MAP = {!! json_encode($targetCapabilityMap ?? []) !!};
        const spiderDiagramClientName = @json($evaluation->organization->organization_name ?? 'N/A');
        class COBITAssessmentManager {
            constructor(evalId, status = 'draft', canManageAssessment = false) {
                this.assessmentData = {};
                this.levelScores = {};
                this.currentEvalId = evalId;
                this.status = status;
                this.canManageAssessment = (canManageAssessment === true || canManageAssessment === 'true');
                this.evidenceLibrary = new Set();
                this.diagramChartInstance = null;
                this.objectiveCapabilityLevels = {};
                this.activeDomainFilter = 'all';
                this.activeObjectiveFilter = 'all';
                this.domainChartContainer = null;
                this.domainChartWrapper = null;
                this.domainOverviewToggle = null;
                this.domainChartCollapsed = true;
                this.domainChartHasData = false;
                this.domainChartRows = null;
                this.domainChartTitle = null;
                this.domainChartPill = null;
                this.objectiveFilterWrapper = null;
                this.objectiveFilterTabs = null;
                this.domainObjectiveMap = {};
                this.objectiveCards = [];
                this.targetCapabilityMap = window.TARGET_CAPABILITY_MAP || {};
                this.cache = {
                    elements: new Map(),
                    data: new Map()
                };
                this.elementCache = {
                    ratingSelects: new Map(),
                    evidenceInputs: new Map(),
                    noteInputs: new Map()
                };
                this.evidenceModalTableBody = null;
                this.evidenceModalFilterInputs = [];
                this.evidenceModalFilters = {};
                this.currentEvidenceModalExistingValues = [];
                this.evidenceModalData = Array.isArray(window.SERVER_EVIDENCES) ? window.SERVER_EVIDENCES : [];
                this.objectiveDisplayMetrics = {};

                // Modal Pagination
                this.evidenceModalPagination = {
                    currentPage: 1,
                    itemsPerPage: 50
                };

                // Configuration Variables
                this.config = {
                    levelColors: {
                        0: '#dc3545', // Red
                        1: '#f97316', // Orange
                        2: '#facc15', // Yellow
                        3: '#86efac', // Light Green
                        4: '#15803d', // Green
                        5: '#0f6ad9' // Blue
                    },
                    levelTextColors: {
                        0: '#fff',
                        1: '#fff',
                        2: '#7a5d07',
                        3: '#065f46',
                        4: '#fff',
                        5: '#fff'
                    },
                    domainOrder: ['EDM', 'APO', 'BAI', 'DSS', 'MEA'],
                    domainNames: {
                        'EDM': 'Evaluate, Direct, and Monitor',
                        'APO': 'Align, Plan, and Organize',
                        'BAI': 'Build, Acquire, and Implement',
                        'DSS': 'Deliver, Service, and Support',
                        'MEA': 'Monitor, Evaluate, and Assess'
                    },
                    ratingMap: {
                        'N': 0,
                        'P': 1 / 3,
                        'L': 2 / 3,
                        'F': 1
                    },
                    scoreThresholds: {
                        partial: 0.15,
                        largely: 0.50,
                        fully: 0.85
                    },
                    badgeClasses: ['badge-level-0', 'badge-level-1', 'badge-level-2', 'badge-level-3',
                        'badge-level-4', 'badge-level-5'
                    ],
                    allObjectives: [
                        'EDM01', 'EDM02', 'EDM03', 'EDM04', 'EDM05',
                        'APO01', 'APO02', 'APO03', 'APO04', 'APO05', 'APO06', 'APO07', 'APO08', 'APO09',
                        'APO10', 'APO11', 'APO12', 'APO13', 'APO14',
                        'BAI01', 'BAI02', 'BAI03', 'BAI04', 'BAI05', 'BAI06', 'BAI07', 'BAI08', 'BAI09',
                        'BAI10', 'BAI11',
                        'DSS01', 'DSS02', 'DSS03', 'DSS04', 'DSS05', 'DSS06',
                        'MEA01', 'MEA02', 'MEA03', 'MEA04'
                    ],
                    maxCaps: [
                        4, 5, 4, 4, 4, 5, 4, 5, 4, 5, 5, 4, 5, 4, 5, 5, 5, 5, 5, 5,
                        4, 4, 5, 5, 4, 5, 5, 5, 5, 4, 5, 5, 5, 5, 4, 5, 5, 5, 5, 4
                    ]
                };

                this.currentSessionSelectedEvidence = new Set();

                this.init();
            }

            init() {
                this.cacheLoadingElements();
                this.buildElementCache();
                this.initializeEvidenceLibrary();
                this.showLoading('Initializing assessment...', 0);
                this.setupEvidenceModal();

                setTimeout(() => {
                    this.cacheDomainChartElements();
                    this.updateLoadingProgress('Loading components...', 10);

                    this.cacheObjectiveFilterElements();
                    this.updateLoadingProgress('Building domain map...', 20);

                    this.buildDomainObjectiveMap();
                    this.updateLoadingProgress('Setting up filters...', 30);

                    this.setupDomainFiltering();
                    this.updateLoadingProgress('Setting up assessment...', 40);

                    this.setupAssessmentToggles();
                    this.setupReferenceColumnToggles();
                    this.updateLoadingProgress('Setting up activity rating...', 50);

                    this.setupActivityRating();
                    this.updateLoadingProgress('Initializing states...', 60);

                    this.initializeDefaultStates();
                    this.updateLoadingProgress('Setting up buttons...', 70);

                    this.setupFinishUnlockButtons();
                    this.checkInitialStatus();
                    this.setupSaveLoadButtons();
                    this.setupDomainOverviewAccordion();
                    this.setupPracticeSummaryAccordions();
                    this.setupBackToTopButton();
                    this.setupEvidenceListener();
                    this.updateLoadingProgress('Loading assessment data...', 80);

                    this.loadAssessment();
                    this.updateLoadingProgress('Finalizing...', 90);

                    this.refreshEvidenceDropdowns();
                    this.updateLoadingProgress('Complete!', 100);

                    setTimeout(() => this.hideLoading(), 500);
                }, 100);
            }

            initializeEvidenceLibrary() {
                this.evidenceLibrary = new Set();
                if (window.SERVER_EVIDENCES && Array.isArray(window.SERVER_EVIDENCES)) {
                    window.SERVER_EVIDENCES.forEach(ev => {
                        let label = ev.judul_dokumen || '';
                        this.evidenceLibrary.add(label.trim());
                    });
                }
            }

            setupEvidenceModal() {
                this.evidenceModalEl = document.getElementById('evidenceModal');
                this.evidenceModalTableBody = this.evidenceModalEl ? this.evidenceModalEl.querySelector(
                    '#evidence-modal-table-body') : null;
                this.evidenceModalFilterInputs = this.evidenceModalEl ? Array.from(this.evidenceModalEl
                    .querySelectorAll('#evidence-modal-table thead input[data-filter-field]')) : [];
                this.evidenceModalApplyBtn = document.getElementById('evidence-modal-apply');

                // Pagination Elements
                this.evidenceModalPrevBtn = document.getElementById('evidence-modal-prev');
                this.evidenceModalNextBtn = document.getElementById('evidence-modal-next');
                this.evidenceModalPageInfo = document.getElementById('evidence-modal-page-info');

                if (this.evidenceModalEl && window.bootstrap) {
                    this.evidenceModalInstance = bootstrap.Modal.getOrCreateInstance(this.evidenceModalEl);
                }

                if (this.evidenceModalApplyBtn) {
                    this.evidenceModalApplyBtn.addEventListener('click', () => this.applyEvidenceModalSelection());
                }

                if (this.evidenceModalPrevBtn) {
                    this.evidenceModalPrevBtn.addEventListener('click', () => this.changeEvidenceModalPage(-1));
                }

                if (this.evidenceModalNextBtn) {
                    this.evidenceModalNextBtn.addEventListener('click', () => this.changeEvidenceModalPage(1));
                }

                this.bindEvidenceModalFilters();
            }

            bindEvidenceModalFilters() {
                this.evidenceModalFilterInputs.forEach((input) => {
                    const field = input.getAttribute('data-filter-field');
                    if (!field) return;
                    if (this.evidenceModalFilters[field]) {
                        input.value = this.evidenceModalFilters[field];
                    }
                    input.addEventListener('input', (event) => {
                        this.evidenceModalFilters[field] = event.target.value || '';
                        this.evidenceModalPagination.currentPage = 1; // Reset to page 1 on filter
                        this.renderEvidenceModalRows();
                    });
                });
            }

            getFilteredEvidenceModalList() {
                if (!Array.isArray(this.evidenceModalData) || !this.evidenceModalData.length) {
                    return [];
                }
                const filters = Object.entries(this.evidenceModalFilters || {}).filter(([, value]) => value && value
                    .toString().trim());
                if (!filters.length) {
                    return this.evidenceModalData;
                }
                return this.evidenceModalData.filter((item) => {
                    return filters.every(([field, value]) => {
                        const hay = (item[field] ?? '').toString().toLowerCase();
                        return hay.includes(value.toLowerCase());
                    });
                });
            }

            formatEvidenceLabel(item) {
                if (!item) return '';
                return (item.judul_dokumen || '').trim() || '-';
            }

            renderEvidenceModalRows() {
                if (!this.evidenceModalTableBody) return;
                this.evidenceModalTableBody.innerHTML = '';

                const list = this.getFilteredEvidenceModalList();

                // Calculate pagination
                const totalItems = list.length;
                const totalPages = Math.max(1, Math.ceil(totalItems / this.evidenceModalPagination.itemsPerPage));

                // Ensure current page is valid
                if (this.evidenceModalPagination.currentPage > totalPages) {
                    this.evidenceModalPagination.currentPage = totalPages;
                }
                if (this.evidenceModalPagination.currentPage < 1) {
                    this.evidenceModalPagination.currentPage = 1;
                }

                // Update UI controls
                if (this.evidenceModalPageInfo) {
                    this.evidenceModalPageInfo.textContent =
                        `page ${this.evidenceModalPagination.currentPage} of ${totalPages} (${totalItems} items)`;
                }
                if (this.evidenceModalPrevBtn) {
                    this.evidenceModalPrevBtn.disabled = this.evidenceModalPagination.currentPage <= 1;
                }
                if (this.evidenceModalNextBtn) {
                    this.evidenceModalNextBtn.disabled = this.evidenceModalPagination.currentPage >= totalPages;
                }

                if (!list.length) {
                    const emptyRow = document.createElement('tr');
                    emptyRow.innerHTML =
                        '<td colspan="12" class="text-center text-muted py-4">Belum ada evidence yang sesuai.</td>';
                    this.evidenceModalTableBody.appendChild(emptyRow);
                    return;
                }

                // Slice data for current page
                const startIndex = (this.evidenceModalPagination.currentPage - 1) * this.evidenceModalPagination
                    .itemsPerPage;
                const endIndex = startIndex + this.evidenceModalPagination.itemsPerPage;
                const displayList = list.slice(startIndex, endIndex);



                displayList.forEach((item, index) => {
                    const rawLabel = this.formatEvidenceLabel(item);
                    const safeLabel = this.escapeHtml(rawLabel);
                    const isChecked = this.currentSessionSelectedEvidence.has(rawLabel);
                    const tr = document.createElement('tr');
                    // Show global index instead of page index
                    const globalIndex = startIndex + index + 1;

                    tr.innerHTML = `
                <td class="text-center align-middle">
                    <input type="checkbox" class="form-check-input" data-raw-label="${safeLabel}" id="evidence-modal-checkbox-${startIndex + index}" ${isChecked ? 'checked' : ''}>
                </td>
                <td class="text-center align-middle">${globalIndex}</td>
                <td class="align-middle">${this.escapeHtml(item.judul_dokumen || '-')}</td>
                <td class="align-middle">${this.escapeHtml(item.no_dokumen || '-')}</td>
                <td class="text-center align-middle">${this.escapeHtml(item.grup || '-')}</td>
                <td class="align-middle">${this.escapeHtml(item.tipe || '-')}</td>
                <td class="text-center align-middle">${this.escapeHtml(item.tahun_terbit || '-')}</td>
                <td class="text-center align-middle">${this.escapeHtml(item.tahun_kadaluarsa || '-')}</td>
                <td class="align-middle">${this.escapeHtml(item.pemilik_dokumen || '-')}</td>
                <td class="align-middle">${this.escapeHtml(item.pengesahan || '-')}</td>
                <td class="text-center align-middle">${this.escapeHtml(item.klasifikasi || '-')}</td>
                <td class="align-middle">${this.escapeHtml(item.summary || '-')}</td>
            `;

                    const checkbox = tr.querySelector('.form-check-input');
                    checkbox.addEventListener('change', (e) => {
                        if (e.target.checked) {
                            this.currentSessionSelectedEvidence.add(rawLabel);
                        } else {
                            this.currentSessionSelectedEvidence.delete(rawLabel);
                        }
                    });

                    this.evidenceModalTableBody.appendChild(tr);
                });
            }

            changeEvidenceModalPage(direction) {
                const next = this.evidenceModalPagination.currentPage + direction;
                if (next < 1) return;
                this.evidenceModalPagination.currentPage = next;
                this.renderEvidenceModalRows();
            }

            openEvidenceModal(activityId) {
                if (!this.evidenceModalTableBody || !this.evidenceModalInstance) {
                    return;
                }

                this.currentEvidenceModalActivityId = activityId;
                this.currentSessionSelectedEvidence = new Set(this.getExistingEvidenceValues(activityId));
                this.renderEvidenceModalRows();
                this.evidenceModalInstance.show();
            }

            applyEvidenceModalSelection() {
                const activityId = this.currentEvidenceModalActivityId;
                if (!activityId || !this.evidenceModalTableBody) {
                    return;
                }

                const checked = Array.from(this.currentSessionSelectedEvidence).filter(Boolean);

                const textarea = this.elementCache.evidenceInputs.get(activityId);
                if (textarea) {
                    textarea.value = checked.join('\n');
                    textarea.dispatchEvent(new Event('input', {
                        bubbles: true
                    }));
                    this.updateEvidenceDisplay(activityId, textarea.value);
                }

                if (this.evidenceModalInstance) {
                    this.evidenceModalInstance.hide();
                }
            }

            getExistingEvidenceValues(activityId) {
                const textarea = this.elementCache.evidenceInputs.get(activityId);
                if (!textarea || !textarea.value) {
                    return [];
                }
                return textarea.value.split('\n').map(v => v.trim()).filter(Boolean);
            }

            initializeDefaultStates() {
                const objectiveCards = document.querySelectorAll('.objective-card');
                objectiveCards.forEach(card => {
                    const objectiveId = card.getAttribute('data-objective-id');
                    if (!this.objectiveCapabilityLevels[objectiveId]) {
                        this.objectiveCapabilityLevels[objectiveId] = 1;
                    }
                    const levelSections = card.querySelectorAll('.capability-level-section');

                    levelSections.forEach(section => {
                        const level = parseInt(section.getAttribute('data-level'));
                        this.initializeLevelScore(objectiveId, level);
                        this.updateLevelDisplay(objectiveId, level);
                        this.checkLevelLock(objectiveId, level);
                    });

                    // Update overall objective capability level
                    this.updateObjectiveCapabilityLevel(objectiveId);
                });
            }

            resetAssessmentFields() {
                this.levelScores = {};
                this.objectiveCapabilityLevels = {};
                this.objectiveDisplayMetrics = {};
                this.initializeEvidenceLibrary();

                if (this.elementCache.ratingSelects) {
                    this.elementCache.ratingSelects.forEach(select => {
                        select.value = '';
                        select.classList.remove('rating-full', 'rating-high', 'rating-medium', 'rating-low');
                    });
                }

                if (this.elementCache.evidenceInputs) {
                    this.elementCache.evidenceInputs.forEach(textarea => {
                        textarea.value = '';
                    });
                }

                if (this.elementCache.noteInputs) {
                    this.elementCache.noteInputs.forEach(textarea => {
                        textarea.value = '';
                    });
                }

                this.initializeDefaultStates();
            }

            initializeLevelScore(objectiveId, level) {
                if (!this.levelScores[objectiveId]) {
                    this.levelScores[objectiveId] = {};
                }
                if (!this.levelScores[objectiveId][level]) {
                    this.levelScores[objectiveId][level] = {
                        letter: 'N',
                        score: 0.00,
                        activities: {},
                        evidence: {},
                        notes: {}
                    };
                }
            }

            setupSaveLoadButtons() {
                const saveBtn = document.getElementById('save-assessment');
                const loadBtn = document.getElementById('load-assessment');

                if (saveBtn) {
                    saveBtn.addEventListener('click', () => this.saveAssessment());
                }

                if (loadBtn) {
                    loadBtn.addEventListener('click', () => this.loadAssessment(true));
                }
            }

            cacheLoadingElements() {
                this.loadingOverlay = document.getElementById('loading-overlay');
                this.loadingText = document.getElementById('loading-text');
                this.loadingProgressBar = document.getElementById('loading-progress-bar');
                this.loadingPercentage = document.getElementById('loading-percentage');
                this.cornerLoading = document.getElementById('corner-loading');
                this.cornerLoadingText = document.getElementById('corner-loading-text');
                this.cornerProgressBar = document.getElementById('corner-progress-bar');
                this.cornerLoadingPercentage = document.getElementById('corner-loading-percentage');
            }

            buildElementCache() {
                // Cache all rating selects once
                document.querySelectorAll('.activity-rating-select').forEach(el => {
                    this.elementCache.ratingSelects.set(el.dataset.activityId, el);
                });

                // Cache all evidence inputs
                document.querySelectorAll('.evidence-input').forEach(el => {
                    this.elementCache.evidenceInputs.set(el.dataset.activityId, el);
                });

                // Cache all note inputs
                document.querySelectorAll('.note-input').forEach(el => {
                    this.elementCache.noteInputs.set(el.dataset.activityId, el);
                });
            }

            showLoading(message = 'Loading...', percentage = 0) {
                if (this.loadingOverlay) {
                    this.loadingOverlay.style.display = 'flex';
                    if (this.loadingText) this.loadingText.textContent = message;
                    if (this.loadingProgressBar) this.loadingProgressBar.style.width = percentage + '%';
                    if (this.loadingPercentage) this.loadingPercentage.textContent = Math.round(percentage) + '%';
                }
            }

            updateLoadingProgress(message, percentage) {
                if (this.loadingText) this.loadingText.textContent = message;
                if (this.loadingProgressBar) this.loadingProgressBar.style.width = percentage + '%';
                if (this.loadingPercentage) this.loadingPercentage.textContent = Math.round(percentage) + '%';
            }

            hideLoading() {
                if (this.loadingOverlay) {
                    this.loadingOverlay.style.opacity = '0';
                    setTimeout(() => {
                        this.loadingOverlay.style.display = 'none';
                        this.loadingOverlay.style.opacity = '1';
                    }, 300);
                }
            }

            showCornerLoading(message = 'Loading...', percentage = 0) {
                if (this.cornerLoading) {
                    this.cornerLoading.style.display = 'flex';
                    this.cornerLoading.classList.add('show');
                    if (this.cornerLoadingText) this.cornerLoadingText.textContent = message;
                    if (this.cornerProgressBar) this.cornerProgressBar.style.width = percentage + '%';
                    if (this.cornerLoadingPercentage) this.cornerLoadingPercentage.textContent = Math.round(
                        percentage) + '%';
                }
            }

            updateCornerProgress(message, percentage) {
                if (this.cornerLoadingText) this.cornerLoadingText.textContent = message;
                if (this.cornerProgressBar) this.cornerProgressBar.style.width = percentage + '%';
                if (this.cornerLoadingPercentage) this.cornerLoadingPercentage.textContent = Math.round(percentage) +
                    '%';
            }

            hideCornerLoading() {
                if (this.cornerLoading) {
                    this.cornerLoading.classList.remove('show');
                    setTimeout(() => {
                        this.cornerLoading.style.display = 'none';
                    }, 400);
                }
            }

            cacheDomainChartElements() {
                this.domainChartWrapper = document.getElementById('domain-overview-wrapper');
                this.domainChartContainer = document.getElementById('domain-level-overview');
                this.domainChartRows = document.getElementById('domain-level-rows');
                this.domainChartTitle = document.getElementById('domain-level-title');
                this.domainChartPill = document.getElementById('domain-level-pill');
                this.domainOverviewToggle = document.getElementById('domain-overview-toggle');
                this.domainChartTable = document.querySelector('.domain-level-table');
                this.recapStandaloneRow = document.getElementById('recap-standalone-row');
                this.recapStandaloneWrapper = document.getElementById('recap-standalone-wrapper');
                this.recapStandaloneBody = document.getElementById('recap-standalone-body');
                this.diagramStandaloneRow = document.getElementById('diagram-standalone-row');
                this.diagramStandaloneWrapper = document.getElementById('diagram-standalone-wrapper');
                this.diagramStandaloneBody = document.getElementById('diagram-standalone-body');
            }

            cacheObjectiveFilterElements() {
                this.objectiveFilterWrapper = document.getElementById('objective-filter-wrapper');
                this.objectiveFilterTabs = document.getElementById('objective-filter-tabs');
            }

            buildDomainObjectiveMap() {
                this.objectiveCards = Array.from(document.querySelectorAll('.objective-card'));
                this.domainObjectiveMap = {};

                this.objectiveCards.forEach(card => {
                    const domain = card.getAttribute('data-domain');
                    const objectiveId = card.getAttribute('data-objective-id');
                    const objectiveName = card.getAttribute('data-objective-name') || objectiveId;

                    if (!domain || !objectiveId) {
                        return;
                    }

                    if (!this.domainObjectiveMap[domain]) {
                        this.domainObjectiveMap[domain] = [];
                    }

                    this.domainObjectiveMap[domain].push({
                        id: objectiveId,
                        name: objectiveName
                    });
                });

                Object.keys(this.domainObjectiveMap).forEach(domainKey => {
                    this.domainObjectiveMap[domainKey].sort((a, b) => a.id.localeCompare(b.id, undefined, {
                        numeric: true
                    }));
                });
            }

            renderObjectiveFilterTabs(domain) {
                if (!this.objectiveFilterWrapper || !this.objectiveFilterTabs) {
                    return;
                }

                if (domain === 'all' || domain === 'recap' || domain === 'diagram' || !this.domainObjectiveMap[
                        domain] || this.domainObjectiveMap[domain].length === 0) {
                    this.objectiveFilterWrapper.style.display = 'none';
                    this.objectiveFilterTabs.innerHTML = '';
                    this.activeObjectiveFilter = 'all';
                    return;
                }

                this.objectiveFilterWrapper.style.display = 'block';
                this.activeObjectiveFilter = 'all';

                const objectives = this.domainObjectiveMap[domain];
                const tabsHtml = [
                    `<button type="button" class="objective-filter-tab active" data-objective="all">
                All
            </button>`
                ];

                objectives.forEach(obj => {
                    const safeCode = this.escapeHtml(obj.id);
                    tabsHtml.push(`
                <button type="button" class="objective-filter-tab" data-objective="${safeCode}">
                    ${safeCode}
                </button>
            `);
                });

                this.objectiveFilterTabs.innerHTML = tabsHtml.join('');
                const buttons = this.objectiveFilterTabs.querySelectorAll('.objective-filter-tab');

                buttons.forEach(button => {
                    button.addEventListener('click', () => {
                        buttons.forEach(btn => btn.classList.remove('active'));
                        button.classList.add('active');
                        const objectiveId = button.getAttribute('data-objective');
                        this.applyObjectiveFilter(objectiveId);
                    });
                });
            }

            applyObjectiveFilter(objectiveId) {
                this.activeObjectiveFilter = objectiveId || 'all';
                this.updateObjectiveVisibility();
            }

            updateObjectiveVisibility() {
                const cards = this.objectiveCards.length ? this.objectiveCards : Array.from(document.querySelectorAll(
                    '.objective-card'));
                const noResultsDiv = document.getElementById('no-results');
                let visibleCount = 0;

                if (this.activeDomainFilter === 'recap' || this.activeDomainFilter === 'diagram') {
                    cards.forEach(card => {
                        card.style.display = 'none';
                    });
                    if (noResultsDiv) {
                        noResultsDiv.style.display = 'none';
                    }
                    return;
                }

                cards.forEach(card => {
                    const cardDomain = card.getAttribute('data-domain');
                    const cardObjective = card.getAttribute('data-objective-id');
                    const matchesDomain = this.activeDomainFilter === 'all' ||
                        this.activeDomainFilter === 'recap' ||
                        this.activeDomainFilter === 'diagram' ||
                        cardDomain === this.activeDomainFilter;
                    const matchesObjective = this.activeObjectiveFilter === 'all' || cardObjective === this
                        .activeObjectiveFilter;

                    if (matchesDomain && matchesObjective) {
                        card.style.display = 'block';
                        visibleCount++;
                    } else {
                        card.style.display = 'none';
                    }
                });

                if (noResultsDiv) {
                    noResultsDiv.style.display = visibleCount === 0 ? 'block' : 'none';
                }
            }

            setupDomainOverviewAccordion() {
                if (!this.domainOverviewToggle) {
                    return;
                }
                this.domainOverviewToggle.addEventListener('click', () => {
                    this.domainChartCollapsed = !this.domainChartCollapsed;
                    this.updateDomainOverviewVisibility();
                });
            }

            setupPracticeSummaryAccordions() {
                const toggleButtons = document.querySelectorAll('[data-practice-summary-toggle]');
                toggleButtons.forEach((button) => {
                    button.addEventListener('click', () => {
                        const summaryBlock = button.closest('.practice-summary-block');
                        const summaryContent = summaryBlock ? summaryBlock.querySelector('.practice-summary-content') :
                            null;
                        if (!summaryBlock || !summaryContent) {
                            return;
                        }

                        const isExpanded = button.getAttribute('aria-expanded') !== 'false';
                        summaryBlock.classList.toggle('collapsed', isExpanded);
                        summaryContent.style.display = isExpanded ? 'none' : 'block';
                        button.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
                    });
                });
            }

            setupReferenceColumnToggles() {
                const toggleButtons = document.querySelectorAll('[data-reference-toggle]');
                toggleButtons.forEach((button) => {
                    button.addEventListener('click', () => {
                        const objectiveId = button.getAttribute('data-objective-id');
                        const level = button.getAttribute('data-level');
                        const assessmentSection = objectiveId && level ?
                            document.getElementById(`assessment-${objectiveId}-${level}`) :
                            button.closest('.capability-level-section')?.querySelector('.assessment-section');
                        const table = assessmentSection ? assessmentSection.querySelector('.assessment-table') : null;
                        if (!table) {
                            return;
                        }

                        const isHidden = table.classList.toggle('reference-hidden');
                        const icon = button.querySelector('i');
                        const label = button.querySelector('.reference-toggle-text');

                        if (icon) {
                            icon.classList.toggle('fa-eye', !isHidden);
                            icon.classList.toggle('fa-eye-slash', isHidden);
                        }

                        button.setAttribute('aria-pressed', isHidden ? 'false' : 'true');
                        button.setAttribute('title', isHidden ? 'Show reference' : 'Hide reference');

                        if (label) {
                            label.textContent = isHidden ? 'Show Reference' : 'Hide Reference';
                        }
                    });
                });
            }

            updateDomainOverviewVisibility() {
                if (!this.domainChartWrapper || !this.domainChartContainer || !this.domainOverviewToggle) {
                    return;
                }
                if (!this.domainChartHasData) {
                    this.domainChartWrapper.style.display = 'none';
                    return;
                }
                this.domainChartWrapper.style.display = 'block';
                if (this.domainChartCollapsed) {
                    this.domainChartWrapper.classList.add('collapsed');
                    this.domainChartContainer.style.display = 'none';
                    this.domainOverviewToggle.setAttribute('aria-expanded', 'false');
                } else {
                    this.domainChartWrapper.classList.remove('collapsed');
                    this.domainChartContainer.style.display = 'block';
                    this.domainOverviewToggle.setAttribute('aria-expanded', 'true');
                }
            }

            setupBackToTopButton() {
                const backToTopBtn = document.getElementById('back-to-top-btn');
                if (!backToTopBtn) {
                    return;
                }
                backToTopBtn.addEventListener('click', () => {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                });
            }

            setupEvidenceListener() {
                document.addEventListener('evidenceAdded', (e) => {
                    if (e.detail && e.detail.judul_dokumen) {
                        const evidenceText = e.detail.judul_dokumen;
                        this.addEvidenceToLibrary(evidenceText, {
                            refresh: true
                        });
                    }
                });
            }

            async saveAssessment() {
                this.showLoading('Collecting assessment data...', 0);

                try {
                    await new Promise(resolve => setTimeout(resolve, 100));
                    this.updateLoadingProgress('Preparing data...', 20);

                    const fieldPayload = this.collectFieldData();
                    this.updateLoadingProgress('Building payload...', 40);

                    const assessmentData = {
                        assessmentData: this.levelScores,
                        notes: fieldPayload.notes,
                        evidence: fieldPayload.evidence,
                        evidenceNames: fieldPayload.evidenceNames
                    };

                    this.updateLoadingProgress('Saving to server...', 60);

                    const response = await fetch(`/assessment/${this.currentEvalId}/save`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute(
                                'content')
                        },
                        body: JSON.stringify(assessmentData)
                    });

                    this.updateLoadingProgress('Processing response...', 90);
                    const result = await response.json();

                    if (response.ok) {
                        this.updateLoadingProgress('Saved successfully!', 100);
                        setTimeout(() => {
                            this.hideLoading();
                            this.showNotification('Assessment saved successfully!', 'success');
                        }, 500);
                    } else {
                        this.hideLoading();
                        this.showNotification(result.message || 'Failed to save assessment', 'error');
                    }
                } catch (error) {
                    console.error('Save error:', error);
                    this.hideLoading();
                    this.showNotification('Failed to save assessment', 'error');
                }
            }

            async loadAssessment(triggeredManually = false) {
                const showLoadingFn = triggeredManually ? this.showLoading.bind(this) : this.showCornerLoading.bind(
                    this);
                const updateProgressFn = triggeredManually ? this.updateLoadingProgress.bind(this) : this
                    .updateCornerProgress.bind(this);
                const hideLoadingFn = triggeredManually ? this.hideLoading.bind(this) : this.hideCornerLoading.bind(
                    this);

                showLoadingFn('Fetching assessment data...', 5);

                try {
                    updateProgressFn('Requesting data from server...', 15);

                    const response = await fetch(`/assessment/${this.currentEvalId}/load`, {
                        method: 'GET',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute(
                                'content')
                        }
                    });

                    const result = await response.json();

                    if (!response.ok || !result.data) {
                        hideLoadingFn();
                        if (triggeredManually) {
                            this.showNotification(result.message || 'Failed to load assessment', 'error');
                        }
                        return;
                    }

                    const data = result.data;
                    updateProgressFn('Resetting assessment fields...', 30);
                    this.resetAssessmentFields();

                    const aggregatedEvidence = {};
                    const aggregatedNotes = {};
                    const payloadKeys = new Set();
                    if (data.notes) {
                        Object.keys(data.notes).forEach(key => payloadKeys.add(key));
                    }
                    if (data.evidence) {
                        Object.keys(data.evidence).forEach(key => payloadKeys.add(key));
                    }

                    payloadKeys.forEach(activityId => {
                        const parsed = this.parseNotePayload(
                            data.notes ? data.notes[activityId] : null,
                            data.evidence ? data.evidence[activityId] : null
                        );
                        if (parsed.evidence !== undefined) {
                            aggregatedEvidence[activityId] = parsed.evidence || '';
                        }
                        if (parsed.note !== undefined) {
                            aggregatedNotes[activityId] = parsed.note || '';
                        }
                    });
                    const activityEntries = data.activityData ? Object.entries(data.activityData) : [];

                    activityEntries.forEach(([activityId, entry]) => {
                        const parsed = this.parseNotePayload(entry.notes, entry.evidence);
                        if (parsed.evidence !== undefined) {
                            aggregatedEvidence[activityId] = parsed.evidence || '';
                        }
                        if (parsed.note !== undefined) {
                            aggregatedNotes[activityId] = parsed.note || '';
                        }
                    });

                    updateProgressFn('Applying evidence and notes...', 55);
                    Object.entries(aggregatedEvidence).forEach(([activityId, evidenceValue]) => {
                        const textarea = this.elementCache.evidenceInputs.get(activityId);
                        if (textarea) {
                            textarea.value = evidenceValue || '';
                            this.updateEvidenceDisplay(activityId, evidenceValue || '');
                        }
                        const meta = this.getActivityMeta(activityId);
                        if (meta) {
                            this.setActivityEvidence(meta.objectiveId, meta.level, activityId, evidenceValue ||
                                '');
                        }
                        this.addEvidenceToLibrary(evidenceValue, {
                            refresh: false
                        });
                    });

                    Object.entries(aggregatedNotes).forEach(([activityId, noteValue]) => {
                        const textarea = this.elementCache.noteInputs.get(activityId);
                        if (textarea) {
                            textarea.value = noteValue || '';
                        }
                        const meta = this.getActivityMeta(activityId);
                        if (meta) {
                            this.setActivityNote(meta.objectiveId, meta.level, activityId, noteValue || '');
                        }
                    });

                    updateProgressFn('Building evidence dropdowns...', 70);
                    await this.refreshEvidenceDropdowns();

                    updateProgressFn('Applying ratings...', 85);
                    activityEntries.forEach(([activityId, entry]) => {
                        const objectiveId = entry.objective_id;
                        const capabilityLevel = entry.capability_lvl;
                        const levelAchieved = entry.level_achieved;
                        const ratingSelect = this.elementCache.ratingSelects.get(activityId);

                        if (ratingSelect) {
                            ratingSelect.value = levelAchieved || '';
                        }

                        if (objectiveId && capabilityLevel) {
                            this.setActivityRating(objectiveId, capabilityLevel, activityId, levelAchieved);
                            if (entry.evidence) {
                                this.setActivityEvidence(objectiveId, capabilityLevel, activityId, entry
                                    .evidence);
                            }
                            if (entry.notes) {
                                this.setActivityNote(objectiveId, capabilityLevel, activityId, entry.notes);
                            }
                        }

                        this.updateActivityScore(activityId, levelAchieved);
                    });

                    updateProgressFn('Finalizing calculations...', 95);
                    await this.updateAllCalculationsParallel();

                    updateProgressFn('Complete!', 100);
                    hideLoadingFn();

                    // If viewer is not owner, force read-only mode after data is loaded
                    if (!this.canManageAssessment) {
                        this.setActionButtonsDisabled(true);
                        this.lockInterface();
                    }

                    if (triggeredManually) {
                        this.showNotification('Assessment loaded successfully!', 'success');
                    }
                } catch (error) {
                    console.error('Load error:', error);
                    hideLoadingFn();
                    if (triggeredManually) {
                        this.showNotification('Failed to load assessment', 'error');
                    }
                }
            }

            async populateAssessmentDataParallel(data) {
                this.levelScores = {};
                this.objectiveCapabilityLevels = {};
                this.objectiveDisplayMetrics = {};
                this.initializeEvidenceLibrary();

                const allSelects = document.querySelectorAll('.activity-rating-select');
                const allTextareas = document.querySelectorAll('.assessment-textarea');
                const chunkSize = 25; // Smaller chunks = more responsive

                // Clear rating selects in small chunks to keep the UI responsive
                for (let i = 0; i < allSelects.length; i += chunkSize) {
                    const chunk = Array.from(allSelects).slice(i, i + chunkSize);
                    chunk.forEach(select => select.value = '');
                    await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
                }

                // Clear textareas in small chunks
                for (let i = 0; i < allTextareas.length; i += chunkSize) {
                    const chunk = Array.from(allTextareas).slice(i, i + chunkSize);
                    chunk.forEach(textarea => textarea.value = '');
                    await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
                }

                this.updateCornerProgress('Initializing scores...', 55);
                const objectiveCards = document.querySelectorAll('.objective-card');
                for (const card of objectiveCards) {
                    const objectiveId = card.getAttribute('data-objective-id');
                    const levelSections = card.querySelectorAll('.capability-level-section');

                    levelSections.forEach(section => {
                        const level = parseInt(section.getAttribute('data-level'));
                        this.initializeLevelScore(objectiveId, level);

                        const activityInputs = section.querySelectorAll('.activity-rating-select');
                        activityInputs.forEach(input => {
                            const activityId = input.getAttribute('data-activity-id');
                            this.levelScores[objectiveId][level].activities[activityId] = 0;
                        });
                    });
                    await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
                }

                this.updateCornerProgress('Loading notes and evidence...', 65);
                if (data.notes || data.evidence) {
                    const activityIds = new Set();
                    if (data.notes) Object.keys(data.notes).forEach(id => activityIds.add(id));
                    if (data.evidence) Object.keys(data.evidence).forEach(id => activityIds.add(id));

                    const activityIdsArray = Array.from(activityIds);
                    for (let i = 0; i < activityIdsArray.length; i += chunkSize) {
                        const chunk = activityIdsArray.slice(i, i + chunkSize);

                        chunk.forEach(activityId => {
                            const parsedNotes = this.parseNotePayload(
                                data.notes ? data.notes[activityId] : null,
                                data.evidence ? data.evidence[activityId] : null
                            );

                            // Use cached elements instead of querySelector
                            const evidenceField = this.elementCache.evidenceInputs.get(activityId);
                            const noteField = this.elementCache.noteInputs.get(activityId);
                            if (evidenceField) {
                                evidenceField.value = parsedNotes.evidence || '';
                                this.updateEvidenceDisplay(activityId, parsedNotes.evidence || '');
                            }
                            if (noteField) noteField.value = parsedNotes.note || '';
                            this.addEvidenceToLibrary(parsedNotes.evidence, {
                                refresh: false
                            });
                        });

                        await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
                    }
                }

                this.updateCornerProgress('Loading activity ratings...', 75);
                if (data.activityData) {
                    const activityIds = Object.keys(data.activityData);
                    const totalActivities = activityIds.length;

                    for (let i = 0; i < activityIds.length; i += chunkSize) {
                        const chunk = activityIds.slice(i, i + chunkSize);

                        chunk.forEach(activityId => {
                            const activityData = data.activityData[activityId];
                            const levelAchieved = activityData.level_achieved;
                            const capabilityLevel = activityData.capability_lvl;
                            const objectiveId = activityData.objective_id;

                            const ratingSelect = document.querySelector(
                                `select.activity-rating-select[data-activity-id="${activityId}"]`);
                            if (ratingSelect && objectiveId && capabilityLevel) {
                                ratingSelect.value = levelAchieved;

                                if (this.levelScores[objectiveId] && this.levelScores[objectiveId][
                                        capabilityLevel
                                    ]) {
                                    this.levelScores[objectiveId][capabilityLevel].activities[activityId] = this
                                        .getRatingValue(levelAchieved);

                                    if (activityData.notes || activityData.evidence) {
                                        const parsedNotes = this.parseNotePayload(activityData.notes,
                                            activityData.evidence);
                                        this.levelScores[objectiveId][capabilityLevel].evidence[activityId] =
                                            parsedNotes.evidence || '';
                                        this.levelScores[objectiveId][capabilityLevel].notes[activityId] =
                                            parsedNotes.note || '';
                                        this.addEvidenceToLibrary(parsedNotes.evidence, {
                                            refresh: false
                                        });
                                    }

                                    this.updateActivityScore(activityId, levelAchieved);
                                }
                            }
                        });

                        const progress = 75 + Math.round((i / totalActivities) * 15);
                        this.updateCornerProgress(
                            `Loading: ${Math.min(i + chunk.length, totalActivities)}/${totalActivities} activities`,
                            progress);

                        await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
                    }
                }

                this.updateCornerProgress('Refreshing dropdowns...', 92);
                await this.refreshEvidenceDropdownsParallel();

                this.updateCornerProgress('Calculating scores...', 96);
                await this.updateAllCalculationsParallel();
            }

            async populateAssessmentData(data) {
                this.levelScores = {};
                this.objectiveCapabilityLevels = {};
                this.objectiveDisplayMetrics = {};
                this.initializeEvidenceLibrary();

                const allSelects = document.querySelectorAll('.activity-rating-select');
                const allTextareas = document.querySelectorAll('.assessment-textarea');
                const chunkSize = 100;

                // Clear fields in chunks to avoid blocking the UI
                for (let i = 0; i < allSelects.length; i += chunkSize) {
                    const chunk = Array.from(allSelects).slice(i, i + chunkSize);
                    chunk.forEach(select => select.value = '');
                    if (i % 200 === 0) {
                        await new Promise(resolve => setTimeout(resolve, 0));
                    }
                }

                for (let i = 0; i < allTextareas.length; i += chunkSize) {
                    const chunk = Array.from(allTextareas).slice(i, i + chunkSize);
                    chunk.forEach(textarea => textarea.value = '');
                    if (i % 200 === 0) {
                        await new Promise(resolve => setTimeout(resolve, 0));
                    }
                }

                const objectiveCards = document.querySelectorAll('.objective-card');
                objectiveCards.forEach(card => {
                    const objectiveId = card.getAttribute('data-objective-id');
                    const levelSections = card.querySelectorAll('.capability-level-section');

                    levelSections.forEach(section => {
                        const level = parseInt(section.getAttribute('data-level'));
                        this.initializeLevelScore(objectiveId, level);

                        const activityInputs = section.querySelectorAll('.activity-rating-select');
                        const activityIds = new Set();
                        activityInputs.forEach(input => {
                            const activityId = input.getAttribute('data-activity-id');
                            activityIds.add(activityId);
                        });

                        activityIds.forEach(activityId => {
                            this.levelScores[objectiveId][level].activities[activityId] = 0;
                        });
                    });
                });

                if (data.notes) {
                    const activityIds = new Set();
                    Object.keys(data.notes).forEach(id => activityIds.add(id));

                    activityIds.forEach(activityId => {
                        const parsedNotes = this.parseNotePayload(
                            data.notes ? data.notes[activityId] : null,
                            null // No evidence field anymore
                        );

                        const noteField = document.querySelector(
                            `textarea.note-input[data-activity-id="${activityId}"]`);
                        if (noteField) {
                            noteField.value = parsedNotes.note || '';
                        }
                    });
                }

                if (data.activityData) {
                    const activityIds = Object.keys(data.activityData);
                    const totalActivities = activityIds.length;
                    const chunkSize = 50;

                    for (let i = 0; i < activityIds.length; i += chunkSize) {
                        const chunk = activityIds.slice(i, i + chunkSize);

                        chunk.forEach(activityId => {
                            const activityData = data.activityData[activityId];
                            const levelAchieved = activityData.level_achieved;
                            const capabilityLevel = activityData.capability_lvl;
                            const objectiveId = activityData.objective_id;

                            const ratingSelect = document.querySelector(
                                `select.activity-rating-select[data-activity-id="${activityId}"]`);
                            if (ratingSelect && objectiveId && capabilityLevel) {
                                ratingSelect.value = levelAchieved;

                                if (this.levelScores[objectiveId] && this.levelScores[objectiveId][
                                        capabilityLevel
                                    ]) {
                                    this.levelScores[objectiveId][capabilityLevel].activities[activityId] = this
                                        .getRatingValue(levelAchieved);

                                    if (activityData.notes) {
                                        const parsedNotes = this.parseNotePayload(activityData.notes,
                                            null); // No evidence field anymore
                                        this.levelScores[objectiveId][capabilityLevel].notes[activityId] =
                                            parsedNotes.note || '';
                                    }

                                    this.updateActivityScore(activityId, levelAchieved);
                                }
                            }
                        });

                        const progress = 70 + Math.round((i / totalActivities) * 20);
                        this.updateLoadingProgress(`Loading activities: ${i + chunk.length}/${totalActivities}`,
                            progress);

                        await new Promise(resolve => setTimeout(resolve, 0));
                    }
                }

                this.updateLoadingProgress('Refreshing dropdowns...', 92);
                await this.refreshEvidenceDropdowns();

                this.updateLoadingProgress('Calculating scores...', 96);
                await this.updateAllCalculations();
            }

            async updateAllCalculationsParallel() {
                const objectiveCards = document.querySelectorAll('.objective-card');
                const cardsArray = Array.from(objectiveCards);

                for (let i = 0; i < cardsArray.length; i++) {
                    const card = cardsArray[i];
                    const objectiveId = card.getAttribute('data-objective-id');
                    const levelSections = card.querySelectorAll('.capability-level-section');

                    levelSections.forEach(section => {
                        const level = parseInt(section.getAttribute('data-level'));
                        this.updateLevelCapability(objectiveId, level);
                        this.checkLevelLock(objectiveId, level);
                    });

                    this.updateObjectiveCapabilityLevel(objectiveId);

                    // Yield every 3 objectives for smoother interaction
                    if (i % 3 === 0) {
                        await new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 0)));
                    }
                }

                this.updateDomainChart(this.activeDomainFilter);
            }

            async updateAllCalculations() {
                const objectiveCards = document.querySelectorAll('.objective-card');
                const cardsArray = Array.from(objectiveCards);

                for (let i = 0; i < cardsArray.length; i++) {
                    const card = cardsArray[i];
                    const objectiveId = card.getAttribute('data-objective-id');
                    const levelSections = card.querySelectorAll('.capability-level-section');

                    levelSections.forEach(section => {
                        const level = parseInt(section.getAttribute('data-level'));
                        this.updateLevelCapability(objectiveId, level);
                        this.checkLevelLock(objectiveId, level);
                    });

                    // Update overall objective capability level
                    this.updateObjectiveCapabilityLevel(objectiveId);

                    // Yield setiap 5 objectives
                    if (i % 5 === 0) {
                        await new Promise(resolve => setTimeout(resolve, 0));
                    }
                }

                this.updateDomainChart(this.activeDomainFilter);
            }

            collectFieldData() {
                const notes = {};
                const evidence = {};
                const evidenceNames = {};

                document.querySelectorAll('.assessment-textarea[data-activity-id]').forEach(field => {
                    const activityId = field.getAttribute('data-activity-id');
                    const fieldType = field.getAttribute('data-field-type');
                    const value = field.value.trim();

                    if (!value) {
                        return;
                    }

                    if (fieldType === 'note') {
                        notes[activityId] = value;
                    } else {
                        evidence[activityId] = value;
                        // Build evidenceNames array: Split by newline and trim each line
                        evidenceNames[activityId] = value.split('\n')
                            .map(line => line.trim())
                            .filter(item => item.length > 0);
                    }
                });

                return {
                    notes,
                    evidence,
                    evidenceNames
                };
            }

            escapeHtml(value) {
                if (value === null || value === undefined) {
                    return '';
                }
                return String(value)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
            }

            showNotification(message, type = 'info') {
                const notification = document.createElement('div');
                notification.className =
                    `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
                notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
                notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

                document.body.appendChild(notification);

                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 5000);
            }

            setupDomainFiltering() {
                const filterButtons = document.querySelectorAll('.domain-tab');
                this.objectiveCards = this.objectiveCards.length ? this.objectiveCards : Array.from(document
                    .querySelectorAll('.objective-card'));
                filterButtons.forEach(button => {
                    button.addEventListener('click', () => {
                        filterButtons.forEach(btn => btn.classList.remove('active'));
                        button.classList.add('active');

                        const selectedDomain = button.getAttribute('data-domain');
                        this.activeDomainFilter = selectedDomain;
                        this.activeObjectiveFilter = 'all';
                        this.renderObjectiveFilterTabs(selectedDomain);
                        this.updateObjectiveVisibility();
                        this.updateDomainChart(selectedDomain);
                    });
                });

                this.renderObjectiveFilterTabs(this.activeDomainFilter);
                this.updateObjectiveVisibility();
            }

            setupAssessmentToggles() {
                const toggleButtons = document.querySelectorAll('.toggle-level-details');

                toggleButtons.forEach(button => {
                    button.addEventListener('click', () => {
                        const objectiveId = button.getAttribute('data-objective-id');
                        const level = button.getAttribute('data-level');
                        const assessmentSection = document.getElementById(
                            `assessment-${objectiveId}-${level}`);
                        const icon = button.querySelector('.toggle-icon');
                        const text = button.querySelector('.toggle-text');

                        if (text.textContent === 'Locked') {
                            return;
                        }

                        if (assessmentSection.style.display === 'none' || !assessmentSection.style
                            .display) {
                            assessmentSection.style.display = 'block';
                            assessmentSection.style.animation = 'slideDown 0.3s ease-out';
                            icon.classList.remove('fa-chevron-down');
                            icon.classList.add('fa-chevron-up');
                            text.textContent = 'Hide Assessment';
                        } else {
                            assessmentSection.style.display = 'none';
                            icon.classList.remove('fa-chevron-up');
                            icon.classList.add('fa-chevron-down');
                            text.textContent = 'Show Assesment';
                        }
                    });
                });
            }

            setupActivityRating() {
                const ratingInputs = document.querySelectorAll('.activity-rating-select');
                const noteTextareas = document.querySelectorAll('.note-input');

                ratingInputs.forEach(select => {
                    select.addEventListener('change', () => {
                        const activityId = select.getAttribute('data-activity-id');
                        const objectiveId = select.getAttribute('data-objective-id');
                        const level = parseInt(select.getAttribute('data-level'));
                        const rating = select.value;

                        if (rating) {
                            this.setActivityRating(objectiveId, level, activityId, rating);
                            this.updateActivityScore(activityId, rating);
                        } else {
                            this.clearActivityRating(objectiveId, level, activityId);
                            this.updateActivityScore(activityId, null);
                        }
                        this.updateLevelCapability(objectiveId, level);
                        this.checkAllLevelLocks(objectiveId);
                    });
                });

                noteTextareas.forEach(textarea => {
                    textarea.addEventListener('input', () => {
                        const activityId = textarea.getAttribute('data-activity-id');
                        const objectiveId = textarea.getAttribute('data-objective-id');
                        const level = parseInt(textarea.getAttribute('data-level'));
                        const note = textarea.value;

                        this.setActivityNote(objectiveId, level, activityId, note);
                    });
                });

                // Evidence Inputs (Hidden but updated by modal)
                const evidenceTextareas = document.querySelectorAll('.evidence-input');
                evidenceTextareas.forEach(textarea => {
                    textarea.addEventListener('input', () => {
                        const activityId = textarea.getAttribute('data-activity-id');
                        const objectiveId = textarea.getAttribute('data-objective-id');
                        const level = parseInt(textarea.getAttribute('data-level'));
                        const evidence = textarea.value;

                        this.setActivityEvidence(objectiveId, level, activityId, evidence);
                    });
                });

                // Evidence Dropdowns (History) - Click triggers modal
                const evidenceSelects = document.querySelectorAll('.evidence-history-select');
                evidenceSelects.forEach(select => {
                    select.addEventListener('click', (e) => {
                        e.preventDefault();
                        const activityId = select.getAttribute('data-activity-id');
                        this.openEvidenceModal(activityId);
                    });
                    // Prevent actual selection change, act as button
                    select.addEventListener('change', (e) => {
                        e.preventDefault();
                        select.value = '';
                    });
                });

                const modalTriggers = document.querySelectorAll('.evidence-modal-trigger');
                modalTriggers.forEach(btn => {
                    btn.addEventListener('click', () => {
                        const activityId = btn.getAttribute('data-activity-id');
                        this.openEvidenceModal(activityId);
                    });
                });
            }

            renderEvidenceDisplay(displayElement, values) {
                if (!displayElement) return;

                displayElement.innerHTML = '';
                const cleanValues = (values || []).map(v => v.trim()).filter(Boolean);

                if (!cleanValues.length) {
                    displayElement.innerHTML = '<span class="text-muted small">No evidence added</span>';
                    return;
                }

                const list = document.createElement('ul');
                list.className = 'mb-0 ps-3 evidence-list';

                cleanValues.forEach(val => {
                    const li = document.createElement('li');
                    li.textContent = val;
                    list.appendChild(li);
                });

                displayElement.appendChild(list);
            }



            updateEvidenceDisplay(activityId, value) {
                const values = typeof value === 'string' ? value.split('\n') : [];
                const display = document.querySelector(`.evidence-display[data-activity-id="${activityId}"]`);
                this.renderEvidenceDisplay(display, values);
            }

            setActivityRating(objectiveId, level, activityId, rating) {
                this.initializeLevelScore(objectiveId, level);
                if (!rating) {
                    delete this.levelScores[objectiveId][level].activities[activityId];
                    return;
                }
                this.levelScores[objectiveId][level].activities[activityId] = this.getRatingValue(rating);
            }

            setActivityEvidence(objectiveId, level, activityId, evidence) {
                this.initializeLevelScore(objectiveId, level);
                this.levelScores[objectiveId][level].evidence[activityId] = evidence;
                this.updateEvidenceDisplay(activityId, evidence);
            }

            setActivityNote(objectiveId, level, activityId, note) {
                this.initializeLevelScore(objectiveId, level);
                this.levelScores[objectiveId][level].notes[activityId] = note;
            }

            clearActivityRating(objectiveId, level, activityId) {
                if (this.levelScores[objectiveId] && this.levelScores[objectiveId][level]) {
                    // Only clear the rating, preserve evidence and notes
                    delete this.levelScores[objectiveId][level].activities[activityId];

                    // DO NOT delete evidence and notes - they should be preserved
                    // delete this.levelScores[objectiveId][level].evidence[activityId];
                    // delete this.levelScores[objectiveId][level].notes[activityId];

                    // DO NOT clear textarea values - evidence and notes should remain visible
                    // const evidenceTextarea = document.getElementById(`evidence_${activityId}`);
                    // if (evidenceTextarea) {
                    //     evidenceTextarea.value = '';
                    // }
                    // this.updateEvidenceDisplay(activityId, '');
                    // const noteTextarea = document.getElementById(`note_${activityId}`);
                    // if (noteTextarea) {
                    //     noteTextarea.value = '';
                    // }
                }
            }

            updateActivityScore(activityId, rating) {
                // Use cached element
                const ratingSelect = this.elementCache.ratingSelects.get(activityId);
                if (ratingSelect) {
                    ratingSelect.classList.remove('rating-full', 'rating-high', 'rating-medium', 'rating-low');
                    if (rating === 'F') {
                        ratingSelect.classList.add('rating-full');
                    } else if (rating === 'L') {
                        ratingSelect.classList.add('rating-high');
                    } else if (rating === 'P') {
                        ratingSelect.classList.add('rating-medium');
                    } else if (rating === 'N') {
                        ratingSelect.classList.add('rating-low');
                    }
                }
            }

            updateLevelCapability(objectiveId, level) {
                const levelData = this.levelScores[objectiveId][level];
                const totalActivities = this.getTotalActivitiesForLevel(objectiveId, level);
                const ratedActivities = Object.keys(levelData.activities).length;

                let totalScore = 0;
                if (levelData.activities) {
                    totalScore = Object.values(levelData.activities).reduce((sum, score) => sum + score, 0);
                }
                const averageScore = totalActivities > 0 ? totalScore / totalActivities : 0;

                levelData.score = averageScore;
                levelData.letter = this.getScoreLetter(averageScore);

                this.updateLevelDisplay(objectiveId, level);
                this.updateLevelStats(objectiveId, level, averageScore, ratedActivities, totalActivities);
            }

            updateLevelDisplay(objectiveId, level) {
                const levelData = this.levelScores[objectiveId][level];
                const scoreElement = document.getElementById(`level-score-${objectiveId}-${level}`);

                if (scoreElement) {
                    scoreElement.textContent = `${levelData.letter} (${levelData.score.toFixed(2)})`;
                    scoreElement.className =
                        `capability-score level-score-chip ${this.getScoreColorClass(levelData.score)}`;
                }
            }

            updateLevelStats(objectiveId, level, averageScore, ratedActivities, totalActivities) {
                // Update average score display
                const averageScoreElement = document.getElementById(`average-score-${objectiveId}-${level}`);
                if (averageScoreElement) {
                    averageScoreElement.textContent = averageScore.toFixed(2);
                    averageScoreElement.className = `badge ${this.getScoreColorClass(averageScore)}`;
                }

                // Update activities count display
                const activitiesCountElement = document.getElementById(`activities-count-${objectiveId}-${level}`);
                if (activitiesCountElement) {
                    activitiesCountElement.textContent = `${ratedActivities}/${totalActivities}`;
                    const completionRatio = totalActivities > 0 ? ratedActivities / totalActivities : 0;
                    activitiesCountElement.className = `badge ${this.getCompletionColorClass(completionRatio)}`;
                }

                // Update the overall objective capability level
                this.updateObjectiveCapabilityLevel(objectiveId);
            }

            getObjectiveDisplayMetrics(objectiveId) {
                const minLevel = this.getMinLevelForObjective(objectiveId);
                let progressLevel = 0;
                let progressScore = 0;

                for (let level = 5; level >= minLevel; level -= 1) {
                    const score = this.levelScores[objectiveId]?.[level]?.score || 0;
                    if (this.getScoreLetter(score) !== 'N') {
                        progressLevel = level;
                        progressScore = score;
                        break;
                    }
                }

                const getCapabilityScore = (level) => {
                    if (level < minLevel) {
                        return 1;
                    }

                    return this.levelScores[objectiveId]?.[level]?.score || 0;
                };

                const score2 = getCapabilityScore(2);
                const score3 = getCapabilityScore(3);
                const score4 = getCapabilityScore(4);
                const score5 = getCapabilityScore(5);

                let finalLevel = 0;
                if (score2 <= this.config.scoreThresholds.partial) {
                    finalLevel = 0;
                } else if (score2 <= this.config.scoreThresholds.largely) {
                    finalLevel = 1;
                } else if (score2 <= this.config.scoreThresholds.fully) {
                    finalLevel = 2;
                } else {
                    if (score3 <= this.config.scoreThresholds.largely) {
                        finalLevel = 2;
                    } else if (score3 <= this.config.scoreThresholds.fully) {
                        finalLevel = 3;
                    } else {
                        if (score4 <= this.config.scoreThresholds.largely) {
                            finalLevel = 3;
                        } else if (score4 <= this.config.scoreThresholds.fully) {
                            finalLevel = 4;
                        } else {
                            finalLevel = score5 <= this.config.scoreThresholds.largely ? 4 : 5;
                        }
                    }
                }

                if (minLevel > 2 && (this.levelScores[objectiveId]?.[minLevel]?.score || 0) <= this.config
                    .scoreThresholds.partial) {
                    finalLevel = 0;
                }

                let ratingSourceLevel = finalLevel > 0 ? Math.max(2, finalLevel) : null;
                if (ratingSourceLevel !== null && !this.levelScores[objectiveId]?.[ratingSourceLevel]) {
                    ratingSourceLevel = minLevel;
                }

                const finalScore = ratingSourceLevel !== null ?
                    (this.levelScores[objectiveId]?.[ratingSourceLevel]?.score || 0) :
                    0;
                const ratingLetter = progressLevel > 0 ? this.getScoreLetter(progressScore) : 'N';
                const value = progressLevel > 0 ? Number((((progressLevel - 1) + progressScore)).toFixed(2)) : 0;

                return {
                    level: finalLevel,
                    score: finalScore,
                    progressLevel,
                    progressScore,
                    ratingLetter,
                    ratingString: progressLevel > 0 ? `${progressLevel}${ratingLetter}` : '0N',
                    value,
                    valueLabel: value.toFixed(2),
                };
            }

            updateObjectiveCapabilityLevel(objectiveId) {
                const metrics = this.getObjectiveDisplayMetrics(objectiveId);
                const finalLevel = metrics.level;

                // Update the objective capability level badge
                const capabilityBadge = document.getElementById(`capability-level-${objectiveId}`);
                if (capabilityBadge) {
                    this.updateCapabilityBadge(capabilityBadge, finalLevel);
                }

                this.updatePracticeSummaryMetrics(objectiveId, metrics);
                this.objectiveDisplayMetrics[objectiveId] = metrics;
                this.objectiveCapabilityLevels[objectiveId] = finalLevel;
            }

            formatPracticeSummaryNumber(value) {
                const numericValue = Number(value);
                if (!Number.isFinite(numericValue)) {
                    return '';
                }

                return numericValue.toLocaleString('id-ID', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            }

            updatePracticeSummaryMetrics(objectiveId, metrics = null) {
                const resolvedMetrics = metrics || this.objectiveDisplayMetrics[objectiveId] || this
                    .getObjectiveDisplayMetrics(objectiveId);
                [2, 3, 4, 5].forEach((level) => {
                    const indexElement = document.getElementById(`practice-summary-index-${objectiveId}-${level}`);
                    const levelRatingElement = document.getElementById(
                        `practice-summary-level-rating-${objectiveId}-${level}`);
                    const totalActivities = this.getTotalActivitiesForLevel(objectiveId, level);
                    const levelData = this.levelScores[objectiveId]?.[level];

                    if (indexElement) {
                        indexElement.textContent = totalActivities > 0 && levelData ? this
                            .formatPracticeSummaryNumber(levelData.score || 0) : '';
                    }

                    if (levelRatingElement) {
                        levelRatingElement.textContent = totalActivities > 0 && levelData ? (levelData.letter ||
                            'N') : '';
                    }
                });

                const valueElement = document.getElementById(`practice-summary-value-${objectiveId}`);
                const ratingElement = document.getElementById(`practice-summary-rating-${objectiveId}`);
                const levelElement = document.getElementById(`practice-summary-level-${objectiveId}`);

                if (valueElement) {
                    valueElement.textContent = this.formatPracticeSummaryNumber(resolvedMetrics.value || 0);
                }

                if (ratingElement) {
                    ratingElement.textContent = resolvedMetrics.ratingString || '0N';
                }

                if (levelElement) {
                    levelElement.textContent = Number.isFinite(resolvedMetrics.level) ? resolvedMetrics.level : 0;
                }
            }

            getMinLevelForObjective(objectiveId) {
                const firstButton = document.querySelector(`[data-objective-id="${objectiveId}"].toggle-level-details`);
                if (firstButton) {
                    return parseInt(firstButton.getAttribute('data-min-level')) || 2;
                }
                return 2;
            }

            checkLevelLock(objectiveId, level) {
                const minLevel = this.getMinLevelForObjective(objectiveId);

                if (level === minLevel) {
                    return;
                }

                const previousLevel = level - 1;
                const prevLevelData = this.levelScores[objectiveId] && this.levelScores[objectiveId][previousLevel];
                const isLocked = !prevLevelData || prevLevelData.letter !== 'F';

                const button = document.querySelector(
                    `.toggle-level-details[data-objective-id="${objectiveId}"][data-level="${level}"]`
                );
                const scoreElement = document.getElementById(`level-score-${objectiveId}-${level}`);
                const toggleText = button ? button.querySelector('.toggle-text') : null;

                if (button && scoreElement) {
                    if (isLocked) {
                        if (toggleText) {
                            toggleText.textContent = 'Locked';
                        }
                        button.disabled = true;
                        button.classList.add('level-toggle-btn-disabled');
                        scoreElement.textContent = 'N (0.00)';
                        scoreElement.className = 'capability-score level-score-chip score-chip-muted';

                        // Preserve existing evidence and notes when locking
                        // Lock the level data but preserve evidence and notes by mutating in place
                        const levelData = this.levelScores[objectiveId][level];
                        if (levelData) {
                            levelData.letter = 'N';
                            levelData.score = 0.00;
                            levelData.activities = {};
                            // evidence and notes are untouched and preserved
                        } else {
                            // Should not start as locked if it doesn't exist, but if initialized:
                            this.levelScores[objectiveId][level] = {
                                letter: 'N',
                                score: 0.00,
                                activities: {},
                                evidence: {},
                                notes: {}
                            };
                        }
                    } else {
                        if (toggleText) {
                            toggleText.textContent = 'Show Assesment';
                        }
                        button.disabled = false;
                        button.classList.remove('level-toggle-btn-disabled');
                    }
                }
            }

            checkAllLevelLocks(objectiveId) {
                const objectiveCard = document.querySelector(`[data-objective-id="${objectiveId}"].objective-card`);
                if (objectiveCard) {
                    const levelSections = objectiveCard.querySelectorAll('.capability-level-section');
                    levelSections.forEach(section => {
                        const level = parseInt(section.getAttribute('data-level'));
                        this.checkLevelLock(objectiveId, level);
                    });
                }
            }

            getScoreLetter(score) {
                if (score > this.config.scoreThresholds.fully) return 'F';
                if (score > this.config.scoreThresholds.largely) return 'L';
                if (score > this.config.scoreThresholds.partial) return 'P';
                return 'N';
            }

            calculateCapabilityFromScore(score) {
                if (score <= 0.15) return 1;
                if (score <= 0.5) return 1;
                if (score <= 0.85) return 2;
                return 2;
            }

            updateCapabilityBadge(badge, level) {
                const badgeClasses = ['badge-level-1', 'badge-level-2', 'badge-level-3', 'badge-level-4',
                    'badge-level-5'
                ];
                badgeClasses.forEach(c => badge.classList.remove(c));
                const levelKey = Math.min(Math.max(level, 0), 5);
                badge.classList.add(`badge-level-${levelKey}`);

                const levelNumber = badge.querySelector('.level-number');
                if (levelNumber) {
                    levelNumber.textContent = level;
                }
            }

            getTotalActivitiesForLevel(objectiveId, level) {
                const assessmentSection = document.getElementById(`assessment-${objectiveId}-${level}`);
                if (assessmentSection) {
                    return assessmentSection.querySelectorAll('.activity-rating-select').length;
                }
                return 0;
            }

            getActivityMeta(activityId) {
                const ratingSelect = this.elementCache.ratingSelects.get(activityId);
                if (!ratingSelect) {
                    return null;
                }
                const objectiveId = ratingSelect.getAttribute('data-objective-id');
                const levelValue = parseInt(ratingSelect.getAttribute('data-level'), 10);
                if (!objectiveId || Number.isNaN(levelValue)) {
                    return null;
                }
                return {
                    objectiveId,
                    level: levelValue
                };
            }

            getScoreColorClass(score) {
                if (score === 0) return 'score-chip-danger';
                if (score < 0.5) return 'score-chip-warning';
                if (score < 0.8) return 'score-chip-info';
                return 'score-chip-success';
            }

            getCompletionColorClass(ratio) {
                if (ratio === 0) return 'bg-secondary text-white';
                if (ratio < 0.5) return 'bg-warning text-dark';
                if (ratio < 1) return 'bg-info text-white';
                return 'bg-success text-white';
            }

            getRatingValue(rating) {
                return this.config.ratingMap[rating] || 0;
            }

            addEvidenceToLibrary(value, {
                refresh = true
            } = {}) {
                // Only use server-provided evidence in the dropdown.
                // Do not add dynamic values from textareas.
                return;
            }

            async refreshEvidenceDropdownsParallel() {
                return this.refreshEvidenceDropdowns();
            }

            async refreshEvidenceDropdowns() {
                // Optimization: These select elements are configured to open the Evidence Modal on click
                // (see setupActivityRating). They are not used as standard dropdowns.
                // Populating them with thousands of evidence options creates millions of DOM nodes
                // and freezes the browser during initialization.
                // We skip this heavy operation to ensure smooth page load.
                return;
            }

            updateDomainChart(selectedDomain = 'all') {
                // Special handling for 'scope' tab: show recap only for selected domains
                if (selectedDomain === 'scope') {
                    const selected = (window.SELECTED_DOMAINS || []).map(s => (s || '').toString().replace(/\d+/g, ''))
                        .filter(Boolean)
                        .map(s => s.toUpperCase());
                    const recapData = this.buildGamoRecapData().filter(item => selected.includes(item.domain));
                    if (!recapData.length) {
                        this.toggleRecapStandalone(false);
                        this.toggleDiagramStandalone(false);
                        this.domainChartHasData = false;
                        this.updateDomainOverviewVisibility();
                        return;
                    }

                    this.toggleDiagramStandalone(false);
                    this.toggleRecapStandalone(true, recapData);
                    this.domainChartHasData = false;
                    this.updateDomainOverviewVisibility();
                    return;
                }
                if (!this.domainChartContainer || !this.domainChartRows) {
                    return;
                }

                if (!selectedDomain || selectedDomain === 'all') {
                    this.toggleRecapStandalone(false);
                    this.toggleDiagramStandalone(false);
                    this.domainChartHasData = false;
                    this.updateDomainOverviewVisibility();
                    return;
                }

                if (selectedDomain === 'diagram') {
                    const recapData = this.buildGamoRecapData();
                    if (!recapData.length) {
                        this.toggleDiagramStandalone(false);
                        this.domainChartHasData = false;
                        this.updateDomainOverviewVisibility();
                        return;
                    }

                    this.toggleRecapStandalone(false);
                    this.toggleDiagramStandalone(true, recapData);
                    this.domainChartHasData = false;
                    this.updateDomainOverviewVisibility();
                    return;
                }

                if (selectedDomain === 'recap') {
                    const recapData = this.buildGamoRecapData();
                    if (!recapData.length) {
                        this.toggleRecapStandalone(false);
                        this.toggleDiagramStandalone(false);
                        this.domainChartHasData = false;
                        this.updateDomainOverviewVisibility();
                        return;
                    }

                    this.toggleDiagramStandalone(false);
                    this.toggleRecapStandalone(true, recapData);
                    this.domainChartHasData = false;
                    this.updateDomainOverviewVisibility();
                    return;
                }

                this.toggleRecapStandalone(false);
                this.toggleDiagramStandalone(false);

                const objectiveCards = document.querySelectorAll(`.objective-card[data-domain="${selectedDomain}"]`);
                const chartData = Array.from(objectiveCards).map(card => {
                    const objectiveId = card.getAttribute('data-objective-id');
                    const objectiveName = card.getAttribute('data-objective-name') || objectiveId;
                    const metrics = this.objectiveDisplayMetrics[objectiveId] || this.getObjectiveDisplayMetrics(
                        objectiveId);
                    const currentLevel = Math.min(Math.max(metrics.level || 0, 0), 5);

                    // Get ratings for each level
                    const ratings = {};
                    for (let i = 1; i <= 5; i++) {
                        if (this.levelScores[objectiveId] && this.levelScores[objectiveId][i]) {
                            ratings[i] = this.levelScores[objectiveId][i].letter; // N, P, L, F
                        } else {
                            ratings[i] = 'N'; // Default if not initialized
                        }
                    }

                    return {
                        objectiveId,
                        objectiveName,
                        level: currentLevel,
                        valueLabel: metrics.valueLabel,
                        ratingString: metrics.ratingString,
                        ratings: ratings,
                        maxCapability: this.getMaxCapabilityForObjective(objectiveId)
                    };
                }).sort((a, b) => a.objectiveId.localeCompare(b.objectiveId, undefined, {
                    numeric: true
                }));

                if (!chartData.length) {
                    this.domainChartHasData = false;
                    this.updateDomainOverviewVisibility();
                    return;
                }

                this.domainChartHasData = true;

                if (this.domainChartTitle) {
                    this.domainChartTitle.textContent = `${this.getDomainFullName(selectedDomain)}`;
                }
                if (this.domainChartPill) {
                    this.domainChartPill.textContent = selectedDomain;
                }

                this.domainChartRows.innerHTML = '';
                chartData.forEach(row => {
                    this.domainChartRows.appendChild(this.createDomainChartRow(row));
                });

                this.updateDomainOverviewVisibility();
            }

            buildGamoRecapData() {
                this.objectiveCards = this.objectiveCards.length ? this.objectiveCards : Array.from(document
                    .querySelectorAll('.objective-card'));
                if (!this.objectiveCards.length) {
                    return [];
                }

                const domainOrder = this.config.domainOrder;
                const domainRank = (domain) => {
                    const idx = domainOrder.indexOf(domain);
                    return idx === -1 ? domainOrder.length : idx;
                };

                const data = this.objectiveCards
                    .map(card => {
                        const domain = card.getAttribute('data-domain');
                        const objectiveId = card.getAttribute('data-objective-id');
                        const objectiveName = card.getAttribute('data-objective-name') || objectiveId;
                        if (!domain || !objectiveId) {
                            return null;
                        }
                        const metrics = this.objectiveDisplayMetrics[objectiveId] || this
                            .getObjectiveDisplayMetrics(objectiveId);
                        const level = Math.min(Math.max(metrics.level || 0, 0), 5);

                        return {
                            domain,
                            objectiveId,
                            objectiveName,
                            level,
                            ratingLetter: metrics.ratingLetter,
                            ratingString: metrics.ratingString,
                            valueLabel: metrics.valueLabel
                        };
                    })
                    .filter(Boolean)
                    .sort((a, b) => {
                        const domainComparison = domainRank(a.domain) - domainRank(b.domain);
                        if (domainComparison !== 0) {
                            return domainComparison;
                        }
                        return a.objectiveId.localeCompare(b.objectiveId, undefined, {
                            numeric: true
                        });
                    });

                return data;
            }
            createRecapTable(data) {
                const wrapper = document.createElement('div');
                wrapper.className = 'recap-table-wrapper';

                const table = document.createElement('table');
                table.className = 'table table-sm table-bordered recap-table align-middle mb-0';
                // Assessment Recapitulation Result Head
                const thead = document.createElement('thead');
                thead.innerHTML = `
            <tr>
                <th style="width:60px;">No</th>
                <th style="width:110px;">Domain</th>
                <th style="width:100px;">Gamo</th>
                <th>Gamo Name</th>
                <th style="width:100px;" class="text-center">Score</th>
                <th style="width:110px;" class="text-center">Value</th>
                <th style="width:100px;" class="text-center">Rating</th>
                <th style="width:100px;" class="text-center">Target</th>
                <th style="width:100px;" class="text-center">Gap</th>
                <th style="width:100px;" class="text-center">Max Level</th>
                <th style="width:100px;" class="text-center">Action</th>
            </tr>
        `;

                // Level Colors Mapping (Same as Domain Chart)
                const levelColors = this.config.levelColors;

                const levelTextColors = this.config.levelTextColors;

                const tbody = document.createElement('tbody');
                let totalLevel = 0;

                data.forEach((row, index) => {
                    const domainCode = (row.domain || '').toLowerCase();
                    const safeDomain = this.escapeHtml(row.domain);
                    const safeObjectiveId = this.escapeHtml(row.objectiveId);
                    const safeObjectiveName = this.escapeHtml(row.objectiveName);

                    const level = row.level;
                    totalLevel += level;

                    const bgColor = levelColors[level] || '#f8f9fa';
                    const textColor = levelTextColors[level] || '#6c757d';

                    const ratingDisplay = row.ratingString || '0N';
                    const valueDisplay = row.valueLabel || '0.00';
                    const maxCap = this.getMaxCapabilityForObjective(row.objectiveId);
                    const targetVal = this.getTargetCapabilityForObjective(row.objectiveId);
                    const gap = (targetVal === null || targetVal === undefined) ? null : (level - targetVal);
                    const gapIsNegative = gap !== null && gap < 0;
                    const gapIsPositive = gap !== null && gap > 0;
                    const gapDisplay = gap === null ? '-' : gap;
                    const targetDisplay = targetVal === null ? '-' : targetVal;

                    const gapClasses = ['gap-box'];
                    if (gapIsNegative) {
                        gapClasses.push('text-danger', 'fw-bold');
                    } else if (gapIsPositive) {
                        gapClasses.push('text-success', 'fw-bold');
                    } else {
                        gapClasses.push(gap === null ? 'text-muted' : 'text-dark', 'fw-bold');
                    }

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                <td class="text-center fw-semibold">${index + 1}</td>
                <td class="fw-bold text-secondary">
                    ${safeDomain}
                </td>
                <td>
                    <span class="fw-bold text-primary">${safeObjectiveId}</span>
                </td>
                <td>
                    <span class="small text-muted">${safeObjectiveName}</span>
                </td>
                <td class="text-center fw-bold" style="background-color: ${bgColor}; color: ${textColor};">
                    ${level}
                </td>
                <td class="text-center fw-semibold text-dark">
                    ${valueDisplay}
                </td>
                <td class="text-center fw-bold text-dark">
                    ${ratingDisplay}
                </td>
                <td class="text-center text-muted">
                    ${targetDisplay}
                </td>
                <td class="text-center">
                    <div class="${gapClasses.join(' ')}">${gapDisplay}</div>
                </td>
                <td class="text-center fw-bold text-secondary">
                    ${maxCap}
                </td>
                <td class="text-center">
                    <a href="/assessment/${this.currentEvalId}/report-activity/${row.objectiveId}" 
                       class="btn btn-xs btn-outline-primary rounded-pill py-1 px-3" 
                       style="font-size: 0.7rem; font-weight: 600;"
                       title="View Activity Report">
                        Detail
                    </a>
                </td>
            `;
                    tbody.appendChild(tr);
                });

                const maturity = data.length > 0 ? (totalLevel / data.length).toFixed(2) : '0.00';

                // Calculate average Target Capability
                let totalTarget = 0;
                let targetCount = 0;
                data.forEach(row => {
                    const targetVal = this.getTargetCapabilityForObjective(row.objectiveId);
                    if (targetVal !== null && targetVal !== undefined) {
                        totalTarget += targetVal;
                        targetCount++;
                    }
                });
                const avgTarget = targetCount > 0 ? (totalTarget / targetCount).toFixed(2) : '-';

                // Calculate average Max Level
                let totalMaxLevel = 0;
                data.forEach(row => {
                    const maxCap = this.getMaxCapabilityForObjective(row.objectiveId);
                    totalMaxLevel += maxCap;
                });
                const avgMaxLevel = data.length > 0 ? (totalMaxLevel / data.length).toFixed(2) : '0.00';

                const tfoot = document.createElement('tfoot');
                tfoot.innerHTML = `
            <tr class="table-light fw-bold border-top-2">
                <td colspan="4" class="text-end pe-3">I&T Maturity Score</td>
                <td class="text-center bg-primary text-white">${maturity}</td>
                <td class="bg-light"></td>
                <td class="bg-light"></td>
                <td class="text-center bg-info text-white">${avgTarget}</td>
                <td class="bg-light"></td>
                <td class="text-center bg-secondary text-white">${avgMaxLevel}</td>
                <td class="bg-light"></td>
            </tr>
        `;

                table.appendChild(thead);
                table.appendChild(tbody);
                table.appendChild(tfoot);
                wrapper.appendChild(table);
                return wrapper;
            }

            getMaxCapabilityForObjective(objectiveId) {
                const allObjectives = this.config.allObjectives;
                const maxCaps = this.getMaximumCapabilityData();
                const index = allObjectives.indexOf(objectiveId);
                if (index !== -1 && index < maxCaps.length) {
                    return maxCaps[index];
                }
                return 5; // Default fallback
            }

            getMaximumCapabilityData() {
                return this.config.maxCaps;
            }

            getTargetCapabilityForObjective(objectiveId) {
                if (!objectiveId || !this.targetCapabilityMap) return null;
                const val = this.targetCapabilityMap[objectiveId];
                if (val === null || val === undefined || val === '') return null;
                const num = Number(val);
                return isNaN(num) ? null : num;
            }

            toggleRecapStandalone(show, data = []) {
                if (!this.recapStandaloneRow || !this.recapStandaloneWrapper || !this.recapStandaloneBody) {
                    return;
                }

                if (!show || !data.length) {
                    this.recapStandaloneRow.style.display = 'none';
                    this.recapStandaloneWrapper.style.display = 'none';
                    this.recapStandaloneBody.innerHTML = '';
                    return;
                }

                this.recapStandaloneBody.innerHTML = '';

                const tableContainer = document.createElement('div');
                tableContainer.className = 'bg-white p-4 rounded-lg border border-gray-200 shadow-sm';
                tableContainer.appendChild(this.createRecapTable(data));

                this.recapStandaloneBody.appendChild(tableContainer);
                this.recapStandaloneRow.style.display = 'flex';
                this.recapStandaloneWrapper.style.display = 'block';
            }

            toggleDiagramStandalone(show, data = []) {
                const maturityContainer = document.getElementById('diagram-maturity-container');

                if (!this.diagramStandaloneRow || !this.diagramStandaloneWrapper || !this.diagramStandaloneBody) {
                    return;
                }

                if (!show || !data.length) {
                    this.diagramStandaloneRow.style.display = 'none';
                    this.diagramStandaloneWrapper.style.display = 'none';
                    this.diagramStandaloneBody.innerHTML = '';
                    if (maturityContainer) maturityContainer.style.display = 'none';
                    if (this.diagramChartInstance) {
                        this.diagramChartInstance.destroy();
                        this.diagramChartInstance = null;
                    }
                    return;
                }

                this.diagramStandaloneBody.innerHTML = '';

                const container = document.createElement('div');
                container.className = 'bg-white p-4 rounded-lg border border-gray-200 shadow-sm';
                container.innerHTML = '<canvas id="diagramRadarChart" height="640" class="w-100"></canvas>';
                this.diagramStandaloneBody.appendChild(container);

                this.diagramStandaloneRow.style.display = 'flex';
                this.diagramStandaloneWrapper.style.display = 'block';
                if (maturityContainer) maturityContainer.style.display = 'block';

                this.renderDiagramChart(data);
            }

            renderDiagramChart(data) {
                const ctx = document.getElementById('diagramRadarChart');
                if (!ctx) return;

                if (this.diagramChartInstance) {
                    this.diagramChartInstance.destroy();
                }

                const labels = data.map(item => item.objectiveId);
                const agreedData = data.map(item => item.level);
                const dataMaximum = this.getMaximumCapabilityData();
                const maxDataSliced = dataMaximum.slice(0, labels.length);
                const targetData = labels.map(id => this.getTargetCapabilityForObjective(id));

                // Calculate Maturity Level
                const totalLevel = agreedData.reduce((sum, val) => sum + val, 0);
                const maturity = data.length > 0 ? (totalLevel / data.length).toFixed(2) : '0.00';

                // Update the static element
                const maturityValueDiv = document.getElementById('diagram-maturity-value');
                if (maturityValueDiv) {
                    maturityValueDiv.textContent = maturity;
                }

                this.diagramChartInstance = new Chart(ctx, {
                    type: 'radar',
                    data: {
                        labels,
                        datasets: [{
                            label: 'Capability Level',
                            data: agreedData,
                            fill: true,
                            backgroundColor: 'rgba(54, 162, 235, 0.18)',
                            borderColor: 'rgb(37, 99, 235)',
                            pointBackgroundColor: 'rgb(37, 99, 235)',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: 'rgb(37, 99, 235)'
                        }, {
                            label: 'Target Capability',
                            data: targetData,
                            fill: true,
                            backgroundColor: 'rgba(16, 185, 129, 0.18)',
                            borderColor: 'rgb(16, 185, 129)',
                            pointBackgroundColor: 'rgb(16, 185, 129)',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: 'rgb(16, 185, 129)'
                        }, {
                            label: 'Maximum Capability',
                            data: maxDataSliced,
                            fill: true,
                            backgroundColor: 'rgba(255, 159, 64, 0.25)',
                            borderColor: 'rgb(255, 159, 64)',
                            pointBackgroundColor: 'rgb(255, 159, 64)',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: 'rgb(255, 159, 64)'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        elements: {
                            line: {
                                borderWidth: 3
                            }
                        },
                        scales: {
                            r: {
                                angleLines: {
                                    display: true
                                },
                                suggestedMin: 0,
                                suggestedMax: 5,
                                ticks: {
                                    stepSize: 1,
                                    backdropColor: 'transparent'
                                },
                                pointLabels: {
                                    font: {
                                        size: labels.length > 30 ? 9 : 11,
                                        family: 'Inter, "Helvetica Neue", Arial, sans-serif'
                                    }
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                position: 'top'
                            },
                            title: {
                                display: true,
                                text: `Hasil I&T Maturity Assessment ${spiderDiagramClientName} - ${data.length} Governance & Management Objective`,
                                font: {
                                    size: 18,
                                    weight: 'bold'
                                }
                            },
                            tooltip: {
                                callbacks: {
                                    title: (tooltipItems) => tooltipItems[0]?.label || '',
                                    label: (ctx) => `${ctx.dataset.label}: ${ctx.formattedValue}`
                                }
                            }
                        }
                    }
                });
            }

            createDomainChartRow({
                objectiveId,
                objectiveName,
                level,
                valueLabel = '0.00',
                ratingString = '0N',
                ratings = {},
                meta = {},
                maxCapability = 5
            }) {
                const tr = document.createElement('tr');

                // Gamo Column (ID)
                const tdGamo = document.createElement('td');
                tdGamo.innerHTML = `<span class="fw-bold text-primary">${objectiveId}</span>`;
                tr.appendChild(tdGamo);

                // Gamo Name Column
                const tdGamoName = document.createElement('td');
                tdGamoName.innerHTML =
                    `<span class="small text-muted text-truncate d-block" style="max-width: 300px;" title="${objectiveName}">${objectiveName}</span>`;
                tr.appendChild(tdGamoName);

                const unifiedLevelColor = '#0f6ad9';

                // Level 0-5 Columns
                for (let i = 0; i <= 5; i++) {
                    const tdLevel = document.createElement('td');
                    tdLevel.className = 'text-center p-0';
                    tdLevel.style.height = '26px';

                    if (i <= level) {
                        tdLevel.style.backgroundColor = unifiedLevelColor;
                        tdLevel.style.color = unifiedLevelColor;
                        tdLevel.innerHTML =
                            `<span class="d-block w-100" style="line-height: 24px; font-size: 0.78rem; font-weight: 600; color: inherit;">${i}</span>`;
                    } else {
                        tdLevel.style.backgroundColor = '#f8f9fa';
                        tdLevel.innerHTML =
                            `<span class="d-block w-100 text-muted" style="line-height: 24px; font-size: 0.78rem; opacity: 0.45;">-</span>`;
                    }
                    tr.appendChild(tdLevel);
                }

                const tdValue = document.createElement('td');
                tdValue.className = 'text-center fw-semibold text-dark';
                tdValue.textContent = valueLabel;
                tr.appendChild(tdValue);

                // Rating Column
                const tdCurrent = document.createElement('td');
                tdCurrent.className = 'text-center';
                const averageNote = meta && typeof meta.average === 'number' ?
                    `<div class="mt-1"><small class="text-muted">Avg: ${meta.average.toFixed(2)}</small></div>` :
                    '';

                tdCurrent.innerHTML = `
            <span class="fw-bold" style="font-size: 1rem;">${ratingString}</span>
            ${averageNote}
        `;
                tr.appendChild(tdCurrent);

                // Maximum Capability Column
                const tdMax = document.createElement('td');
                tdMax.className = 'text-center fw-bold text-secondary';
                tdMax.textContent = maxCapability;
                tr.appendChild(tdMax);

                return tr;
            }

            getDomainFullName(domainCode) {
                return this.config.domainNames[domainCode] || domainCode;
            }

            parseNotePayload(rawValue, rawEvidence = null) {
                const emptyPayload = {
                    evidence: '',
                    note: ''
                };

                const normalizeText = (value) => {
                    if (value === null || value === undefined) {
                        return '';
                    }

                    return typeof value === 'string' ? value : String(value);
                };

                if (rawEvidence !== null && rawEvidence !== undefined) {
                    return {
                        evidence: normalizeText(rawEvidence),
                        note: normalizeText(rawValue)
                    };
                }

                if (rawValue === null || rawValue === undefined || rawValue === '') {
                    return emptyPayload;
                }

                if (typeof rawValue === 'object') {
                    return {
                        evidence: normalizeText(rawValue.evidence || rawValue.comment || ''),
                        note: normalizeText(rawValue.note || rawValue.notes || '')
                    };
                }

                if (typeof rawValue === 'string') {
                    try {
                        const parsed = JSON.parse(rawValue);
                        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
                            return {
                                evidence: normalizeText(parsed.evidence || parsed.comment || ''),
                                note: normalizeText(parsed.note || parsed.notes || '')
                            };
                        }
                    } catch (error) {
                        // Plain text without an evidence field must remain a note.
                    }

                    return {
                        evidence: '',
                        note: rawValue
                    };
                }

                return emptyPayload;
            }

            setupFinishUnlockButtons() {
                const finishBtn = document.getElementById('btn-finish-assessment');
                const unlockBtn = document.getElementById('btn-unlock-assessment');

                if (finishBtn) {
                    finishBtn.addEventListener('click', async () => {
                        const confirmed = await this.confirmAction({
                            title: 'Selesaikan assessment ini?',
                            text: 'Status akan berubah menjadi selesai dan semua field terkunci sampai Anda memilih Edit.',
                            icon: 'warning',
                            confirmButtonText: 'Ya, selesaikan'
                        });
                        if (confirmed) {
                            this.finishAssessment();
                        }
                    });
                }

                if (unlockBtn) {
                    unlockBtn.addEventListener('click', async () => {
                        const confirmed = await this.confirmAction({
                            title: 'Buka mode edit?',
                            text: 'Assessment akan dibuka kembali sehingga Anda bisa melakukan perubahan.',
                            icon: 'info',
                            confirmButtonText: 'Ya, edit sekarang'
                        });
                        if (confirmed) {
                            this.unlockAssessment();
                        }
                    });
                }
            }

            setActionButtonsDisabled(disabled) {
                ['save-assessment', 'btn-finish-assessment', 'btn-unlock-assessment'].forEach(id => {
                    const btn = document.getElementById(id);
                    if (btn) {
                        btn.disabled = disabled;
                        btn.classList.toggle('disabled', disabled);
                    }
                });
            }

            async confirmAction({
                title = 'Are you sure?',
                text = '',
                icon = 'question',
                confirmButtonText = 'Yes',
                cancelButtonText = 'Cancel'
            } = {}) {
                if (window.Swal) {
                    const result = await Swal.fire({
                        title,
                        text,
                        icon,
                        showCancelButton: true,
                        confirmButtonColor: '#0f6ad9',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText,
                        cancelButtonText
                    });
                    return result.isConfirmed;
                }
                return confirm(text || title);
            }

            async showAlert({
                title = 'Done',
                text = '',
                icon = 'success',
                confirmButtonText = 'OK'
            } = {}) {
                if (window.Swal) {
                    await Swal.fire({
                        title,
                        text,
                        icon,
                        confirmButtonColor: '#0f6ad9',
                        confirmButtonText
                    });
                    return;
                }
                alert(text || title);
            }

            checkInitialStatus() {
                this.updateStatusUI(this.status);
                if (this.status === 'finished') {
                    this.lockInterface();
                }
            }

            updateStatusUI(status) {
                const finishBtn = document.getElementById('btn-finish-assessment');
                const unlockBtn = document.getElementById('btn-unlock-assessment');
                const statusBadge = document.getElementById('status-badge');
                const statusText = statusBadge ? statusBadge.querySelector('.status-text') : null;
                const saveBtn = document.getElementById('save-assessment');

                if (status === 'finished') {
                    if (finishBtn) finishBtn.style.display = 'none';
                    if (unlockBtn) unlockBtn.style.display = 'inline-flex';
                    if (statusBadge) {
                        statusBadge.className = 'assessment-status-chip status-finished';
                    }
                    if (statusText) {
                        statusText.textContent = 'Finished';
                    }
                    if (saveBtn) saveBtn.style.display = 'none';
                } else {
                    if (finishBtn) finishBtn.style.display = 'inline-flex';
                    if (unlockBtn) unlockBtn.style.display = 'none';
                    if (statusBadge) {
                        statusBadge.className = 'assessment-status-chip status-draft';
                    }
                    if (statusText) {
                        statusText.textContent = 'Draft';
                    }
                    if (saveBtn) saveBtn.style.display = 'inline-flex';
                }
            }

            async finishAssessment() {
                this.setActionButtonsDisabled(true);
                try {
                    const response = await fetch(`/assessment/${this.currentEvalId}/finish`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        }
                    });

                    if (!response.ok) {
                        const payload = await response.json().catch(() => ({}));
                        throw new Error(payload.message || 'Failed to finish assessment');
                    }

                    this.status = 'finished';
                    this.updateStatusUI('finished');
                    this.lockInterface();
                    await this.showAlert({
                        title: 'Assessment selesai',
                        text: 'Semua input dikunci. Gunakan tombol Edit bila perlu mengubah.',
                        icon: 'success'
                    });
                } catch (error) {
                    console.error('Error finishing assessment:', error);
                    await this.showAlert({
                        title: 'Gagal menyelesaikan',
                        text: error.message || 'Silakan coba beberapa saat lagi.',
                        icon: 'error'
                    });
                } finally {
                    this.setActionButtonsDisabled(false);
                }
            }

            async unlockAssessment() {
                this.setActionButtonsDisabled(true);
                try {
                    const response = await fetch(`/assessment/${this.currentEvalId}/unlock`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        }
                    });

                    if (!response.ok) {
                        const payload = await response.json().catch(() => ({}));
                        throw new Error(payload.message || 'Failed to enable editing');
                    }

                    this.status = 'in_progress';
                    this.updateStatusUI('in_progress');
                    this.unlockInterface();
                    await this.showAlert({
                        title: 'Mode edit aktif',
                        text: 'Anda sudah bisa memperbarui assessment kembali.',
                        icon: 'success'
                    });
                } catch (error) {
                    console.error('Error unlocking assessment:', error);
                    await this.showAlert({
                        title: 'Gagal mengaktifkan mode edit',
                        text: error.message || 'Silakan coba beberapa saat lagi.',
                        icon: 'error'
                    });
                } finally {
                    this.setActionButtonsDisabled(false);
                }
            }

            lockInterface() {
                const selectors = [
                    '.activity-rating-select',
                    '.evidence-input',
                    '.note-input',
                    '.evidence-history-select',
                    '.evidence-modal-trigger'
                ];
                document.querySelectorAll(selectors.join(',')).forEach(el => {
                    el.disabled = true;
                    if (el.tagName === 'TEXTAREA') {
                        el.readOnly = true;
                        el.classList.add('bg-light');
                    }
                });


            }

            unlockInterface() {
                const selectors = [
                    '.activity-rating-select',
                    '.evidence-input',
                    '.note-input',
                    '.evidence-history-select',
                    '.evidence-modal-trigger'
                ];
                document.querySelectorAll(selectors.join(',')).forEach(el => {
                    el.disabled = false;
                    if (el.tagName === 'TEXTAREA') {
                        el.readOnly = false;
                        el.classList.remove('bg-light');
                    }
                });


            }

            openRecapInNewTab() {
                const data = this.buildGamoRecapData();
                if (!data.length) {
                    this.showNotification('No data available for recap', 'warning');
                    return;
                }

                const newWindow = window.open('', '_blank');
                if (!newWindow) {
                    this.showNotification('Pop-up blocked. Please allow pop-ups for this site.', 'error');
                    return;
                }

                const labels = data.map(item => item.domain);
                const targetMap = this.targetCapabilityMap || {};
                const targetData = data.map(item => targetMap[item.objectiveId] ?? null);

                // Maximum Capability Data from Step 4 reference
                const dataMaximum = [
                    4, 5, 4, 4, 4, 5, 4, 5, 4, 5, 5, 4, 5, 4, 5, 5, 5, 5, 5, 5,
                    4, 4, 5, 5, 4, 5, 5, 5, 5, 4, 5, 5, 5, 5, 4, 5, 5, 5, 5, 4
                ];
                const maxDataSliced = dataMaximum.slice(0, labels.length);

                const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Assessment Recap</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/chart.js"><\/script>
                <style>
                    body { padding: 20px; background-color: #f8f9fa; }
                    .card { margin-bottom: 20px; box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,0.075); border: none; }
                    .card-header { background-color: #0d6efd; color: white; padding: 1rem; }
                    .table th { background-color: #f8f9fa; }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-primary text-white py-3">
                            <h6 class="mb-0">Agreed Target Capability Radar</h6>
                        </div>
                        <div class="card-body" style="padding: 1rem;">
                            <div class="mt-2" style="max-width:600px; margin:auto;">
                                <canvas id="recapRadarChart" height="600"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card shadow-sm">
                        <div class="card-header bg-primary text-white py-3">
                            <h6 class="mb-0">Capability Level Summary</h6>
                        </div>
                        <div class="card-body p-0">
                            <table class="table table-bordered table-striped mb-0">
                                <thead>
                                    <tr>
                                        <th>Domain</th>
                                        <th>Level</th>
                                        <th>Rating</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${data.map(row => `
                                                                                                        <tr>
                                                                                                            <td>${row.domain}</td>
                                                                                                            <td>${row.level}</td>
                                                                                                            <td>
                                                                                                                <div class="d-flex gap-1">
                                                                                                                    ${Object.entries(row.ratings).map(([lvl, rating]) => 
                                                                                                                        `<span class="badge ${rating === 'F' ? 'bg-success' : (rating === 'L' ? 'bg-warning text-dark' : (rating === 'P' ? 'bg-info text-dark' : 'bg-secondary'))}">${lvl}:${rating}</span>`
                                                                                                                    ).join('')}
                                                                                                                </div>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <script>
                    const ctx = document.getElementById('recapRadarChart').getContext('2d');
                    new Chart(ctx, {
                        type: 'radar',
                        data: {
                            labels: ${JSON.stringify(labels)},
                            datasets: [{
                                label: 'Agreed Target Capability',
                                data: ${JSON.stringify(targetData)},
                                fill: true,
                                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                borderColor: 'rgb(54, 162, 235)',
                                pointBackgroundColor: 'rgb(54, 162, 235)',
                                pointBorderColor: '#fff',
                                pointHoverBackgroundColor: '#fff',
                                pointHoverBorderColor: 'rgb(54, 162, 235)'
                            }, {
                                label: 'Maximum Capability',
                                data: ${JSON.stringify(maxDataSliced)},
                                fill: true,
                                backgroundColor: 'rgba(255, 159, 64, 0.2)',
                                borderColor: 'rgb(255, 159, 64)',
                                pointBackgroundColor: 'rgb(255, 159, 64)',
                                pointBorderColor: '#fff',
                                pointHoverBackgroundColor: '#fff',
                                pointHoverBorderColor: 'rgb(255, 159, 64)'
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            elements: {
                                line: { borderWidth: 3 }
                            },
                            scales: {
                                r: {
                                    angleLines: { display: true },
                                    suggestedMin: 0,
                                    suggestedMax: 5,
                                    ticks: {
                                        stepSize: 1,
                                        backdropColor: 'transparent'
                                    },
                                    pointLabels: {
                                        font: { size: 11 }
                                    }
                                }
                            },
                            plugins: {
                                legend: { position: 'top' },
                                title: { display: false }
                            }
                        }
                    });
                <\/script>
            </body>
            </html>
        `;

                newWindow.document.write(htmlContent);
                newWindow.document.close();
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            const canManageAssessmentFlag = window.CAN_MANAGE_ASSESSMENT === true || window.CAN_MANAGE_ASSESSMENT === 'true';
            new COBITAssessmentManager({{ $evalId }}, '{{ $evaluation->status ?? 'draft' }}', canManageAssessmentFlag);
            initAssessmentToolbarSticky();
        });

        function initAssessmentToolbarSticky() {
            const toolbarAnchor = document.getElementById('assessment-toolbar-anchor');
            const toolbar = document.getElementById('assessment-toolbar');

            if (!toolbarAnchor || !toolbar) {
                return;
            }

            const breadcrumbWrapper = document.querySelector('.breadcrumb-wrapper');

            const getTopOffset = () => {
                const rootStyles = window.getComputedStyle(document.documentElement);
                const navbarHeight = parseFloat(rootStyles.getPropertyValue('--navbar-height')) || 68;
                const breadcrumbHeight = breadcrumbWrapper ? breadcrumbWrapper.offsetHeight : 0;

                return Math.round(navbarHeight + breadcrumbHeight + 12);
            };

            const syncToolbarState = () => {
                const anchorRect = toolbarAnchor.getBoundingClientRect();
                const topOffset = getTopOffset();
                const shouldStick = anchorRect.top <= topOffset;

                toolbar.classList.toggle('is-sticky', shouldStick);

                if (shouldStick) {
                    toolbar.style.top = `${topOffset}px`;
                    toolbar.style.left = `${anchorRect.left}px`;
                    toolbar.style.width = `${anchorRect.width}px`;
                    toolbarAnchor.style.minHeight = `${toolbar.offsetHeight}px`;
                } else {
                    toolbar.style.top = '';
                    toolbar.style.left = '';
                    toolbar.style.width = '';
                    toolbarAnchor.style.minHeight = '';
                }
            };

            const requestSync = () => window.requestAnimationFrame(syncToolbarState);

            window.addEventListener('scroll', requestSync, {
                passive: true
            });
            window.addEventListener('resize', requestSync);

            if ('ResizeObserver' in window) {
                const observer = new ResizeObserver(requestSync);
                observer.observe(toolbarAnchor);
                observer.observe(toolbar);

                if (breadcrumbWrapper) {
                    observer.observe(breadcrumbWrapper);
                }
            }

            requestSync();
        }
    </script>

    {{-- Custom CSS for better styling --}}
    <style>
        .objective-card {
            transition: transform 0.2s ease-in-out;
        }

        .assessment-status-chip {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.35rem 0.9rem;
            border-radius: 999px;
            font-weight: 600;
            font-size: 0.85rem;
            border: 1px solid transparent;
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1);
        }

        .assessment-status-chip .status-dot {
            width: 0.55rem;
            height: 0.55rem;
            border-radius: 50%;
            background: currentColor;
            display: inline-block;
            box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.25);
        }

        .assessment-status-chip.status-draft {
            background: rgba(255, 255, 255, 0.12);
            color: rgba(255, 255, 255, 0.85);
            border-color: rgba(255, 255, 255, 0.25);
        }

        .assessment-status-chip.status-finished {
            background: rgba(16, 185, 129, 0.18);
            color: #d9ffe4;
            border-color: rgba(16, 185, 129, 0.45);
        }

        .objective-card:hover {
            transform: translateY(-5px);
        }

        .card {
            border: none;
            border-radius: 10px;
            overflow: hidden;
        }

        .hero-card {
            overflow: visible;
        }

        .card-header {
            border-bottom: none;
        }

        .objective-header {
            background-color: #0f2b5c;
            color: #fff;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        }

        .objective-title {
            font-size: 1.15rem;
            font-weight: 600;
        }

        .objective-domain {
            font-size: 0.95rem;
            opacity: 0.85;
        }

        .objective-stat {
            font-size: 0.9rem;
        }

        .capability-badge {
            display: inline-block;
            padding: 0.35rem 0.8rem;
            border-radius: 999px;
            font-weight: 600;
        }

        .capability-badge.badge-level-0 {
            background-color: #FF4F30;
            color: #FFffff;
        }

        .capability-badge.badge-level-1 {
            background-color: #f8d7da;
            color: #58151c;
        }

        .capability-badge.badge-level-2 {
            background-color: #fff3cd;
            color: #664d03;
        }

        .capability-badge.badge-level-3 {
            background-color: #cff4fc;
            color: #055160;
        }

        .capability-badge.badge-level-4 {
            background-color: #dbe4ff;
            color: #102a5b;
        }

        .capability-badge.badge-level-5 {
            background-color: #d1e7dd;
            color: #0f5132;
        }

        .objective-description-text,
        .objective-purpose-text {
            font-size: 0.95rem;
            line-height: 1.5;
            color: rgba(255, 255, 255, 0.9);
        }

        .objective-summary {
            display: flex;
            gap: 1.25rem;
            flex-wrap: wrap;
        }

        .summary-column {
            flex: 1 1 260px;
            background-color: rgba(255, 255, 255, 0.08);
            border-radius: 0.5rem;
            padding: 0.85rem 1rem;
        }

        .summary-label {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            margin-bottom: 0.35rem;
            opacity: 0.75;
        }

        .practice-summary-block {
            margin: 1rem 1.25rem 0;
            border: 1px solid var(--bs-border-color, #dee2e6);
            border-radius: 0.35rem;
            overflow: hidden;
            background: var(--bs-body-bg, #fff);
            box-shadow: none;
        }

        .practice-summary-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            padding: 0.75rem 0.95rem;
            background: var(--bs-light, #f8f9fa);
            border-bottom: 1px solid var(--bs-border-color, #dee2e6);
        }

        .practice-summary-toggle {
            width: 100%;
            border: none;
            appearance: none;
            font: inherit;
            color: inherit;
            text-align: left;
            cursor: pointer;
            box-shadow: none;
        }

        .practice-summary-toggle .toggle-indicator {
            color: var(--bs-secondary-color, #6c757d);
            transition: transform 0.25s ease;
        }

        .practice-summary-block.collapsed .toggle-indicator {
            transform: rotate(180deg);
        }

        .practice-summary-content {
            background: var(--bs-body-bg, #fff);
        }

        .practice-summary-title {
            font-size: 0.98rem;
            font-weight: 700;
            color: var(--bs-body-color, #212529);
        }

        .practice-summary-subtitle {
            font-size: 0.8rem;
            color: var(--bs-secondary-color, #6c757d);
        }

        .practice-summary-table {
            margin-bottom: 0;
        }

        .practice-summary-table thead th {
            background: var(--bs-tertiary-bg, #f8f9fa);
            color: var(--bs-body-color, #212529);
            border-color: var(--bs-border-color, #dee2e6);
            font-weight: 700;
            letter-spacing: 0.01em;
            padding: 0.35rem 0.4rem;
        }

        .practice-summary-table td,
        .practice-summary-table th {
            border-color: var(--bs-border-color, #dee2e6);
            vertical-align: middle;
            padding: 0.32rem 0.4rem;
        }

        .practice-summary-table tbody td {
            background: var(--bs-body-bg, #fff);
            color: var(--bs-body-color, #212529);
        }

        .practice-summary-table tfoot td {
            background: var(--bs-light, #f8f9fa);
            color: var(--bs-body-color, #212529);
        }

        .practice-summary-table tfoot .practice-summary-metric-row td {
            background: var(--bs-light, #f8f9fa);
            border-top-color: var(--bs-border-color, #dee2e6);
        }

        .practice-summary-table .practice-cell {
            min-width: 320px;
        }

        .practice-summary-code {
            font-weight: 700;
            color: var(--bs-body-color, #212529);
        }

        .practice-summary-name {
            color: var(--bs-secondary-color, #6c757d);
        }

        .practice-summary-table .level-col,
        .practice-summary-table .total-col {
            width: 88px;
        }

        .practice-summary-metric-value {
            display: inline-block;
            min-width: 72px;
            font-size: 1rem;
            font-weight: 700;
            color: var(--bs-body-color, #212529);
        }

        .btn-group .btn {
            border-radius: 0;
        }

        .btn-group .btn:first-child {
            border-top-left-radius: 0.375rem;
            border-bottom-left-radius: 0.375rem;
        }

        .btn-group .btn:last-child {
            border-top-right-radius: 0.375rem;
            border-bottom-right-radius: 0.375rem;
        }

        .badge {
            font-size: 0.75rem;
        }

        .assessment-toolbar-anchor {
            position: relative;
        }

        .domain-tabs-wrapper {
            background: #f7f9ff;
            border-radius: 0.8rem;
            padding: 0.25rem 0.5rem 0.2rem;
            border: 1px solid #e1e6f5;
            overflow-x: auto;
            transition: box-shadow 0.2s ease, transform 0.2s ease, background-color 0.2s ease;
        }

        .domain-tabs-wrapper.is-sticky {
            position: fixed;
            z-index: 1015;
            background: rgba(247, 249, 255, 0.96);
            box-shadow: 0 18px 36px rgba(15, 43, 92, 0.14);
            backdrop-filter: blur(14px);
            transform: translateY(0);
        }

        .domain-tabs {
            display: flex;
            flex-wrap: nowrap;
            gap: 0.65rem;
            justify-content: flex-start;
            min-width: max-content;
        }

        .domain-tab {
            border: none;
            background: transparent;
            color: #0f6ad9;
            padding: 0.22rem 0.85rem;
            border-radius: 0.55rem;
            font-weight: 600;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            transition: all 0.2s ease;
        }

        .domain-tab:hover {
            color: #0c4fb5;
        }

        .domain-tab.active {
            background: #0f73c9;
            color: #fff;
            box-shadow: 0 12px 24px rgba(15, 106, 217, 0.25);
        }

        .objective-filter-wrapper {
            margin-top: 0.75rem;
            padding-top: 0.35rem;
            border-top: 1px solid #dfe4f4;
        }

        .objective-filter-tabs {
            display: flex;
            flex-wrap: wrap;
            gap: 0.35rem;
            overflow-x: auto;
        }

        .objective-filter-tab {
            border: none;
            background: transparent;
            color: #6a7091;
            font-weight: 600;
            font-size: 0.85rem;
            letter-spacing: 0.04em;
            padding: 0.35rem 0.65rem;
            border-bottom: 2px solid transparent;
            border-radius: 0;
            transition: color 0.15s ease, border-color 0.15s ease;
        }

        .objective-filter-tab:hover {
            color: #0c4fb5;
        }

        .objective-filter-tab.active {
            color: #0f2b5c;
            border-bottom-color: #0f6ad9;
        }

        @media (max-width: 991.98px) {
            .domain-tabs-wrapper.is-sticky {
                left: 0.75rem !important;
                width: calc(100vw - 1.5rem) !important;
            }
        }

        .domain-overview-wrapper {
            border: 1px solid #e2e8fb;
            border-radius: 0.9rem;
            background: #fdfdff;
            box-shadow: 0 16px 35px rgba(15, 43, 92, 0.06);
            padding: 0;
        }

        .domain-overview-toggle {
            width: 100%;
            border: none;
            background: transparent;
            padding: 0.95rem 1.25rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
            color: #0f2b5c;
            font-size: 1rem;
            letter-spacing: 0.03em;
        }

        .domain-overview-toggle .toggle-indicator {
            transition: transform 0.25s ease;
        }

        .domain-overview-wrapper.collapsed .toggle-indicator {
            transform: rotate(180deg);
        }

        .domain-level-card {
            background: #fff;
            border: 1px solid #e2e8fb;
            border-radius: 0.85rem;
            padding: 1.5rem;
            box-shadow: 0 18px 40px rgba(15, 43, 92, 0.08);
        }

        .domain-level-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .domain-level-label {
            font-size: 0.78rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: #6f7a98;
            margin-bottom: 0.25rem;
        }

        .domain-level-title {
            margin: 0;
            font-weight: 700;
            color: #0f2b5c;
        }

        .domain-level-pill {
            background: #0f2b5c;
            color: #fff;
            border-radius: 999px;
            padding: 0.4rem 1.3rem;
            font-weight: 600;
            letter-spacing: 0.06em;
        }

        .domain-level-table {
            border: 1px solid #e2e8fb;
            border-radius: 0.75rem;
            overflow: hidden;
        }

        .domain-level-table-head,
        .domain-level-row {
            display: grid;
            grid-template-columns: minmax(170px, 1.3fr) minmax(250px, 2fr) 150px;
            gap: 0.85rem;
            padding: 0.9rem 1.2rem;
            align-items: center;
        }

        .domain-level-table {
            max-height: 320px;
            overflow-y: auto;
        }

        .domain-level-table-head {
            background: #f6f8ff;
            font-weight: 600;
            color: #42507a;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            border-bottom: 1px solid #e2e8fb;
        }

        .recap-table-wrapper {
            border-radius: 0.75rem;
            border: 1px solid #e2e8fb;
        }

        .recap-table {
            margin: 0;
            background: #fff;
            border-collapse: collapse;
        }

        .recap-table th,
        .recap-table td {}

        .recap-table .level-box,
        .recap-table .gap-box {
            width: 100%;
            min-height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }

        .recap-table .gap-box {
            background: transparent;
        }

        .recap-table thead th {
            position: sticky;
            top: 0;
            background: #f6f8ff;
            color: #42507a;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.78rem;
            letter-spacing: 0.04em;
            border-bottom: 1px solid #e2e8fb;
        }

        .recap-table tbody tr:nth-child(odd) {
            background: #fbfcff;
        }

        .recap-table tbody tr:hover {
            background: #f0f4ff;
        }

        .recap-domain-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.25rem 0.8rem;
            border-radius: 999px;
            font-weight: 600;
            letter-spacing: 0.04em;
            font-size: 0.85rem;
            border: 1px solid transparent;
        }

        .domain-pill-edm {
            background: rgba(15, 43, 92, 0.12);
            color: #081a3d;
            border-color: rgba(15, 43, 92, 0.3);
        }

        .domain-pill-apo {
            background: rgba(8, 122, 194, 0.12);
            color: #084c8c;
            border-color: rgba(8, 122, 194, 0.3);
        }

        .domain-pill-bai {
            background: rgba(19, 110, 82, 0.12);
            color: #0b5136;
            border-color: rgba(19, 110, 82, 0.3);
        }

        .domain-pill-dss {
            background: rgba(207, 99, 26, 0.12);
            color: #81370a;
            border-color: rgba(207, 99, 26, 0.3);
        }

        .domain-pill-mea {
            background: rgba(103, 35, 156, 0.12);
            color: #4b0f82;
            border-color: rgba(103, 35, 156, 0.3);
        }

        .recap-objective-code {
            font-weight: 600;
            color: #0f2b5c;
            letter-spacing: 0.03em;
        }

        .recap-objective-name {
            font-size: 0.86rem;
            color: #5a6482;
        }

        .domain-level-row:nth-child(odd) {
            background: #fbfcff;
        }

        .domain-level-row:not(:last-child) {
            border-bottom: 1px solid #eef2ff;
        }

        .domain-level-objective {
            display: flex;
            flex-direction: column;
            gap: 0.15rem;
        }

        .domain-level-objective strong {
            color: #0f2b5c;
            font-size: 0.95rem;
        }

        .domain-level-objective span {
            font-size: 0.85rem;
            color: #66718f;
        }

        .domain-level-bar {
            display: flex;
            gap: 0.35rem;
        }

        .level-segment {
            flex: 1;
            border-radius: 0.4rem;
            border: 1px solid #d7ddf1;
            text-align: center;
            font-weight: 600;
            font-size: 0.8rem;
            padding: 0.35rem 0;
            color: #7a85a8;
        }

        .level-segment.active {
            color: #fff;
            border-color: transparent;
            box-shadow: 0 6px 14px rgba(15, 106, 217, 0.18);
        }

        .level-segment.level-tier-1.active {
            background: #f97316;
        }

        .level-segment.level-tier-2.active {
            background: #facc15;
            color: #7a5d07;
            box-shadow: none;
        }

        .level-segment.level-tier-3.active {
            background: #86efac;
            color: #065f46;
            box-shadow: none;
        }

        .level-segment.level-tier-4.active {
            background: #15803d;
        }

        .level-segment.level-tier-5.active {
            background: linear-gradient(120deg, #0f6ad9, #0c4fb5);
        }

        .domain-level-current {
            text-align: right;
        }

        .level-badge {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-width: 110px;
            gap: 0.1rem;
            padding: 0.4rem 0.85rem;
            border-radius: 1.5rem;
            font-weight: 600;
            border: 1px solid transparent;
            font-size: 0.85rem;
        }

        .level-badge small {
            font-size: 0.7rem;
            text-transform: none;
            letter-spacing: 0.03em;
            opacity: 0.85;
        }

        .level-badge-1 {
            background: rgba(249, 115, 22, 0.15);
            color: #9a3412;
            border-color: rgba(249, 115, 22, 0.4);
        }

        .level-badge-2 {
            background: rgba(250, 204, 21, 0.2);
            color: #7a5d07;
            border-color: rgba(250, 204, 21, 0.6);
        }

        .level-badge-3 {
            background: rgba(134, 239, 172, 0.25);
            color: #065f46;
            border-color: rgba(16, 185, 129, 0.45);
        }

        .level-badge-4 {
            background: rgba(21, 128, 61, 0.2);
            color: #064e3b;
            border-color: rgba(21, 128, 61, 0.5);
        }

        .level-badge-5 {
            background: rgba(15, 74, 129, 0.15);
            color: #0f2b5c;
            border-color: rgba(15, 74, 129, 0.45);
        }

        .card-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .bg-light {
            background-color: #f8f9fa !important;
        }

        /* Assessment Interface Styling */
        .capability-level-section {
            border: 1px solid #e2e8fb;
            border-radius: 0.85rem;
            padding: 1rem 1.25rem;
            background-color: #fff;
            box-shadow: 0 10px 25px rgba(15, 43, 92, 0.04);
        }

        .capability-level-section:not(:last-child) {
            margin-bottom: 1rem;
        }

        .level-section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .level-section-info {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 0.85rem;
        }

        .level-pill {
            background-color: #0f2b5c;
            color: #fff;
            border-radius: 999px;
            padding: 0.35rem 1.2rem;
            font-weight: 600;
            box-shadow: inset 0 -2px 0 rgba(0, 0, 0, 0.12);
        }

        .level-section-subtext {
            font-size: 0.9rem;
            color: #5e6681;
            font-weight: 500;
        }

        .level-section-actions {
            display: flex;
            align-items: center;
            gap: 0.9rem;
        }

        .capability-score {
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .level-score-chip {
            border-radius: 999px;
            padding: 0.35rem 1rem;
            letter-spacing: 0.03em;
            text-transform: uppercase;
            border: 1px solid transparent;
        }

        .score-chip-muted {
            background: #eef1f8;
            color: #5b6279;
        }

        .score-chip-danger {
            background: #fee4e2;
            color: #a01d17;
            border-color: #f8b4a9;
        }

        .score-chip-warning {
            background: #fff3cd;
            color: #7a5d07;
            border-color: #ffe69c;
        }

        .score-chip-info {
            background: #e0f2ff;
            color: #0b4c73;
            border-color: #b6e0fe;
        }

        .score-chip-success {
            background: #d1f2e2;
            color: #0f5132;
            border-color: #a5e3c6;
        }

        .sticky-action-group {
            position: fixed;
            right: 25px;
            bottom: 25px;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 0.45rem;
            z-index: 1050;
        }

        .sticky-action-btn {
            border-radius: 999px;
            padding: 0;
            font-weight: 600;
            font-size: 0 !important;
            /* Hide text completely in collapsed mode */
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            /* Center the icon perfectly */
            box-shadow: 0 10px 24px rgba(15, 106, 217, 0.18);
            transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            white-space: nowrap;
            overflow: hidden;
        }

        .sticky-action-btn:hover {
            width: 140px;
            padding: 0 1.25rem;
            justify-content: flex-start;
            font-size: 0.85rem !important;
            /* Restore text size on hover */
        }

        .sticky-action-btn i {
            font-size: 1.2rem !important;
            /* Ensure icon stays visible */
            margin-right: 0 !important;
            transition: margin 0.3s ease;
        }

        .sticky-action-btn:hover i {
            margin-right: 0.5rem !important;
        }

        .sticky-action-btn.btn-light {
            background: #fff;
            color: #0f2b5c;
            border: 1px solid rgba(15, 43, 92, 0.15);
        }

        .sticky-action-btn.btn-primary {
            background: linear-gradient(120deg, #0f6ad9, #0c4fb5);
            border: none;
        }

        .level-toggle-btn {
            border-radius: 999px;
            padding: 0.45rem 1.35rem;
            font-weight: 600;
            background: linear-gradient(120deg, #0f6ad9, #0c4fb5);
            color: #fff;
            border: none;
            box-shadow: 0 6px 15px rgba(15, 106, 217, 0.25);
            display: flex;
            align-items: center;
            gap: 0.35rem;
        }

        .level-toggle-btn:hover {
            color: #fff;
            transform: translateY(-1px);
        }

        .level-toggle-btn:disabled,
        .level-toggle-btn-disabled {
            background: #c6cdde;
            color: #6b738a;
            box-shadow: none;
        }

        .assessment-section {
            margin-top: 1rem;
            padding-top: 1.25rem;
            border-top: 1px solid #e5e8f4;
        }

        .assessment-table th {
            background-color: #eef2ff;
            border-bottom: 2px solid #d5dcf3;
            color: #0f2b5c;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.78rem;
            letter-spacing: 0.04em;
        }

        .assessment-table th,
        .assessment-table td {
            padding: 0.65rem;
            border-color: #d9d9d9;
        }

        .assessment-table.reference-hidden .reference-column-cell {
            display: none;
        }

        .assessment-table.reference-hidden .reference-column-header {
            display: none;
        }

        .assessment-table {
            min-width: 1460px;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .assessment-table td {
            vertical-align: top;
        }

        .assessment-table tbody tr:nth-child(even) {
            background-color: #fbfcff;
        }

        .practice-code-cell {
            background-color: #fff;
        }

        .practice-code-text {
            font-size: 0.9rem;
            font-weight: 600;
        }

        .practice-name-cell {
            font-size: 0.9rem;
        }

        .practice-name-cell small {
            font-size: 0.75rem;
        }

        .description-cell p {
            margin-bottom: 0;
        }

        .rating-cell select {
            width: 100%;
            margin-bottom: 0.35rem;
        }

        .reference-toggle-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.45rem;
            padding: 0.45rem 0.95rem;
            border: 1px solid #cbd5e1;
            border-radius: 999px;
            background: #fff;
            color: #64748b;
            transition: color 0.2s ease, border-color 0.2s ease, background-color 0.2s ease;
        }

        .reference-toggle-btn:hover {
            color: #334155;
            border-color: #94a3b8;
            background-color: #f8fafc;
        }

        .reference-cell {
            background-color: #fcfcfd;
            min-width: 220px;
        }

        .reference-list {
            padding-left: 1rem;
            margin: 0;
        }

        .reference-list li {
            margin-bottom: 0.45rem;
        }

        .reference-list li:last-child {
            margin-bottom: 0;
        }

        .reference-description {
            font-size: 0.9rem;
            color: #1f2937;
            line-height: 1.35;
        }

        .reference-target {
            margin-top: 0.15rem;
            font-size: 0.78rem;
            color: #6b7280;
            line-height: 1.3;
        }


        .activity-rating-select.rating-full {
            background-color: #198754;
            border-color: #198754;
            color: #fff;
        }

        .activity-rating-select.rating-high {
            background-color: #0dcaf0;
            border-color: #0dcaf0;
            color: #042c55;
        }

        .activity-rating-select.rating-medium {
            background-color: #ffe69c;
            border-color: #ffe69c;
            color: #5c4705;
        }

        .activity-rating-select.rating-low {
            background-color: #f8d7da;
            border-color: #f8d7da;
            color: #842029;
        }

        .evidence-cell .assessment-textarea,
        .notes-cell .assessment-textarea {
            width: 100%;
        }

        .evidence-input-wrapper {
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
        }

        .evidence-display {
            min-height: 38px;
            padding: 0.5rem 0.75rem;
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            background-color: #f8f9fa;
            font-size: 0.9rem;
        }

        .evidence-list li {
            margin-bottom: 0.15rem;
            line-height: 1.35;
        }

        .evidence-list li:last-child {
            margin-bottom: 0;
        }

        .evidence-history-select {
            font-size: 0.85rem;
        }

        .assessment-textarea {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            resize: vertical;
            min-height: 60px;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .assessment-textarea:focus {
            border-color: #86b7fe;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }

        .assessment-textarea::placeholder {
            color: #6c757d;
            font-style: italic;
        }

        /* Smooth animations */
        @keyframes slideDown {
            from {
                opacity: 0;
                max-height: 0;
                transform: translateY(-10px);
            }

            to {
                opacity: 1;
                max-height: 1000px;
                transform: translateY(0);
            }
        }

        .assessment-section {
            overflow: hidden;
            transition: all 0.3s ease;
        }

        /* Loading Overlay Styles */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 43, 92, 0.95);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease;
        }

        .loading-content {
            text-align: center;
            color: #fff;
            max-width: 400px;
            padding: 2rem;
        }

        .loading-spinner {
            width: 80px;
            height: 80px;
            margin: 0 auto 1.5rem;
            border: 6px solid rgba(255, 255, 255, 0.2);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .loading-text {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            letter-spacing: 0.03em;
        }

        .loading-progress-container {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 999px;
            overflow: hidden;
            margin-bottom: 1rem;
        }

        .loading-progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #0f6ad9, #00d4ff);
            border-radius: 999px;
            transition: width 0.3s ease;
            box-shadow: 0 0 20px rgba(0, 212, 255, 0.5);
        }

        .loading-percentage {
            font-size: 2rem;
            font-weight: 700;
            color: #00d4ff;
            text-shadow: 0 0 20px rgba(0, 212, 255, 0.5);
            letter-spacing: 0.05em;
        }

        /* Corner Loading Indicator (Non-blocking) */
        .corner-loading {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1040;
            background: linear-gradient(135deg, #0f2b5c, #1a3d6b);
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(15, 43, 92, 0.4);
            padding: 16px 20px;
            min-width: 280px;
            opacity: 0;
            transform: translateX(350px);
            transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            pointer-events: none;
        }

        .corner-loading.show {
            opacity: 1;
            transform: translateX(0);
        }

        .corner-loading-content {
            display: flex;
            align-items: flex-start;
            gap: 14px;
        }

        .corner-spinner {
            width: 32px;
            height: 32px;
            min-width: 32px;
            border: 3px solid rgba(255, 255, 255, 0.2);
            border-top-color: #00d4ff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        .corner-loading-info {
            flex: 1;
            min-width: 0;
        }

        .corner-loading-text {
            color: #fff;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 8px;
            line-height: 1.3;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .corner-loading-progress {
            width: 100%;
            height: 4px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 999px;
            overflow: hidden;
            margin-bottom: 6px;
        }

        .corner-progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #0f6ad9, #00d4ff);
            border-radius: 999px;
            transition: width 0.3s ease;
            box-shadow: 0 0 10px rgba(0, 212, 255, 0.6);
        }

        .corner-loading-percentage {
            color: #00d4ff;
            font-size: 0.85rem;
            font-weight: 700;
            text-align: right;
        }

        @media (max-width: 768px) {
            .corner-loading {
                right: 10px;
                top: 10px;
                min-width: 240px;
            }
        }

        .domain-scope-pill {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            border-radius: 999px;
            background: rgba(15, 106, 217, 0.08);
            color: #0f2b5c;
            font-weight: 600;
            border: 1px solid rgba(15, 106, 217, 0.12);
        }
    </style>
@endsection
