@extends('layouts.app')

@section('content')
<meta name="csrf-token" content="{{ csrf_token() }}">
@php($displayEvalId = $evaluation->eval_id)
@php($routeEvalId = $evaluation->encrypted_id)

<div class="container-fluid px-4 py-3">
    {{-- Header --}}
    <div class="card shadow-sm mb-4 hero-card" style="border:none;box-shadow:0 22px 45px rgba(14,33,70,0.15);">
        <div class="card-header hero-header py-4" style="background:linear-gradient(135deg,#081a3d,#0f2b5c);color:#fff;border:none;">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="hero-title" style="font-size:1.5rem;font-weight:700;letter-spacing:0.04em;">Activity Report</div>
                    <div class="hero-eval-id" style="font-size:1.05rem;font-weight:600;margin-top:0.25rem;letter-spacing:0.08em;text-transform:uppercase;color:rgba(255,255,255,0.85);">
                        {{ $objective->objective_id }} - {{ $objective->objective ?? 'Objective' }}
                    </div>
                </div>
                <div>
                    <a href="{{ route('assessment.report-activity-pdf', ['evalId' => $routeEvalId, 'objectiveId' => 'all']) }}{{ $filterLevel ? '?level=' . $filterLevel : '' }}" 
                       class="btn btn-sm btn-outline-danger fw-bold rounded-pill px-3 me-2 bg-white" 
                       target="_blank">
                        <i class="fas fa-file-pdf me-1"></i>Export All PDF
                    </a>
                    <a href="{{ route('assessment.report-activity-pdf', ['evalId' => $routeEvalId, 'objectiveId' => $objective->objective_id]) }}{{ $filterLevel ? '?level=' . $filterLevel : '' }}" 
                       class="btn btn-sm btn-danger text-white fw-bold rounded-pill px-3 me-2" 
                       target="_blank">
                        <i class="fas fa-file-pdf me-1"></i>Export PDF
                    </a>
                    <a href="{{ route('assessment.report', $routeEvalId) }}" class="btn btn-light btn-sm rounded-pill px-3">
                        <i class="fas fa-arrow-left me-2"></i>Back to Report
                    </a>
                </div>
            </div>
        </div>
    </div>

    {{-- Brief Info Section --}}
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm border-0" style="border-radius: 12px; overflow: hidden;">
                <div class="card-body p-0">
                    <div class="row g-0">
                        <div class="col-md-5 p-3 text-center bg-light border-end d-flex flex-column justify-content-center">
                            <div class="table-responsive">
                                <table class="table table-bordered mb-0" style="border: 1px solid #000; border-collapse: collapse; width: 100%;">
                                    <thead>
                                        <tr style="background-color: #9b59b6; color: #fff;">
                                            <th style="width: 25%; border: 1px solid #fff; background-color: #9b59b6; color: #fff; text-align: center; vertical-align: middle;">{{ $objective->objective_id }}</th>
                                            <th style="width: 25%; border: 1px solid #fff; font-size: 0.65rem; font-style: italic; text-align: center; vertical-align: middle; padding: 4px; background-color: #9b59b6; color: #fff;">Capability Level</th>
                                            <th style="width: 25%; border: 1px solid #fff; font-size: 0.65rem; font-style: italic; text-align: center; vertical-align: middle; padding: 4px; background-color: #9b59b6; color: #fff;">Rating</th>
                                            <th style="width: 25%; border: 1px solid #fff; font-size: 0.65rem; font-style: italic; text-align: center; vertical-align: middle; padding: 4px; background-color: #9b59b6; color: #fff;">Capability Target {{ $evaluation->tahun ?? '2025' }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr style="height: 40px;">
                                            <td style="background-color: #9b59b6; color: #fff; font-size: 0.65rem; font-weight: bold; font-style: italic; text-align: center; vertical-align: middle; border: 1px solid #fff; padding: 4px;">Capability Level:</td>
                                            <td style="background-color: #fff; color: #000; text-align: center; vertical-align: middle; font-weight: bold; font-size: 1.15rem; border: 1px solid #000; padding: 4px;">{{ $currentLevel }}</td>
                                            <td style="background-color: #fff; color: #000; text-align: center; vertical-align: middle; font-weight: bold; font-size: 1.15rem; border: 1px solid #000; padding: 4px;">{{ $ratingString }}</td>
                                            <td style="background-color: #fff; color: #000; text-align: center; vertical-align: middle; font-weight: bold; font-size: 1.15rem; border: 1px solid #000; padding: 4px;">{{ $targetLevel === null || $targetLevel === '' ? '-' : $targetLevel }}</td>
                                        </tr>
                                        <tr style="height: 40px;">
                                            <td style="background-color: #9b59b6; color: #fff; font-size: 0.65rem; font-weight: bold; font-style: italic; text-align: center; vertical-align: middle; border: 1px solid #fff; padding: 4px;">Max Level:</td>
                                            <td style="background-color: #fff; color: #000; text-align: center; vertical-align: middle; font-weight: bold; font-size: 1.15rem; border: 1px solid #000; padding: 4px;">{{ $maxLevel }}</td>
                                            <td style="background-color: #fff; border: 1px solid #000;"></td>
                                            <td style="background-color: #fff; border: 1px solid #000;"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-7 p-4">
                            <div class="row">
                                <div class="col-sm-4 mb-3 mb-sm-0">
                                    <div class="text-uppercase extreme-small fw-bold text-muted mb-1">Assessment ID</div>
                                    <div class="fw-bold text-dark" style="font-size: 1.1rem;">{{ $displayEvalId }}</div>
                                </div>
                                <div class="col-sm-4 mb-3 mb-sm-0">
                                    <div class="text-uppercase extreme-small fw-bold text-muted mb-1">Assessment Year</div>
                                    <div class="fw-bold text-dark" style="font-size: 1.1rem;">{{ $evaluation->year ?? $evaluation->assessment_year ?? $evaluation->tahun ?? 'N/A' }}</div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="text-uppercase extreme-small fw-bold text-muted mb-1">Organization</div>
                                    <div class="fw-bold text-dark text-truncate" style="font-size: 1.1rem;" title="{{ $organization }}">
                                        {{ $organization }}
                                    </div>
                                </div>
                            </div>
                            <hr class="my-3 opacity-10">
                            <div class="row">
                                <div class="col-12">
                                    <div class="text-uppercase extreme-small fw-bold text-muted mb-1">{{ $areaObjective->area }} Objective</div>
                                    <div class="fw-semibold text-secondary small">
                                        {{ $objective->objective_id }} - {{ $objective->objective }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Toggle View Buttons --}}
    <div class="btn-group mb-4 shadow-sm w-100" role="group" aria-label="View toggle">
        <button type="button" class="btn btn-outline-primary px-4 py-2 active" id="btn-view-practice">
            <i class="fas fa-list me-2"></i>View by Practice
        </button>
        <button type="button" class="btn btn-outline-secondary px-4 py-2" id="btn-view-level">
            <i class="fas fa-layer-group me-2"></i>View by Level
        </button>
    </div>

    {{-- VIEW BY PRACTICE --}}
    <div id="view-practice" class="view-section">
    {{-- Activity Table --}}
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-white py-3">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <h5 class="mb-0 fw-bold text-primary">Filled Activities (by Practice)</h5>
                        <span class="badge bg-secondary" id="activity-count-practice">{{ count($activityData) }} activities</span>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <div class="d-flex align-items-center gap-2">
                                <label for="filter-level-practice" class="form-label mb-0 small fw-bold text-secondary" style="white-space: nowrap;">Filter by Level:</label>
                                <select class="form-select form-select-sm" id="filter-level-practice">
                                    <option value="">All Levels</option>
                                    <option value="2">Level 2</option>
                                    <option value="3">Level 3</option>
                                    <option value="4">Level 4</option>
                                    <option value="5">Level 5</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-center gap-2">
                                <label for="filter-practice" class="form-label mb-0 small fw-bold text-secondary" style="white-space: nowrap;">Filter by Practice:</label>
                                <select class="form-select form-select-sm" id="filter-practice">
                                    <option value="">All Practices</option>
                                    @foreach(($practices ?? []) as $practice)
                                        <option value="{{ $practice['id'] }}">{{ $practice['id'] }} - {{ Str::limit($practice['name'], 30) }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive" style="max-height: 70vh; overflow: auto;">
                <table class="table table-sm table-bordered align-middle mb-0" id="activity-report-table">
                    <thead style="background-color: #e9ecef;">
                        <tr>
                            <th class="text-center" style="min-width: 50px;">NO</th>
                            <th style="min-width: 100px;">PRACTICE</th>
                            <th style="min-width: 180px;">PRACTICE NAME</th>
                            <th style="min-width: 300px;">ACTIVITY</th>
                            <th class="text-center" style="min-width: 90px;">ANSWER</th>
                            <th style="min-width: 250px;">EVIDENCE</th>
                            <th style="min-width: 200px;">NOTES</th>
                            <th class="text-center" style="min-width: 60px;">LEVEL</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(count($practiceRows ?? []) > 0)
                            @foreach(($practiceRows ?? []) as $activity)
                                <tr data-level="{{ $activity['capability_level'] }}" data-practice="{{ $activity['practice_id'] }}" class="activity-row-practice">
                                    @if($activity['show_group'])
                                        <td class="text-center" rowspan="{{ $activity['group_rowspan'] }}">{{ $activity['group_row_number'] }}</td>
                                        <td class="fw-semibold" rowspan="{{ $activity['group_rowspan'] }}">{{ str_replace('"', '', $activity['practice_id']) }}</td>
                                        <td rowspan="{{ $activity['group_rowspan'] }}">{{ str_replace('"', '', $activity['practice_name']) }}</td>
                                    @endif
                                    <td>{{ str_replace('"', '', $activity['activity_description']) }}</td>
                                    <td class="text-center">
                                        <?php
                                            $answer = $activity['answer'];
                                            $badgeClass = match(strtolower($answer)) {
                                                'fully', 'f' => 'bg-success',
                                                'largely', 'l' => 'bg-info',
                                                'partially', 'p' => 'bg-warning text-dark',
                                                'not', 'n' => 'bg-danger',
                                                default => 'bg-secondary'
                                            };
                                        ?>
                                        <span class="badge {{ $badgeClass }}">{{ $answer }}</span>
                                    </td>
                                    <td>
                                        @if(!empty($activity['evidence']) && is_array($activity['evidence']) && count($activity['evidence']) > 0)
                                            <ul class="mb-0 ps-3 small">
                                                @foreach($activity['evidence'] as $ev)
                                                    <li>{{ $ev }}</li>
                                                @endforeach
                                            </ul>
                                        @else
                                            <span class="text-muted small">-</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($activity['notes'])
                                            <span class="small">{{ $activity['notes'] }}</span>
                                        @else
                                            <span class="text-muted small">-</span>
                                        @endif
                                    </td>
                                    <td class="text-center fw-bold">
                                        {{ $activity['capability_level'] ?? '-' }}
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    No filled activities for this criteria.
                                </td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @include('assessment.report.partials.practice-summary')
    </div>

    {{-- VIEW BY LEVEL --}}
    <div id="view-level" class="view-section" style="display: none;">
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-header bg-white py-3">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <h5 class="mb-0 fw-bold text-primary">Filled Activities (by Level)</h5>
                        <span class="badge bg-secondary" id="activity-count-level">{{ count($activityData) }} activities</span>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="row g-2">
                        <div class="col-md-6">
                            <div class="d-flex align-items-center gap-2">
                                <label for="filter-level-level" class="form-label mb-0 small fw-bold text-secondary" style="white-space: nowrap;">Filter by Level:</label>
                                <select class="form-select form-select-sm" id="filter-level-level">
                                    <option value="">All Levels</option>
                                    <option value="2">Level 2</option>
                                    <option value="3">Level 3</option>
                                    <option value="4">Level 4</option>
                                    <option value="5">Level 5</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-flex align-items-center gap-2">
                                <label for="filter-practice-level" class="form-label mb-0 small fw-bold text-secondary" style="white-space: nowrap;">Filter by Practice:</label>
                                <select class="form-select form-select-sm" id="filter-practice-level">
                                    <option value="">All Practices</option>
                                    @foreach(($practices ?? []) as $practice)
                                        <option value="{{ $practice['id'] }}">{{ $practice['id'] }} - {{ Str::limit($practice['name'], 30) }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive" style="max-height: 70vh; overflow: auto;">
                <table class="table table-sm table-bordered align-middle mb-0" id="activity-report-table-level">
                    <thead style="background-color: #e9ecef;">
                        <tr>
                            <th class="text-center" style="min-width: 50px;">NO</th>
                            <th class="text-center" style="min-width: 60px;">LEVEL</th>
                            <th style="min-width: 100px;">PRACTICE</th>
                            <th style="min-width: 180px;">PRACTICE NAME</th>
                            <th style="min-width: 300px;">ACTIVITY</th>
                            <th class="text-center" style="min-width: 90px;">ANSWER</th>
                            <th style="min-width: 250px;">EVIDENCE</th>
                            <th style="min-width: 200px;">NOTES</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(count($levelRows ?? []) > 0)
                            @foreach(($levelRows ?? []) as $activity)
                                @if($activity['show_level_separator'])
                                    <tr class="level-separator-row" data-separator-level="{{ $activity['separator_level'] }}">
                                        <td class="text-center fw-bold" style="background-color: #e9ecef;">LEVEL</td>
                                        <td class="text-center fw-bold" style="background-color: #e9ecef;">{{ $activity['separator_level'] }}</td>
                                        <td class="text-center fw-bold" style="background-color: #e9ecef;">RATING</td>
                                        <td class="text-center fw-bold" style="background-color: #e9ecef;">
                                            {{ $activity['separator_rating_display'] }}
                                        </td>
                                        <td colspan="4" style="background-color: #e9ecef;"></td>
                                    </tr>
                                @endif

                                <tr data-level="{{ $activity['capability_level'] }}" data-practice="{{ $activity['practice_id'] }}" class="activity-row-level">
                                    @if($activity['show_group'])
                                        <td class="text-center" rowspan="{{ $activity['group_rowspan'] }}">{{ $activity['group_row_number'] }}</td>
                                        <td class="text-center fw-bold" rowspan="{{ $activity['group_rowspan'] }}" style="background-color: #f8f9fa;">{{ $activity['capability_level'] ?? '-' }}</td>
                                        <td class="fw-semibold" rowspan="{{ $activity['group_rowspan'] }}">{{ str_replace('"', '', $activity['practice_id']) }}</td>
                                        <td rowspan="{{ $activity['group_rowspan'] }}">{{ str_replace('"', '', $activity['practice_name']) }}</td>
                                    @endif
                                    <td>{{ str_replace('"', '', $activity['activity_description']) }}</td>
                                    <td class="text-center">
                                        <?php
                                            $answer = $activity['answer'];
                                            $badgeClass = match(strtolower($answer)) {
                                                'fully', 'f' => 'bg-success',
                                                'largely', 'l' => 'bg-info',
                                                'partially', 'p' => 'bg-warning text-dark',
                                                'not', 'n' => 'bg-danger',
                                                default => 'bg-secondary'
                                            };
                                        ?>
                                        <span class="badge {{ $badgeClass }}">{{ $answer }}</span>
                                    </td>
                                    <td>
                                        @if(!empty($activity['evidence']) && is_array($activity['evidence']) && count($activity['evidence']) > 0)
                                            <ul class="mb-0 ps-3 small">
                                                @foreach($activity['evidence'] as $ev)
                                                    <li>{{ $ev }}</li>
                                                @endforeach
                                            </ul>
                                        @else
                                            <span class="text-muted small">-</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($activity['notes'])
                                            <span class="small">{{ $activity['notes'] }}</span>
                                        @else
                                            <span class="text-muted small">-</span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    No filled activities for this criteria.
                                </td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // View toggle buttons
        const btnViewPractice = document.getElementById('btn-view-practice');
        const btnViewLevel = document.getElementById('btn-view-level');
        const viewPractice = document.getElementById('view-practice');
        const viewLevel = document.getElementById('view-level');
        
        // Toggle between views
        btnViewPractice.addEventListener('click', function() {
            viewPractice.style.display = 'block';
            viewLevel.style.display = 'none';
            btnViewPractice.classList.add('active');
            btnViewLevel.classList.remove('active');
        });
        
        btnViewLevel.addEventListener('click', function() {
            viewPractice.style.display = 'none';
            viewLevel.style.display = 'block';
            btnViewLevel.classList.add('active');
            btnViewPractice.classList.remove('active');
        });
        
        // Filter for VIEW BY PRACTICE
        const filterLevelPractice = document.getElementById('filter-level-practice');
        const filterPractice = document.getElementById('filter-practice');
        const activityRowsPractice = document.querySelectorAll('.activity-row-practice');
        const activityCountPractice = document.getElementById('activity-count-practice');
        
        function applyFiltersPractice() {
            const selectedLevel = filterLevelPractice.value;
            const selectedPractice = filterPractice.value;
            let visibleCount = 0;
            
            activityRowsPractice.forEach(row => {
                const rowLevel = row.dataset.level;
                const rowPractice = row.dataset.practice;
                
                const levelMatch = !selectedLevel || rowLevel === selectedLevel;
                const practiceMatch = !selectedPractice || rowPractice === selectedPractice;
                
                if (levelMatch && practiceMatch) {
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Update count badge
            if (activityCountPractice) {
                let filterText = [];
                if (selectedLevel) filterText.push(`Level ${selectedLevel}`);
                if (selectedPractice) filterText.push(`Practice ${selectedPractice}`);
                const suffix = filterText.length > 0 ? ` (${filterText.join(', ')})` : '';
                activityCountPractice.textContent = `${visibleCount} activities${suffix}`;
            }
        }
        
        if (filterLevelPractice) {
            filterLevelPractice.addEventListener('change', applyFiltersPractice);
        }
        if (filterPractice) {
            filterPractice.addEventListener('change', applyFiltersPractice);
        }
        
        // Filter for VIEW BY LEVEL
        const filterLevelLevel = document.getElementById('filter-level-level');
        const filterPracticeLevel = document.getElementById('filter-practice-level');
        const activityRowsLevel = document.querySelectorAll('.activity-row-level');
        const levelSeparatorRows = document.querySelectorAll('.level-separator-row');
        const activityCountLevel = document.getElementById('activity-count-level');
        
        function applyFiltersLevel() {
            const selectedLevel = filterLevelLevel.value;
            const selectedPractice = filterPracticeLevel.value;
            let visibleCount = 0;
            const visibleLevels = new Set();
            
            activityRowsLevel.forEach(row => {
                const rowLevel = row.dataset.level;
                const rowPractice = row.dataset.practice;
                
                const levelMatch = !selectedLevel || rowLevel === selectedLevel;
                const practiceMatch = !selectedPractice || rowPractice === selectedPractice;
                
                if (levelMatch && practiceMatch) {
                    row.style.display = '';
                    visibleCount++;
                    visibleLevels.add(rowLevel);
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Show/hide level separators based on visible activities
            levelSeparatorRows.forEach(separator => {
                const separatorLevel = separator.dataset.separatorLevel;
                if (visibleLevels.has(separatorLevel)) {
                    separator.style.display = '';
                } else {
                    separator.style.display = 'none';
                }
            });
            
            // Update count badge
            if (activityCountLevel) {
                let filterText = [];
                if (selectedLevel) filterText.push(`Level ${selectedLevel}`);
                if (selectedPractice) filterText.push(`Practice ${selectedPractice}`);
                const suffix = filterText.length > 0 ? ` (${filterText.join(', ')})` : '';
                activityCountLevel.textContent = `${visibleCount} activities${suffix}`;
            }
        }
        
        if (filterLevelLevel) {
            filterLevelLevel.addEventListener('change', applyFiltersLevel);
        }
        if (filterPracticeLevel) {
            filterPracticeLevel.addEventListener('change', applyFiltersLevel);
        }
        
        // Initialize filters
        applyFiltersPractice();
        applyFiltersLevel();
    });
</script>

<style>
    .extreme-small {
        font-size: 0.65rem;
        letter-spacing: 0.05em;
    }
    #activity-report-table th, #activity-report-table-level th {
        position: sticky;
        top: 0;
        background-color: #e9ecef;
        z-index: 10;
    }
    #activity-report-table td, #activity-report-table th,
    #activity-report-table-level td, #activity-report-table-level th {
        vertical-align: top;
    }
    #activity-report-table td[rowspan], #activity-report-table-level td[rowspan] {
        vertical-align: middle;
        background-color: #f8f9fa;
    }
    .table-responsive {
        -webkit-overflow-scrolling: touch;
    }
    .level-separator-row td {
        font-size: 0.9rem;
        padding: 0.75rem 0.5rem;
    }
    .practice-summary-report {
        border: 1px solid #dee2e6;
        border-radius: 0.9rem;
        overflow: hidden;
        background: #fff;
        box-shadow: 0 10px 24px rgba(15, 43, 92, 0.06);
    }
    .practice-summary-report-header {
        padding: 0.95rem 1.1rem;
        background: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }
    .practice-summary-report-title {
        font-size: 1rem;
        font-weight: 700;
        color: #1f2937;
    }
    .practice-summary-report-body {
        overflow-x: auto;
    }
    .practice-summary-report-table {
        width: 100%;
        border-collapse: collapse;
        margin: 0;
    }
    .practice-summary-report-table th,
    .practice-summary-report-table td {
        border: 1px solid #dee2e6;
        padding: 0.5rem 0.65rem;
        vertical-align: middle;
    }
    .practice-summary-report-table thead th {
        background: #f8f9fa;
        color: #334155;
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }
    .practice-summary-report-table tbody td {
        background: #fff;
        color: #212529;
    }
    .practice-summary-report-table tfoot td {
        background: #f8f9fa;
        font-weight: 600;
        color: #212529;
    }
    .practice-summary-report-table .practice-col {
        width: 36%;
    }
    .practice-summary-report-table .level-col,
    .practice-summary-report-table .total-col {
        width: 10.5%;
    }
    .practice-summary-code {
        font-weight: 700;
        color: #1f2937;
    }
    .practice-summary-name {
        color: #6c757d;
    }
    .practice-summary-metric-row td {
        background: #fff;
    }
    .practice-summary-score-header-row td {
        background: #ffffff;
        font-weight: 700;
        text-align: center;
        color: #1f2937;
    }
    .practice-summary-score-value-row td {
        background: #f8f9fa;
        font-size: 1.05rem;
        font-weight: 700;
        text-align: center;
        color: #212529;
    }
</style>
@endsection
