@extends('design_factor.cobitTools')
@section('cobit-tools-content')
  @include('design_factor.cobitPagination')
  <div class="container">

  {{-- Admin raw submissions (generic) --}}
  {{-- Admin raw submissions removed per request --}}
    <div class="row justify-content-center">
      <div class="col-md-10">
        <div class="card shadow border-0 rounded">
          <!-- Card Header -->
          <div class="card-header bg-primary text-white text-center py-3">
            <h4 class="mb-0">Design Factor 9 - IT Implementation Methods</h4>
          </div>
          <!-- Card Body -->
          <div class="card-body p-4">
            <form action="{{ route('df9.store') }}" method="POST" onsubmit="return validateForm()">
              @csrf
              <input type="hidden" name="df_id" value="{{ $id }}">

              <!-- Tabel Input DF9 -->
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                  <thead class="table-success">
                    <tr>
                      <th scope="col">Value</th>
                      <th scope="col" class="text-center" style="width: 50%;">Importance (100%)</th>
                      <th scope="col" class="text-center">Baseline</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Agile</td>
                      <td>
                        <input type="number" name="input1df9" id="input1df9" class="form-control input-percentage"
                          required>
                        <small class="text-muted">Masukkan nilai dalam persen (contoh: 33 untuk 33%).</small>
                      </td>
                      <td class="text-center fw-bold text-success fs-5">
                        15%
                        <input type="hidden" name="baseline_1df9" value="33">
                      </td>
                    </tr>
                    <tr>
                      <td>DevOps</td>
                      <td>
                        <input type="number" name="input2df9" id="input2df9" class="form-control input-percentage"
                          required>
                        <small class="text-muted">Masukkan nilai dalam persen (contoh: 33 untuk 33%).</small>
                      </td>
                      <td class="text-center fw-bold text-success fs-5">
                        10%
                        <input type="hidden" name="baseline_2df9" value="33">
                      </td>
                    </tr>
                    <tr>
                      <td>Traditional</td>
                      <td>
                        <input type="number" name="input3df9" id="input3df9" class="form-control input-percentage"
                          required>
                        <small class="text-muted">Masukkan nilai dalam persen (contoh: 34 untuk 34%).</small>
                      </td>
                      <td class="text-center fw-bold text-success fs-5">
                        75%
                        <input type="hidden" name="baseline_3df9" value="34">
                      </td>
                    </tr>
                  </tbody>
                </table>
                <!-- Submit Button -->
                <div class="text-end mt-4">
                  <button type="submit" class="btn btn-primary btn-lg px-5">
                    Save
                  </button>
                </div>
              </div>

              <!-- Error Message -->
              <div id="error-message" class="alert alert-danger mt-3" role="alert" style="display: none;">
                The sum of all fields must not exceed 100%.
              </div>

              <!-- Pie Chart -->
              <div class="chart-container mt-4" style="height: 300px;">
                <canvas id="pieChart"></canvas>
              </div>

              <!-- Layout: Relative Importance -->
              <div class="row mt-4">
                <!-- Relative Importance Radar Chart -->
                <div class="col-md-6 mb-3">
                  <div class="card h-100">
                    <div class="card-header text-center text-primary">
                      Relative Importance (Radar Chart)
                    </div>
                    <div class="card-body">
                      <div class="w-100" style="height: 400px;">
                        <canvas id="relativeImportanceRadarChart"></canvas>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Relative Importance Table -->
                <div class="col-md-6 mb-3">
                  <div class="card h-100">
                    <div class="card-header text-center text-primary">
                      Relative Importance Table
                    </div>
                    <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                      <table class="table table-bordered table-sm" id="results-table">
                        <thead class="table-light">
                          <tr>
                            <th class="text-center text-primary">Index</th>
                            <th class="text-center text-primary">DF9 Score</th>
                            <th class="text-center text-primary">Relative Importance</th>
                          </tr>
                        </thead>
                        <tbody>
                          <!-- Data akan diisi oleh JavaScript -->
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Relative Importance Bar Chart -->
              <div class="row mt-4">
                <div class="col-12">
                  <div class="card">
                    <div class="card-header text-center text-primary">
                      Relative Importance (Bar Chart)
                    </div>
                    <div class="card-body">
                      <div class="w-100" style="height: 700px;">
                        <canvas id="relativeImportanceChart"></canvas>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              @include('design_factor.components.df-matrix-table', [
                'id' => 'df9-matrix',
                'dfCode' => 'DF9',
                'columns' => ['Agile', 'DevOps', 'Traditional'],
                'matrix' => \App\Data\Cobit\Df9Data::MAP,
                'note' => 'Matriks DF9 memetakan metode implementasi (Agile/DevOps/Traditional) ke objective COBIT.',
              ])

            </form>
          </div>
          <!-- end card-body -->
        </div>
      </div>
    </div>
  </div>

  <!-- Sertakan Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    // --------------------------- PIE CHART ---------------------------
    // Inisialisasi Pie Chart untuk DF9 dengan default data [33, 33, 34]
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    const pieChart = new Chart(pieCtx, {
      type: 'pie',
      data: {
        labels: ['Agile', 'DevOps', 'Traditional'],
        datasets: [{
          data: [33, 33, 34],
          backgroundColor: [
            'rgba(75, 192, 192, 0.6)',    // Warna untuk Agile
            'rgba(153, 102, 255, 0.6)',     // Warna untuk DevOps
            'rgba(255, 159, 64, 0.6)'       // Warna untuk Traditional
          ],
          borderColor: [
            'rgba(75, 192, 192, 1)',
            'rgba(153, 102, 255, 1)',
            'rgba(255, 159, 64, 1)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } }
      }
    });

    // Fungsi untuk memperbarui data Pie Chart saat input berubah
    function updatePieChart() {
      const input1 = parseFloat(document.getElementById('input1df9').value) || 33;
      const input2 = parseFloat(document.getElementById('input2df9').value) || 33;
      const input3 = parseFloat(document.getElementById('input3df9').value) || 34;
      pieChart.data.datasets[0].data = [input1, input2, input3];
      pieChart.data.datasets[0].backgroundColor = [
        input1 > 0 ? 'rgba(75, 192, 192, 0.6)' : 'rgba(169, 169, 169, 0.6)',
        input2 > 0 ? 'rgba(153, 102, 255, 0.6)' : 'rgba(169, 169, 169, 0.6)',
        input3 > 0 ? 'rgba(255, 159, 64, 0.6)' : 'rgba(169, 169, 169, 0.6)'
      ];
      pieChart.update();
    }

    // Validasi form untuk memastikan total input tidak melebihi 100%
    function validateForm() {
      const input1 = parseFloat(document.getElementById('input1df9').value) || 0;
      const input2 = parseFloat(document.getElementById('input2df9').value) || 0;
      const input3 = parseFloat(document.getElementById('input3df9').value) || 0;
      const total = input1 + input2 + input3;
      if (total > 100) {
        document.getElementById('error-message').style.display = 'block';
        return false;
      }
      document.getElementById('error-message').style.display = 'none';
      return true;
    }

    // Tambahkan event listener untuk setiap input agar update terjadi secara real-time
    document.getElementById('input1df9').addEventListener('input', updateAll);
    document.getElementById('input2df9').addEventListener('input', updateAll);
    document.getElementById('input3df9').addEventListener('input', updateAll);

    // -------------------- KONFIGURASI PERHITUNGAN DF9 --------------------
    // DF9_MAP: Matriks mapping (40x3) untuk perhitungan DF9
    const DF9_MAP = [
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 2.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.5, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.5, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [2.0, 1.5, 1.0],
      [3.5, 2.0, 1.0],
      [4.0, 3.0, 1.0],
      [1.0, 1.0, 1.0],
      [2.5, 1.5, 1.0],
      [3.5, 2.0, 1.0],
      [2.5, 2.5, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.5, 2.0, 1.0],
      [2.5, 1.0, 1.0],
      [1.0, 2.5, 1.0],
      [1.0, 1.5, 1.0],
      [1.0, 1.5, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.5, 1.5, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0],
      [1.0, 1.0, 1.0]
    ];

    // DF9_BASELINE: Nilai baseline input untuk DF9
    const DF9_BASELINE = [
      [15], // 15%
      [10], // 10%
      [75]  // 75%
    ];

    // DF9_SC_BASELINE: Baseline skor untuk masing-masing baris (40x1)
    const DF9_SC_BASELINE = [
      [1.00],
      [1.00],
      [1.00],
      [1.00],
      [1.00],
      [1.00],
      [1.00],
      [1.10],
      [1.00],
      [1.00],
      [1.00],
      [1.05],
      [1.00],
      [1.00],
      [1.00],
      [1.00],
      [1.05],
      [1.00],
      [1.00],
      [1.20],
      [1.48],
      [1.65],
      [1.00],
      [1.28],
      [1.48],
      [1.38],
      [1.00],
      [1.00],
      [1.18],
      [1.23],
      [1.15],
      [1.05],
      [1.05],
      [1.00],
      [1.00],
      [1.00],
      [1.13],
      [1.00],
      [1.00],
      [1.00]
    ];

    // Fungsi pembulatan ke kelipatan tertentu (mirip dengan mround di PHP)
    function mround(value, multiple) {
      if (multiple === 0) return 0;
      return Math.round(value / multiple) * multiple;
    }

    // Fungsi untuk menghitung DF9_SCORE dan DF9_RELATIVE_IMP
    function updateRelativeImportance() {
      const in1 = parseFloat(document.getElementById('input1df9').value) || 15;
      const in2 = parseFloat(document.getElementById('input2df9').value) || 10;
      const in3 = parseFloat(document.getElementById('input3df9').value) || 75;
      // DF9_INPUT sebagai array 2D, sesuai dengan format perhitungan
      const DF9_INPUT = [
        [in1 / 100],
        [in2 / 100],
        [in3 / 100]
      ];

      let DF9_SCORE = [];
      DF9_MAP.forEach((row, i) => {
        let score = 0;
        DF9_INPUT.forEach((input, j) => {
          score += row[j] * input[0];
        });
        DF9_SCORE.push(score);
      });

      let DF9_RELATIVE_IMP = [];
      DF9_SCORE.forEach((score, i) => {
        // Round score to 2 decimal places to match Excel logic
        const roundedScore = Math.round(score * 100) / 100;
        
        if (DF9_SC_BASELINE[i][0] !== 0) {
          let relativeValue = (100 * roundedScore) / DF9_SC_BASELINE[i][0];
          DF9_RELATIVE_IMP.push(mround(relativeValue, 5) - 100);
        } else {
          DF9_RELATIVE_IMP.push(0);
        }
      });
      return { score: DF9_SCORE, relative: DF9_RELATIVE_IMP };
    }

    // Fungsi untuk memperbarui tabel Relative Importance
    function updateRelativeTable(df9Scores, relativeValues) {
      const tableBody = document.querySelector('#results-table tbody');
      tableBody.innerHTML = '';
      relativeValues.forEach((relativeValue, index) => {
        const scoreClass = relativeValue > 0
          ? 'bg-primary-subtle text-dark'
          : relativeValue < 0
            ? 'bg-danger-subtle text-dark'
            : '';
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="text-center">${relativeImportanceLabels[index]}</td>
            <td class="text-center">${df9Scores[index].toFixed(2)}</td>
            <td class="text-center ${scoreClass}">${relativeValue}</td>
          `;
        tableBody.appendChild(row);
      });
    }

    // Label untuk Relative Importance (40 label)
    const relativeImportanceLabels = [
      'EDM01', 'EDM02', 'EDM03', 'EDM04', 'EDM05',
      'APO01', 'APO02', 'APO03', 'APO04', 'APO05',
      'APO06', 'APO07', 'APO08', 'APO09', 'APO10',
      'APO11', 'APO12', 'APO13', 'APO14',
      'BAI01', 'BAI02', 'BAI03', 'BAI04', 'BAI05', 'BAI06', 'BAI07', 'BAI08', 'BAI09', 'BAI10', 'BAI11',
      'DSS01', 'DSS02', 'DSS03', 'DSS04', 'DSS05', 'DSS06',
      'MEA01', 'MEA02', 'MEA03', 'MEA04'
    ];

    // Inisialisasi Bar Chart untuk Relative Importance
    const relBarCtx = document.getElementById('relativeImportanceChart').getContext('2d');
    const relativeBarChart = new Chart(relBarCtx, {
      type: 'bar',
      data: {
        labels: relativeImportanceLabels,
        datasets: [{
          label: 'Relative Importance Score',
          data: [],
          backgroundColor: [],
          borderColor: [],
          borderWidth: 1
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            min: -100,
            max: 100,
            beginAtZero: true,
            ticks: { stepSize: 20 },
            grid: {
              color: ctx => ctx.tick.value === 0 ? 'rgba(0,0,0,0.3)' : 'rgba(200,200,200,0.3)',
              lineWidth: ctx => ctx.tick.value === 0 ? 2 : 1
            }
          },
          y: { ticks: { autoSkip: false, maxTicksLimit: 40 } }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => {
                let lbl = ctx.dataset.label || '';
                if (lbl) lbl += ': ';
                lbl += ctx.raw >= 0 ? '+' + ctx.raw : ctx.raw;
                return lbl;
              }
            }
          }
        }
      }
    });

    // Inisialisasi Radar Chart untuk Relative Importance
    const relRadarCtx = document.getElementById('relativeImportanceRadarChart').getContext('2d');
    const relativeRadarChart = new Chart(relRadarCtx, {
      type: 'radar',
      data: {
        labels: [...relativeImportanceLabels].reverse(),
        datasets: [{
          label: 'Relative Importance',
          data: [],
          backgroundColor: 'rgba(235,54,54,0.2)',
          borderColor: [],
          borderWidth: 2,
          tension: 0.4,
          pointBackgroundColor: [],
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: []
        }]
      },
      options: {
        maintainAspectRatio: false,
        scales: {
          r: {
            suggestedMin: -100,
            suggestedMax: 100,
            ticks: { stepSize: 25 },
            pointLabels: { font: { size: 10 } },
            angleLines: { color: 'rgba(200,200,200,0.3)' },
            grid: { color: 'rgba(200,200,200,0.3)' }
          }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => {
                let lbl = ctx.dataset.label || '';
                if (lbl) lbl += ': ';
                lbl += ctx.raw >= 0 ? '+' + ctx.raw : ctx.raw;
                return lbl;
              }
            }
          }
        }
      }
    });

    // Fungsi update untuk Bar & Radar Chart serta tabel Relative Importance
    function updateRelativeChartsAndTable() {
      updatePieChart();
      const result = updateRelativeImportance();
      updateRelativeTable(result.score, result.relative);

      // Update Bar Chart
      relativeBarChart.data.datasets[0].data = result.relative;
      relativeBarChart.data.datasets[0].backgroundColor = result.relative.map(value =>
        value > 0 ? 'rgba(54, 162, 235, 0.6)' :
          value < 0 ? 'rgba(255, 99, 132, 0.6)' :
            'rgba(201, 201, 201, 0.6)'
      );
      relativeBarChart.data.datasets[0].borderColor = result.relative.map(value =>
        value > 0 ? 'rgba(54, 162, 235, 1)' :
          value < 0 ? 'rgba(255, 99, 132, 1)' :
            'rgba(201, 201, 201, 1)'
      );
      relativeBarChart.update();

      // Update Radar Chart (data dibalik)
      const reversedData = [...result.relative].reverse();
      relativeRadarChart.data.datasets[0].data = reversedData;
      relativeRadarChart.data.datasets[0].borderColor = reversedData.map(value =>
        value < 0 ? 'rgba(255, 99, 132, 1)' : 'rgba(54, 162, 235, 1)'
      );
      relativeRadarChart.data.datasets[0].pointBackgroundColor = reversedData.map(value =>
        value < 0 ? 'rgba(255, 99, 132, 1)' : 'rgba(54, 162, 235, 1)'
      );
      relativeRadarChart.data.datasets[0].pointHoverBorderColor = reversedData.map(value =>
        value < 0 ? 'rgba(255, 99, 132, 1)' : 'rgba(54, 162, 235, 1)'
      );
      relativeRadarChart.update();
    }

    // Fungsi untuk menyinkronkan update seluruh komponen, termasuk pie chart
    function updateAll() {
      updatePieChart(); // Memastikan pie chart juga diupdate
      updateRelativeChartsAndTable();
    }

    // Inisialisasi awal ketika DOM sudah termuat
    document.addEventListener('DOMContentLoaded', function () {
      updateAll();
      // --- Restore server-provided latest inputs (if any) ---
      const serverHistoryInputs = @json($historyInputs ?? null);
      const serverHistoryScoreArray = @json($historyScoreArray ?? null);
      const serverHistoryRIArray = @json($historyRIArray ?? null);
      if (serverHistoryInputs) {
        document.getElementById('input1df9').value = serverHistoryInputs[0] ?? '';
        document.getElementById('input2df9').value = serverHistoryInputs[1] ?? '';
        document.getElementById('input3df9').value = serverHistoryInputs[2] ?? '';
        // trigger update to recompute charts/tables
        updateAll();
      }
      document.querySelectorAll('.input-percentage').forEach(input => {
        input.addEventListener('change', updateAll);
      });
    });

  </script>
@endsection
