<?php

namespace App\Services\Assessment\Access;

use App\Models\AccessAssignment;
use App\Models\MstEval;
use App\Models\TrsScoping;
use App\Models\User;
use App\Services\Auth\AccessProfilePermissionService;
use App\Support\Authorization\PermissionCatalog;
use Illuminate\Support\Collection;
use Illuminate\Database\Eloquent\Builder;

class AssessmentAccessService
{
    public function __construct(
        private readonly AccessProfilePermissionService $accessProfilePermissionService
    ) {
    }

    public function queryAccessible(User $user): Builder
    {
        $query = MstEval::query()->with('organization');

        if ($user->isAdmin()) {
            return $query;
        }

        return $query->where(function (Builder $builder) use ($user) {
            $builder->where('user_id', $user->id)
                ->orWhereHas('accessAssignments', function (Builder $assignmentQuery) use ($user) {
                    $assignmentQuery->where('user_id', $user->id);
                });

            $this->applyOrganizationScope($builder, $user);
        });
    }

    public function canView(User $user, MstEval $evaluation): bool
    {
        if (! $user->can('assessments.view')) {
            return false;
        }

        if ($user->isAdmin() || (string) $evaluation->user_id === (string) $user->id) {
            return true;
        }

        return $this->assignmentFor($user, $evaluation) !== null
            || $this->belongsToUserOrganizations($user, $evaluation);
    }

    public function canManage(User $user, MstEval $evaluation): bool
    {
        if (! $user->can('assessments.input')) {
            return false;
        }

        if ($user->isAdmin() || (string) $evaluation->user_id === (string) $user->id) {
            return true;
        }

        $assignment = $this->assignmentFor($user, $evaluation);

        if ($assignment && $this->accessProfilePermissionService->profileHasPermission($assignment->access_profile, PermissionCatalog::AssessmentsInput)) {
            return true;
        }

        return $this->belongsToUserOrganizations($user, $evaluation);
    }

    public function findManagedScope(int $scopeId, User $user): ?TrsScoping
    {
        $scope = TrsScoping::with('evaluation.user')->find($scopeId);

        if (! $scope || ! $scope->evaluation) {
            return null;
        }

        return $this->canManage($user, $scope->evaluation) ? $scope : null;
    }

    public function assign(User $user, MstEval $evaluation, ?User $assignedBy = null): AccessAssignment
    {
        $profile = $user->accessProfileEnum() ?? \App\Enums\UserAccessProfile::Viewer;

        return $evaluation->accessAssignments()->updateOrCreate(
            ['user_id' => $user->id],
            [
                'access_profile' => $profile->value,
                'assigned_by' => $assignedBy?->id,
            ]
        );
    }

    private function assignmentFor(User $user, MstEval $evaluation): ?AccessAssignment
    {
        return $evaluation->accessAssignments()
            ->where('user_id', $user->id)
            ->first();
    }

    private function applyOrganizationScope(Builder $query, User $user): void
    {
        $organizationIds = $user->organizationIds();

        if ($organizationIds === []) {
            return;
        }

        $query->orWhere(function (Builder $scopeQuery) use ($organizationIds) {
            // Evaluasi milik organisasi user
            $scopeQuery->whereIn('organization_id', $organizationIds)
                ->orWhere(function (Builder $fallbackQuery) use ($organizationIds) {
                    // Fallback: Jika evaluasi tidak punya organization_id spesifik, cek organisasi pembuatnya
                    $fallbackQuery->whereNull('organization_id')
                        ->whereHas('user', function (Builder $ownerQuery) use ($organizationIds) {
                            $ownerQuery->whereIn('organization_id', $organizationIds)
                                ->orWhereHas('organizations', fn (Builder $organizationQuery) => $organizationQuery->whereIn('mst_organization.organization_id', $organizationIds));
                        });
                });
        });
    }

    private function belongsToUserOrganizations(User $user, MstEval $evaluation): bool
    {
        if ($user->hasOrganizationId((int) $evaluation->organization_id)) {
            return true;
        }

        $organizationIds = $this->resolveEvaluationOrganizationIds($evaluation);

        foreach ($organizationIds as $organizationId) {
            if ($user->hasOrganizationId($organizationId)) {
                return true;
            }
        }

        $organizationNames = $this->resolveEvaluationOrganizationNames($evaluation);

        foreach ($organizationNames as $organizationName) {
            if ($user->hasOrganizationAccess($organizationName)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return list<int>
     */
    private function resolveEvaluationOrganizationIds(MstEval $evaluation): array
    {
        $organizationIds = collect();

        if ($evaluation->organization_id) {
            $organizationIds->push((int) $evaluation->organization_id);
            
            // Jika evaluation sudah memiliki organization_id yang jelas, 
            // jangan tambahkan semua organisasi milik pembuatnya (mencegah kebocoran akses lintas organisasi).
            return $organizationIds->unique()->values()->all();
        }

        $owner = $evaluation->relationLoaded('user')
            ? $evaluation->user
            : $evaluation->user()->with('organizations')->first();

        if ($owner) {
            $organizationIds = $organizationIds
                ->merge($owner->organizationIds())
                ->when($owner->rawOrganizationId(), fn (Collection $ids, int $organizationId) => $ids->push($organizationId));
        }

        return $organizationIds
            ->map(fn ($organizationId) => (int) $organizationId)
            ->filter(fn (int $organizationId): bool => $organizationId > 0)
            ->unique()
            ->values()
            ->all();
    }

    /**
     * @return list<string>
     */
    private function resolveEvaluationOrganizationNames(MstEval $evaluation): array
    {
        $organizationNames = collect();

        $organizationName = $evaluation->relationLoaded('organization')
            ? $evaluation->organization?->organization_name
            : $evaluation->organization()->value('organization_name');

        if (filled($organizationName)) {
            $organizationNames->push((string) $organizationName);
        }
        
        if ($evaluation->organization_id) {
            // Jika sudah ada organization_id spesifik, jangan meluaskan ke instansi milik pembuat
            return $organizationNames->unique()->values()->all();
        }

        $owner = $evaluation->relationLoaded('user')
            ? $evaluation->user
            : $evaluation->user()->with('organizations')->first();

        if ($owner) {
            $organizationNames = $organizationNames
                ->merge($owner->organizationNames())
                ->when($owner->rawOrganizationName(), fn (Collection $names, string $name) => $names->push($name));
        }

        return $organizationNames
            ->filter(fn ($organizationName): bool => filled($organizationName))
            ->map(fn ($organizationName): string => (string) $organizationName)
            ->unique()
            ->values()
            ->all();
    }
}
