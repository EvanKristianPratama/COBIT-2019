<?php

namespace App\Services\Assessment\Evidence;

use App\Models\MstEval;
use App\Models\MstEvidence;
use App\Models\MstOrganization;
use App\Models\TrsActivityeval;
use App\Models\User;

class AssessmentEvidenceService
{
    public function getEvidences(MstEval $evaluation)
    {
        return MstEvidence::where('eval_id', $evaluation->eval_id)
            ->orderBy('created_at', 'desc')
            ->get();
    }

    /**
     * @param  array<string, mixed>  $filters
     * @return array<string, mixed>
     */
    public function getPreviousEvidences(MstEval $evaluation, array $filters): array
    {
        $organizationId = $evaluation->organization_id
            ?? User::where('id', $evaluation->user_id)->value('organization_id');

        $userIds = User::query()
            ->when($organizationId, function ($query) use ($organizationId) {
                $query->whereHas('organizations', function ($organizationQuery) use ($organizationId) {
                    $organizationQuery->where('mst_organization.organization_id', $organizationId);
                });
            })
            ->orWhere('id', $evaluation->user_id)
            ->pluck('id');

        $evalIds = MstEval::whereIn('user_id', $userIds)
            ->where('eval_id', '!=', $evaluation->eval_id)
            ->pluck('eval_id');

        if ($evalIds->isEmpty()) {
            return [
                'data' => [],
                'pagination' => [
                    'total' => 0,
                    'per_page' => 20,
                    'current_page' => 1,
                    'last_page' => 1,
                ],
            ];
        }

        $page = max(1, (int) ($filters['page'] ?? 1));
        $perPage = max(5, min(100, (int) ($filters['per_page'] ?? 20)));
        $search = (string) ($filters['search'] ?? '');
        $columnFilters = is_array($filters['filters'] ?? null) ? $filters['filters'] : [];

        $query = MstEvidence::whereIn('eval_id', $evalIds)
            ->with(['evaluation' => function ($query) {
                $query->select('eval_id', 'tahun');
            }]);

        if ($search !== '') {
            $query->where(function ($builder) use ($search) {
                $builder->where('judul_dokumen', 'like', "%{$search}%")
                    ->orWhere('no_dokumen', 'like', "%{$search}%")
                    ->orWhere('pemilik_dokumen', 'like', "%{$search}%")
                    ->orWhere('grup', 'like', "%{$search}%");
            });
        }

        $allowedFields = [
            'judul_dokumen', 'no_dokumen', 'grup', 'tipe',
            'tahun_terbit', 'tahun_kadaluarsa', 'pemilik_dokumen',
            'pengesahan', 'klasifikasi', 'summary', 'ket_tipe',
        ];

        foreach ($columnFilters as $field => $value) {
            if ($value === null || $value === '' || ! in_array($field, $allowedFields, true)) {
                continue;
            }

            $query->where($field, 'like', '%'.$value.'%');
        }

        $total = $query->count();
        $lastPage = max(1, (int) ceil($total / $perPage));
        $page = min($page, $lastPage);

        $evidences = $query->orderByDesc('created_at')
            ->skip(($page - 1) * $perPage)
            ->take($perPage)
            ->get([
                'id', 'eval_id', 'judul_dokumen', 'no_dokumen', 'grup', 'tipe',
                'tahun_terbit', 'tahun_kadaluarsa', 'pemilik_dokumen', 'pengesahan',
                'klasifikasi', 'summary', 'link', 'ket_tipe', 'created_at',
            ]);

        return [
            'data' => $evidences->map(function (MstEvidence $evidence) {
                return [
                    'id' => $evidence->id,
                    'eval_id' => $evidence->eval_id,
                    'judul_dokumen' => $evidence->judul_dokumen,
                    'no_dokumen' => $evidence->no_dokumen,
                    'grup' => $evidence->grup,
                    'tipe' => $evidence->tipe,
                    'tahun_terbit' => $evidence->tahun_terbit,
                    'tahun_kadaluarsa' => $evidence->tahun_kadaluarsa,
                    'pemilik_dokumen' => $evidence->pemilik_dokumen,
                    'pengesahan' => $evidence->pengesahan,
                    'klasifikasi' => $evidence->klasifikasi,
                    'summary' => $evidence->summary,
                    'link' => $evidence->link,
                    'ket_tipe' => $evidence->ket_tipe,
                    'created_at' => $evidence->created_at,
                    'assessment_year' => optional($evidence->evaluation)->tahun,
                ];
            }),
            'pagination' => [
                'total' => $total,
                'per_page' => $perPage,
                'current_page' => $page,
                'last_page' => $lastPage,
            ],
        ];
    }

    /**
     * @param  array<string, mixed>  $validated
     */
    public function store(MstEval $evaluation, array $validated): MstEvidence
    {
        return MstEvidence::create([
            'eval_id' => $evaluation->eval_id,
            ...$validated,
        ]);
    }

    /**
     * @param  array<string, mixed>  $validated
     */
    public function storeForOrganization(MstOrganization $organization, array $validated): MstEvidence
    {
        return MstEvidence::create([
            'eval_id' => null,
            'organization_id' => $organization->organization_id,
            ...$validated,
        ]);
    }

    /**
     * @param  array<string, mixed>  $validated
     */
    public function update(MstEvidence $evidence, array $validated): MstEvidence
    {
        $oldTitle = $evidence->judul_dokumen;
        $evidence->update($validated);

        // When judul_dokumen changes, sync the text stored in trs_activityeval.evidence
        // so the assessment view reflects the updated evidence name.
        $newTitle = $evidence->judul_dokumen;
        if ($oldTitle !== null && $newTitle !== null && $oldTitle !== $newTitle) {
            if ($evidence->eval_id) {
                // Evidence belongs to a specific assessment: sync that assessment only
                $this->syncActivityEvalEvidence([$evidence->eval_id], $oldTitle, $newTitle);
            } elseif ($evidence->organization_id) {
                // Master evidence (org-level): sync all assessments in the organization
                $evalIds = \App\Models\MstEval::where('organization_id', $evidence->organization_id)
                    ->pluck('eval_id')
                    ->all();

                if ($evalIds !== []) {
                    $this->syncActivityEvalEvidence($evalIds, $oldTitle, $newTitle);
                }
            }
        }

        return $evidence->fresh();
    }

    /**
     * When an evidence document title is renamed, update every trs_activityeval row
     * that references the old name (stored as newline-separated plain text).
     *
     * @param  array<int, string|int>  $evalIds
     */
    private function syncActivityEvalEvidence(array $evalIds, string $oldTitle, string $newTitle): void
    {
        $activityEvals = TrsActivityeval::whereIn('eval_id', $evalIds)
            ->whereNotNull('evidence')
            ->where('evidence', 'like', '%' . addcslashes($oldTitle, '%_\\') . '%')
            ->get();

        foreach ($activityEvals as $activityEval) {
            $lines = preg_split('/\r\n|\r|\n/', $activityEval->evidence);
            $updated = false;

            foreach ($lines as &$line) {
                if (mb_strtolower(trim($line)) === mb_strtolower(trim($oldTitle))) {
                    $line = $newTitle;
                    $updated = true;
                }
            }
            unset($line);

            if ($updated) {
                $activityEval->evidence = implode("\n", $lines);
                $activityEval->save();
            }
        }
    }
}
