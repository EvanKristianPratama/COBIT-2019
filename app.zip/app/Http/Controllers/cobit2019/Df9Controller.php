<?php

declare(strict_types=1);

namespace App\Http\Controllers\cobit2019;

use App\Data\Cobit\Df9Data;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Cobit\Df9Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * DF9 Controller - Technology Adoption Strategy
 */
class Df9Controller extends Controller
{
    public function __construct(
        private readonly Df9Service $service
    ) {}

    public function showDesignFactor9Form(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $userIds = session('respondent_ids', []);
        $users = $this->loadUsers($userIds);

        return view('design_factor.df9.design_factor9', [
            'id' => $id,
            'historyInputs' => $history['inputs'],
            'historyScoreArray' => $history['scores'],
            'historyRIArray' => $history['relativeImportance'],
            'userIds' => $userIds,
            'users' => $users,
            'aggregatedData' => [],
            'suggestedValues' => [],
            'allSubmissions' => collect(),
        ]);
    }

    public function store(Request $request): JsonResponse|RedirectResponse
    {
        $validated = $request->validate([
            'df_id' => 'required|integer',
            'input1df9' => 'required|integer|min:0|max:100',
            'input2df9' => 'required|integer|min:0|max:100',
            'input3df9' => 'required|integer|min:0|max:100',
        ]);

        $assessmentId = session('assessment_id');
        if (!$assessmentId) {
            return $this->errorResponse($request, 'Assessment ID tidak ditemukan, silahkan join assessment terlebih dahulu.');
        }

        try {
            $result = $this->service->store((int) $validated['df_id'], (int) $assessmentId, $validated);

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'historyInputs' => $result['inputs'],
                    'historyScoreArray' => $result['scores'],
                    'historyRIArray' => $result['relativeImportance'],
                ]);
            }

            return redirect()->route('df9.output', ['id' => $validated['df_id']])->with('success', 'Data berhasil disimpan!');
        } catch (\Exception $e) {
            return $this->errorResponse($request, $e->getMessage());
        }
    }

    public function showOutput(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $designFactor9Data = [
            'df_id' => $id,
            'input1df9' => (int) ($history['inputs'][0] ?? 0),
            'input2df9' => (int) ($history['inputs'][1] ?? 0),
            'input3df9' => (int) ($history['inputs'][2] ?? 0),
        ];
        for ($i = 1; $i <= Df9Data::OBJECTIVE_COUNT; $i++) {
            $designFactor9Data['s_df9_' . $i] = (float) ($history['scores'][$i - 1] ?? 0);
        }
        $designFactor9 = (object) $designFactor9Data;

        $designFactorRelativeImportanceData = [];
        for ($i = 1; $i <= Df9Data::OBJECTIVE_COUNT; $i++) {
            $designFactorRelativeImportanceData['r_df9_' . $i] = (float) ($history['relativeImportance'][$i - 1] ?? 0);
        }
        $designFactorRelativeImportance = (object) $designFactorRelativeImportanceData;

        return view('design_factor.df9.df9_output', compact('designFactor9', 'designFactorRelativeImportance'));
    }

    private function loadUsers(array $userIds): array
    {
        if (empty($userIds)) return [];
        try {
            return User::whereIn('id', $userIds)->pluck('name', 'id')->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function errorResponse(Request $request, string $message): JsonResponse|RedirectResponse
    {
        if ($request->ajax() || $request->wantsJson()) {
            return response()->json(['success' => false, 'message' => $message], 500);
        }
        return redirect()->back()->with('error', $message);
    }
}
