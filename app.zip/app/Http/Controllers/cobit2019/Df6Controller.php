<?php

declare(strict_types=1);

namespace App\Http\Controllers\cobit2019;

use App\Data\Cobit\Df6Data;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Cobit\Df6Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * DF6 Controller - Adoption of Cloud Computing
 */
class Df6Controller extends Controller
{
    public function __construct(
        private readonly Df6Service $service
    ) {}

    public function showDesignFactor6Form(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $userIds = session('respondent_ids', []);
        $users = $this->loadUsers($userIds);

        return view('design_factor.df6.design_factor6', [
            'id' => $id,
            'historyInputs' => $history['inputs'],
            'historyScoreArray' => $history['scores'],
            'historyRIArray' => $history['relativeImportance'],
            'userIds' => $userIds,
            'users' => $users,
            'aggregatedData' => [],
            'suggestedValues' => [],
            'allSubmissions' => collect(),
        ]);
    }

    public function store(Request $request): JsonResponse|RedirectResponse
    {
        $validated = $request->validate([
            'df_id' => 'required|integer',
            'input1df6' => 'required|integer|min:0|max:100',
            'input2df6' => 'required|integer|min:0|max:100',
            'input3df6' => 'required|integer|min:0|max:100',
        ]);

        $assessmentId = session('assessment_id');
        if (!$assessmentId) {
            return $this->errorResponse($request, 'Assessment ID tidak ditemukan, silahkan join assessment terlebih dahulu.');
        }

        try {
            $result = $this->service->store((int) $validated['df_id'], (int) $assessmentId, $validated);

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'historyInputs' => $result['inputs'],
                    'historyScoreArray' => $result['scores'],
                    'historyRIArray' => $result['relativeImportance'],
                ]);
            }

            return redirect()->route('df6.output', ['id' => $validated['df_id']])->with('success', 'Data berhasil disimpan!');
        } catch (\Exception $e) {
            return $this->errorResponse($request, $e->getMessage());
        }
    }

    public function showOutput(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $designFactor6Data = [
            'df_id' => $id,
            'input1df6' => (int) ($history['inputs'][0] ?? 0),
            'input2df6' => (int) ($history['inputs'][1] ?? 0),
            'input3df6' => (int) ($history['inputs'][2] ?? 0),
        ];
        for ($i = 1; $i <= Df6Data::OBJECTIVE_COUNT; $i++) {
            $designFactor6Data['s_df6_' . $i] = (float) ($history['scores'][$i - 1] ?? 0);
        }
        $designFactor6 = (object) $designFactor6Data;

        $designFactorRelativeImportanceData = [];
        for ($i = 1; $i <= Df6Data::OBJECTIVE_COUNT; $i++) {
            $designFactorRelativeImportanceData['r_df6_' . $i] = (float) ($history['relativeImportance'][$i - 1] ?? 0);
        }
        $designFactorRelativeImportance = (object) $designFactorRelativeImportanceData;

        return view('design_factor.df6.df6_output', compact('designFactor6', 'designFactorRelativeImportance'));
    }

    private function loadUsers(array $userIds): array
    {
        if (empty($userIds)) return [];
        try {
            return User::whereIn('id', $userIds)->pluck('name', 'id')->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function errorResponse(Request $request, string $message): JsonResponse|RedirectResponse
    {
        if ($request->ajax() || $request->wantsJson()) {
            return response()->json(['success' => false, 'message' => $message], 500);
        }
        return redirect()->back()->with('error', $message);
    }
}
