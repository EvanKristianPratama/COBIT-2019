<?php

declare(strict_types=1);

namespace App\Http\Controllers\cobit2019;

use App\Data\Cobit\Df7Data;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Cobit\Df7Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * DF7 Controller - IT Sourcing Model
 */
class Df7Controller extends Controller
{
    public function __construct(
        private readonly Df7Service $service
    ) {}

    public function showDesignFactor7Form(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $userIds = session('respondent_ids', []);
        $users = $this->loadUsers($userIds);

        return view('design_factor.df7.design_factor7', [
            'id' => $id,
            'historyInputs' => $history['inputs'],
            'historyScoreArray' => $history['scores'],
            'historyRIArray' => $history['relativeImportance'],
            'userIds' => $userIds,
            'users' => $users,
            'aggregatedData' => [],
            'suggestedValues' => [],
            'allSubmissions' => collect(),
        ]);
    }

    public function store(Request $request): JsonResponse|RedirectResponse
    {
        $validated = $request->validate([
            'df_id' => 'required|integer',
            'input1df7' => 'required|integer',
            'input2df7' => 'required|integer',
            'input3df7' => 'required|integer',
            'input4df7' => 'required|integer',
        ]);

        $assessmentId = session('assessment_id');
        if (!$assessmentId) {
            return $this->errorResponse($request, 'Assessment ID tidak ditemukan, silahkan join assessment terlebih dahulu.');
        }

        try {
            $result = $this->service->store((int) $validated['df_id'], (int) $assessmentId, $validated);

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'historyInputs' => $result['inputs'],
                    'historyScoreArray' => $result['scores'],
                    'historyRIArray' => $result['relativeImportance'],
                ]);
            }

            return redirect()->route('df7.output', ['id' => $validated['df_id']])->with('success', 'Data berhasil disimpan!');
        } catch (\Exception $e) {
            return $this->errorResponse($request, $e->getMessage());
        }
    }

    public function showOutput(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $designFactor7Data = [
            'df_id' => $id,
            'input1df7' => (int) ($history['inputs'][0] ?? 0),
            'input2df7' => (int) ($history['inputs'][1] ?? 0),
            'input3df7' => (int) ($history['inputs'][2] ?? 0),
            'input4df7' => (int) ($history['inputs'][3] ?? 0),
        ];
        for ($i = 1; $i <= Df7Data::OBJECTIVE_COUNT; $i++) {
            $designFactor7Data['s_df7_' . $i] = (float) ($history['scores'][$i - 1] ?? 0);
        }
        $designFactor7 = (object) $designFactor7Data;

        $designFactorRelativeImportanceData = [];
        for ($i = 1; $i <= Df7Data::OBJECTIVE_COUNT; $i++) {
            $designFactorRelativeImportanceData['r_df7_' . $i] = (float) ($history['relativeImportance'][$i - 1] ?? 0);
        }
        $designFactorRelativeImportance = (object) $designFactorRelativeImportanceData;

        return view('design_factor.df7.df7_output', compact('designFactor7', 'designFactorRelativeImportance'));
    }

    private function loadUsers(array $userIds): array
    {
        if (empty($userIds)) return [];
        try {
            return User::whereIn('id', $userIds)->pluck('name', 'id')->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function errorResponse(Request $request, string $message): JsonResponse|RedirectResponse
    {
        if ($request->ajax() || $request->wantsJson()) {
            return response()->json(['success' => false, 'message' => $message], 500);
        }
        return redirect()->back()->with('error', $message);
    }
}
