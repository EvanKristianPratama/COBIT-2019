<?php

declare(strict_types=1);

namespace App\Http\Controllers\cobit2019;

use App\Data\Cobit\Df5Data;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Cobit\Df5Service;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * DF5 Controller - IT Investment Portfolio
 */
class Df5Controller extends Controller
{
    public function __construct(
        private readonly Df5Service $service
    ) {}

    public function showDesignFactor5Form(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $userIds = session('respondent_ids', []);
        $users = $this->loadUsers($userIds);

        return view('design_factor.df5.design_factor5', [
            'id' => $id,
            'historyInputs' => $history['inputs'],
            'historyScoreArray' => $history['scores'],
            'historyRIArray' => $history['relativeImportance'],
            'userIds' => $userIds,
            'users' => $users,
            'aggregatedData' => [],
            'suggestedValues' => [],
            'allSubmissions' => collect(),
        ]);
    }

    public function store(Request $request): JsonResponse|RedirectResponse
    {
        $validated = $request->validate([
            'df_id' => 'required|integer',
            'input1df5' => 'required|integer|min:0|max:100',
            'input2df5' => 'required|integer|min:0|max:100',
        ]);

        $assessmentId = session('assessment_id');
        if (!$assessmentId) {
            return $this->errorResponse($request, 'Assessment ID tidak ditemukan, silahkan join assessment terlebih dahulu.');
        }

        try {
            $result = $this->service->store((int) $validated['df_id'], (int) $assessmentId, $validated);

            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'historyInputs' => $result['inputs'],
                    'historyScoreArray' => $result['scores'],
                    'historyRIArray' => $result['relativeImportance'],
                ]);
            }

            return redirect()->route('df5.output', ['id' => $validated['df_id']])->with('success', 'Data berhasil disimpan!');
        } catch (\Exception $e) {
            return $this->errorResponse($request, $e->getMessage());
        }
    }

    public function showOutput(int $id): View
    {
        $assessmentId = session('assessment_id');
        $history = $assessmentId
            ? $this->service->loadHistory($assessmentId)
            : ['inputs' => null, 'scores' => null, 'relativeImportance' => null];

        $designFactor5Data = [
            'df_id' => $id,
            'input1df5' => (int) ($history['inputs'][0] ?? 0),
            'input2df5' => (int) ($history['inputs'][1] ?? 0),
        ];
        for ($i = 1; $i <= Df5Data::OBJECTIVE_COUNT; $i++) {
            $designFactor5Data['s_df5_' . $i] = (float) ($history['scores'][$i - 1] ?? 0);
        }
        $designFactor5 = (object) $designFactor5Data;

        $designFactorRelativeImportanceData = [];
        for ($i = 1; $i <= Df5Data::OBJECTIVE_COUNT; $i++) {
            $designFactorRelativeImportanceData['r_df5_' . $i] = (float) ($history['relativeImportance'][$i - 1] ?? 0);
        }
        $designFactorRelativeImportance = (object) $designFactorRelativeImportanceData;

        return view('design_factor.df5.df5_output', compact('designFactor5', 'designFactorRelativeImportance'));
    }

    private function loadUsers(array $userIds): array
    {
        if (empty($userIds)) return [];
        try {
            return User::whereIn('id', $userIds)->pluck('name', 'id')->toArray();
        } catch (\Throwable $e) {
            return [];
        }
    }

    private function errorResponse(Request $request, string $message): JsonResponse|RedirectResponse
    {
        if ($request->ajax() || $request->wantsJson()) {
            return response()->json(['success' => false, 'message' => $message], 500);
        }
        return redirect()->back()->with('error', $message);
    }
}
