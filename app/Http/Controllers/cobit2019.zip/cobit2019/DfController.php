<?php

# Struktur lokasi si folder ini
namespace App\Http\Controllers\cobit2019;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\DesignFactor1;
use App\Models\DesignFactor1Score;
use Illuminate\Support\Facades\DB;
use App\Models\DesignFactor1RelativeImportance;


class DfController extends Controller
{
    // Method untuk menampilkan form Design Factor
    public function showDesignFactorForm($id)
{
    $assessment_id = session('assessment_id');

    $history = null;
    $historyInputs = null;
    $historyScoreArray = null;
    $historyRIArray = null;

    // defaults untuk admin view
    $allSubmissions = collect();
    $users = [];
    $userIds = session('respondent_ids', []);

    if ($assessment_id) {
        // history user saat ini (latest)
        $history = \App\Models\DesignFactor1::where('assessment_id', $assessment_id)
            ->where('df_id', $id)
            ->where('id', Auth::id())
            ->latest()
            ->first();

        if ($history) {
            $historyInputs = [
                (int) ($history->input1df1 ?? 0),
                (int) ($history->input2df1 ?? 0),
                (int) ($history->input3df1 ?? 0),
                (int) ($history->input4df1 ?? 0),
            ];
        }

        // last saved score untuk user ini
        $historyScore = \App\Models\DesignFactor1Score::where('assessment_id', $assessment_id)
            ->where('df1_id', $id)
            ->where('id', Auth::id())
            ->latest()
            ->first();

        if ($historyScore) {
            $historyScoreArray = [];
            for ($i = 1; $i <= 40; $i++) {
                $col = 's_df1_' . $i;
                $historyScoreArray[] = (float) ($historyScore->{$col} ?? 0);
            }
        }

        // last saved relative importance untuk user ini
        $historyRI = \App\Models\DesignFactor1RelativeImportance::where('assessment_id', $assessment_id)
            ->where('df1_id', $id)
            ->where('id', Auth::id())
            ->latest()
            ->first();

        if ($historyRI) {
            $historyRIArray = [];
            for ($i = 1; $i <= 40; $i++) {
                $col = 'r_df1_' . $i;
                $historyRIArray[] = (float) ($historyRI->{$col} ?? 0);
            }
        }

        // jika admin/pic: sediakan raw submissions latest-per-user (exclude admin accounts)
        $currentRole = strtolower(trim((string) (Auth::user()->role ?? '')));
        if (in_array($currentRole, ['admin', 'administrator', 'pic'], true)) {
            $subs = \App\Models\DesignFactor1::where('assessment_id', $assessment_id)
                ->where('df_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();
      

            // deteksi kolom yang menyimpan submitter id (default: 'id')
            $userKey = 'id';
            if ($subs->isNotEmpty()) {
                $firstAttrs = $subs->first()->getAttributes();
                if (array_key_exists('user_id', $firstAttrs)) $userKey = 'user_id';
                elseif (array_key_exists('id_user', $firstAttrs)) $userKey = 'id_user';
                elseif (array_key_exists('respondent_id', $firstAttrs)) $userKey = 'respondent_id';
            }

            // semua yang submit ke DF ini
            $submitterIds = $subs->pluck($userKey)->filter()->map(fn($v) => (int) $v)->unique()->values()->toArray();

            // jika session menyediakan respondent_ids, gunakan irisan supaya hanya tampil yang relevan
            $sessionRespondentIds = session('respondent_ids', []);
            $uids = !empty($sessionRespondentIds) ? array_values(array_intersect($submitterIds, $sessionRespondentIds)) : $submitterIds;

            // exclude admin accounts dari listing (opsional, case-insensitive)
            if (!empty($uids)) {
                try {
                    $usersForUids = \App\Models\User::whereIn('id', $uids)->get(['id', 'role']);
                    $excludeAdminIds = $usersForUids->filter(function($u) {
                        return in_array(strtolower(trim((string)$u->role)), ['admin', 'administrator']);
                    })->pluck('id')->map(fn($v) => (int) $v)->toArray();

                    if (!empty($excludeAdminIds)) {
                        $uids = array_values(array_filter($uids, function($id) use ($excludeAdminIds) {
                            return ! in_array($id, $excludeAdminIds, true);
                        }));
                    }
                } catch (\Throwable $e) {
                    // ignore and continue with original uids
                }
            }

            // build users map (id => name) jika ada uid

            if (!empty($uids)) {
                $users = \App\Models\User::whereIn('id', $uids)->pluck('name', 'id')->toArray();
                $email = \App\Models\User::whereIn('id', $uids)->pluck('email', 'id')->toArray();
                $jabatan = \App\Models\User::whereIn('id', $uids)->pluck('jabatan', 'id')->toArray();
                // filter subs hanya untuk uids dan ambil latest-per-user
                $subs = $subs->filter(function($r) use ($userKey, $uids) {
                    return in_array((int) ($r->{$userKey} ?? 0), $uids, true);
                })->unique($userKey)->values();
            } else {
                $email = [];
            }

            $allSubmissions = $subs;
            $userIds = $uids;
        }
    }

    return view('cobit2019.df1.design_factor', compact(
        'id',
        'history',
        'historyInputs',
        'historyScoreArray',
        'historyRIArray',
        'allSubmissions',
        'users',
        'email',
        'jabatan',
        'userIds'
    ));
}


    // Method untuk menyimpan data dari form
    public function store(Request $request)
    {
        // Validasi input dari form
        $validated = $request->validate([
            'df_id' => 'required|integer',
            'strategy_archetype' => 'required|integer',
            'current_performance' => 'required|integer',
            'future_goals' => 'required|integer',
            'alignment_with_it' => 'required|integer',
        ]);



        $assessment_id = session('assessment_id');
        if (!$assessment_id) {
            return redirect()->back()->with('error', 'Assessment ID tidak ditemukan, silahkan join assessment terlebih dahulu.');
        }




        try {
            DB::beginTransaction();

            $designFactor = DesignFactor1::create([
                'id' => Auth::id(), // Ambil ID user yang sedang login
                'df_id' => $validated['df_id'],
                'assessment_id' => $assessment_id, // simpan assessment_id di sini
                'input1df1' => $validated['strategy_archetype'],
                'input2df1' => $validated['current_performance'],
                'input3df1' => $validated['future_goals'],
                'input4df1' => $validated['alignment_with_it'],
            ]);

            //==========================================================================
            // Matriks tetap (DF1map) dengan dimensi (40, 4)
            $DF1map = [
                [1.0, 1.0, 1.5, 1.5],
                [1.5, 1.0, 2.0, 3.5],
                [1.0, 1.0, 1.0, 2.0],
                [1.5, 1.0, 4.0, 1.0],
                [1.5, 1.5, 1.0, 2.0],
                [1.0, 1.0, 1.0, 1.0],
                [3.5, 3.5, 1.5, 1.0],
                [4.0, 2.0, 1.0, 1.0],
                [1.0, 4.0, 1.0, 1.0],
                [3.5, 4.0, 2.5, 1.0],
                [1.5, 1.0, 4.0, 1.0],
                [2.0, 1.0, 1.0, 1.0],
                [1.0, 1.5, 1.0, 3.5],
                [1.0, 1.0, 1.5, 4.0],
                [1.0, 1.0, 3.5, 1.5],
                [1.0, 1.0, 1.0, 4.0],
                [1.0, 1.5, 1.0, 2.5],
                [1.0, 1.0, 1.0, 2.5],
                [1.0, 1.0, 1.0, 1.0],
                [4.0, 2.0, 1.5, 1.5],
                [1.0, 1.0, 1.5, 1.0],
                [1.0, 1.0, 1.5, 1.0],
                [1.0, 1.0, 1.0, 3.0],
                [4.0, 2.0, 1.0, 1.5],
                [2.0, 2.0, 1.0, 1.5],
                [1.5, 2.0, 1.0, 1.5],
                [1.0, 3.5, 1.0, 1.0],
                [1.0, 1.0, 1.0, 1.0],
                [1.0, 1.0, 1.0, 1.0],
                [3.5, 3.0, 1.5, 1.0],
                [1.0, 1.0, 1.0, 1.5],
                [1.0, 1.0, 1.0, 4.0],
                [1.0, 1.0, 1.0, 3.0],
                [1.0, 1.0, 1.0, 4.0],
                [1.0, 1.0, 1.0, 2.5],
                [1.0, 1.0, 1.0, 1.5],
                [1.0, 1.0, 1.0, 1.0],
                [1.0, 1.0, 1.0, 1.0],
                [1.0, 1.0, 1.0, 1.0],
                [1.0, 1.0, 1.0, 1.0]
            ];

            // Input data untuk D7:D10 dari input pengguna
            $DF1_INPUT = [
                $designFactor->input1df1,
                $designFactor->input2df1,
                $designFactor->input3df1,
                $designFactor->input4df1
            ];


            // Data baseline untuk E7:E10 (tetap, tidak berubah)
            $DF1_BASELINE = [3, 3, 3, 3];

            // Menghitung E12 sebagai rata-rata dari D7:D10
            $E12 = array_sum($DF1_INPUT) / count($DF1_INPUT);

            // Menghitung E14 sebagai rata-rata dari E7:E10 dibagi E12
            $average_E7_E10 = array_sum($DF1_BASELINE) / count($DF1_BASELINE);
            $E14 = ($E12 != 0) ? $average_E7_E10 / $E12 : 0;

            // Menghitung DF1_SCORE
            $DF1_SCORE = [];
            foreach ($DF1map as $row) {
                $DF1_SCORE[] = array_sum(array_map(function ($a, $b) {
                    return $a * $b;
                }, $row, $DF1_INPUT));
            }

            $DF1_BASELINE_SCORE = [
                15,
                24,
                15,
                22.5,
                18,
                12,
                28.5,
                24,
                21,
                33,
                22.5,
                15,
                21,
                22.5,
                21,
                21,
                18,
                16.5,
                12,
                27,
                13.5,
                13.5,
                18,
                25.5,
                19.5,
                18,
                19.5,
                12,
                12,
                27,
                13.5,
                21,
                18,
                21,
                16.5,
                13.5,
                12,
                12,
                12,
                12
            ];

            // Menghitung DF1_RELATIVE_IMPORTANCE dengan pembulatan
            $DF1_RELATIVE_IMPORTANCE = [];
            foreach ($DF1_SCORE as $index => $b) {
                $c = $DF1_BASELINE_SCORE[$index];
                if ($c != 0) {
                    $result = round($E14 * 100 * $b / $c / 5) * 5 - 100;
                } else {
                    $result = 0;
                }
                $DF1_RELATIVE_IMPORTANCE[] = $result;
            }



            //==========================================================================
            // Siapkan data untuk tabel design_factor_1_score
            $dataForScore = [
                'id' => Auth::id(),
                'df1_id' => $designFactor->df_id,
                'assessment_id' => $assessment_id
            ];
            foreach ($DF1_SCORE as $index => $value) {
                $dataForScore['s_df1_' . ($index + 1)] = $value;
            }
            DesignFactor1Score::create($dataForScore);

            // Siapkan data untuk tabel design_factor_1_relative_importance
            $dataForRelativeImportance = [
                'id' => Auth::id(),
                'df1_id' => $designFactor->df_id,
                'assessment_id' => $assessment_id
            ];
            foreach ($DF1_RELATIVE_IMPORTANCE as $index => $value) {
                $dataForRelativeImportance['r_df1_' . ($index + 1)] = $value;
            }
            DesignFactor1RelativeImportance::create($dataForRelativeImportance);

            DB::commit();

            // If this is an AJAX request, return JSON with computed arrays so frontend can update without reload
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Data berhasil disimpan!',
                    'historyInputs' => $DF1_INPUT,
                    'historyScoreArray' => $DF1_SCORE,
                    'historyRIArray' => $DF1_RELATIVE_IMPORTANCE,
                ]);
            }

            // Redirect ke halaman output dengan pesan sukses for non-AJAX
            return redirect()->route('df1.output', ['id' => $designFactor->df_id])
                ->with('success', 'Data berhasil disimpan!');
        } catch (\Exception $e) {
            DB::rollBack();
            // If AJAX request, return JSON error so frontend can surface it
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'There was an error saving the data. Please try again.',
                    'error' => $e->getMessage(),
                ], 500);
            }
            return redirect()->back()->with('error', 'There was an error saving the data. Please try again.');
        }
    }
    //==========================================================================
    // Method untuk menampilkan output Design Factor
    public function showOutput($id)
    {
        // Ambil data dari tabel design_factor_1 dan design_factor_1_score
        $designFactor = DesignFactor1::where('df_id', $id)
            ->where('id', Auth::id())
            ->latest()
            ->first();

        $designFactorScore = DesignFactor1Score::where('df1_id', $id)
            ->where('id', Auth::id())
            ->latest()
            ->first();

        // Ambil data dari DesignFactor1RelativeImportance
        $designFactorRelativeImportance = DesignFactor1RelativeImportance::where('df1_id', $id)
            ->where('id', Auth::id())
            ->latest()
            ->first();

        // Periksa jika data tidak ditemukan
        if (!$designFactor || !$designFactorScore || !$designFactorRelativeImportance) {
            return redirect()->route('home')->with('error', 'Data tidak ditemukan.');
        }
        // Kirim data ke view
        return view('cobit2019.df1.df1_output', [
            'designFactor' => $designFactor,
            'designFactorScore' => $designFactorScore,
            'designFactorRelativeImportance' => $designFactorRelativeImportance
        ]);
    }
}
